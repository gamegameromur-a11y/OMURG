#pragma once
// =============================================================================
// OMURG - Support.h
// Support ticket delivery via EmailJS HTTP API.
// =============================================================================
#ifndef OMURG_SUPPORT_H
#define OMURG_SUPPORT_H

#include <string>

// ---------------------------------------------------------------------------
// Support ticket payload
// ---------------------------------------------------------------------------
struct SupportTicket {
    std::string senderName;
    std::string senderEmail;  // user's reply-to
    std::string subject;
    std::string body;         // plain-text message
    std::string logDump;      // GPU log (base64 encoded)
    std::string gpuModel;
    std::string driverVersion;
    std::string osInfo;
};

// ---------------------------------------------------------------------------
// Mail delivery result
// ---------------------------------------------------------------------------
struct MailResult {
    bool        success  = false;
    int         httpCode = 0;
    std::string detail;
};

// ---------------------------------------------------------------------------
// SupportClient - EmailJS backend
// ---------------------------------------------------------------------------
class SupportClient {
public:
    // EmailJS credentials
    static constexpr const char* EMAILJS_SERVICE_ID  = "service_jy95qwf";
    static constexpr const char* EMAILJS_TEMPLATE_ID = "template_gldxot4";
    static constexpr const char* EMAILJS_PUBLIC_KEY  = "qcT9axXNPRwXwVqmO";
    static constexpr const char* EMAILJS_API_URL     = "https://api.emailjs.com/api/v1.0/email/send";

    SupportClient();
    ~SupportClient();

    // Send support ticket via EmailJS
    MailResult sendTicket(const SupportTicket& ticket);

    // Helpers
    static std::string collectSystemInfo();
    static std::string base64Encode(const std::string& input);

private:
    std::string buildJsonPayload(const SupportTicket& ticket);
    MailResult  postToEmailJS(const std::string& jsonPayload);

    // JSON string escaping
    static std::string jsonEscape(const std::string& s);
};

#endif // OMURG_SUPPORT_H
