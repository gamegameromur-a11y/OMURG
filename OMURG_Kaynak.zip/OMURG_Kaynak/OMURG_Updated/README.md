# OMURG — Virtual GPU

Windows x64 sanal GPU uygulaması. ImGui + DirectX 11 arayüzü.

## Nasıl Build Edilir?

Bu repoyu GitHub'a yükle. Her `push` işleminde GitHub Actions otomatik olarak:

1. Windows makinede MSVC ile derler
2. `OMURG.exe` + `drivers/` + `version_manifest.json` çıktısını üretir
3. **Releases** sekmesinde indirilebilir `.zip` olarak yayınlar

## Nasıl İndirilir?

Sağ taraftaki **Releases** → `OMURG-Windows-x64.zip` → indir → çalıştır.

## Gereksinimler (Çalıştırma)

- Windows 10/11 x64
- DirectX 11 destekli ekran kartı

## Build Gereksinimler (Geliştirme)

- Visual Studio 2022 + MSVC
- CMake 3.20+
- İnternet bağlantısı (ImGui FetchContent ile indirilir)
