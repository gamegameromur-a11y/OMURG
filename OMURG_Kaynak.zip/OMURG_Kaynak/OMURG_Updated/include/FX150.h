#pragma once
// =============================================================================
// OMURG - FX150 Virtual GPU  [OPTIMIZED v1.1]
// =============================================================================
// Performans iyileştirmeleri:
//   1. cpuHasAVX2()     → static local (yalnızca bir kez çalışır)
//   2. m_texMutex       → shared_mutex  (okuma kilidi yok, yazma kilidi paylaşımlı)
//   3. drawTiled()      → AABB tile-culling (boş işler gönderilmez)
//   4. waitAllJobs()    → ayrı m_doneMutex (job mutex ile çakışmaz)
//   5. freeBuffer()     → freelist (VRAM bloklarını geri kazanır)
//   6. allocateBuffer() → freelist'ten önce bakar, bump sonra gelir
//   7. present()        → stride == row ise tek memcpy
// =============================================================================
#ifndef FX150_H
#define FX150_H

#include "VirtualGPU.h"

#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>           // freelist için
#include <memory>
#include <mutex>
#include <shared_mutex>  // [OPT-2] reader-writer kilidi
#include <thread>
#include <atomic>
#include <condition_variable>
#include <queue>
#include <functional>

// ---------------------------------------------------------------------------
// FX150 donanım sabitleri
// ---------------------------------------------------------------------------
namespace FX150_SPEC {
    constexpr uint64_t DEFAULT_VRAM_BYTES    = 512ull * 1024 * 1024;
    constexpr uint64_t MAX_VRAM_BYTES        = 2048ull * 1024 * 1024;
    constexpr uint32_t DEFAULT_COMPUTE_UNITS = 8;
    constexpr uint32_t TILE_SIZE             = 64;
    constexpr uint32_t MAX_UNIFORMS          = 256;
    constexpr uint32_t MAX_TEXTURES          = 128;
    constexpr uint32_t MAX_BUFFERS           = 1024;
    constexpr uint32_t CLOCK_MHZ             = 1200;
    constexpr float    TDP_WATTS             = 75.0f;
    constexpr float    IDLE_TEMP_C           = 35.0f;
    constexpr float    MAX_TEMP_C            = 85.0f;
}

// ---------------------------------------------------------------------------
// FX150 — somut VirtualGPU implementasyonu (optimized)
// BufferAlloc, TextureEntry, RasterTile → VirtualGPU.h içinde tanımlı
// ---------------------------------------------------------------------------
class FX150 : public VirtualGPU {
public:
    explicit FX150(uint64_t vramBytes    = FX150_SPEC::DEFAULT_VRAM_BYTES,
                   uint32_t computeUnits = 0);
    ~FX150() override;

    FX150(const FX150&)            = delete;
    FX150& operator=(const FX150&) = delete;

    // ── VirtualGPU arayüzü ────────────────────────────────────────────────
    bool initialize() override;
    void shutdown()   override;
    bool isReady()    const override;

    uint32_t allocateBuffer(uint64_t bytes) override;
    void     freeBuffer(uint32_t handle)    override;
    bool     uploadData(uint32_t handle, const void* data, uint64_t bytes) override;
    bool     readbackData(uint32_t handle, void* out, uint64_t bytes)       override;

    uint32_t createTexture(uint32_t w, uint32_t h, const uint8_t* rgbaData) override;
    void     destroyTexture(uint32_t handle) override;

    bool createRenderTarget(RenderTarget& rt, uint32_t w, uint32_t h) override;
    void destroyRenderTarget(RenderTarget& rt) override;
    void clearRenderTarget(RenderTarget& rt, float r, float g, float b, float a) override;

    void setVertexShader  (VertexShaderFn  vs) override;
    void setFragmentShader(FragmentShaderFn fs) override;
    void setUniforms(const float* data, uint32_t count) override;

    bool draw(const DrawCall& dc, RenderTarget& rt) override;
    void present(const RenderTarget& rt, void* destPixels, uint32_t destStride) override;

    const GPUDescriptor& descriptor() const override;
    GPUStats             queryStats()  const override;
    std::string          dumpMemoryMap() const override;

    void dispatchCompute(ComputeJob job, uint32_t groupCount = 0) override;

    float simulatedTemperature() const override;
    float simulatedPowerDraw()   const override;

    void setVRAMSize(uint64_t bytes);
    const uint8_t* vramPoolPtr() const { return m_vramPool.get(); }
    uint64_t vramUsed() const;

private:
    // ── [OPT-1] AVX2 bayrağı — constructor'da bir kez hesaplanır ─────────
    bool m_hasAVX2 = false;

    // ── VRAM havuzu ───────────────────────────────────────────────────────
    std::unique_ptr<uint8_t[]> m_vramPool;
    uint64_t                   m_vramSize       = 0;
    uint64_t                   m_vramWatermark  = 0;
    mutable std::mutex         m_vramMutex;

    // ── [OPT-5/6] Freelist: size → offset (geri kazanılmış bloklar) ──────
    std::multimap<uint64_t /*size*/, uint64_t /*offset*/> m_freeList;

    // ── Buffer kaydı ──────────────────────────────────────────────────────
    std::unordered_map<uint32_t, BufferAlloc> m_buffers;
    std::atomic<uint32_t>                     m_nextHandle{1};

    // ── [OPT-2] Texture kaydı — shared_mutex ile okuma kilidi yok ────────
    std::unordered_map<uint32_t, TextureEntry> m_textures;
    mutable std::shared_mutex                  m_texMutex;

    // ── Thread pool ───────────────────────────────────────────────────────
    uint32_t                               m_computeUnits = 0;
    std::vector<std::thread>               m_workers;
    std::queue<std::function<void()>>      m_jobQueue;
    std::mutex                             m_jobMutex;
    std::condition_variable                m_jobCv;

    // ── [OPT-4] Ayrı done mutex — job mutex ile çakışmaz ─────────────────
    std::mutex              m_doneMutex;
    std::condition_variable m_doneCv;

    std::atomic<uint32_t>   m_pendingJobs{0};
    std::atomic<bool>       m_shutdown{false};

    void workerLoop(uint32_t idx);
    void submitJob(std::function<void()> job);
    void waitAllJobs();

    // ── Shader durumu ─────────────────────────────────────────────────────
    VertexShaderFn   m_vs;
    FragmentShaderFn m_fs;
    float            m_uniforms[FX150_SPEC::MAX_UNIFORMS] = {};
    uint32_t         m_uniformCount = 0;

    // ── İstatistikler ─────────────────────────────────────────────────────
    mutable std::mutex m_statsMutex;
    mutable GPUStats   m_stats;
    double             m_frameStart = 0.0;
    std::atomic<float> m_thermalLoad{0.0f};

    // ── Tanımlayıcı ──────────────────────────────────────────────────────
    GPUDescriptor m_desc;
    bool          m_ready = false;

    // ── Dahili rasterizasyon yardımcıları ─────────────────────────────────
    void rasterizeTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2,
                           RenderTarget& rt, const RasterTile& tile);

    void drawTiled(const DrawCall& dc, RenderTarget& rt);

    void sampleTexture(uint32_t handle, float u, float v,
                       uint8_t outRGBA[4]) const;

    static Vertex defaultVS(const Vertex& in, const float*) { return in; }

    static void defaultFS(float, float, const Vertex& v,
                          const float*, uint8_t out[4]) {
        out[0] = static_cast<uint8_t>(v.r * 255.f);
        out[1] = static_cast<uint8_t>(v.g * 255.f);
        out[2] = static_cast<uint8_t>(v.b * 255.f);
        out[3] = static_cast<uint8_t>(v.a * 255.f);
    }

    // [OPT-1] m_hasAVX2 bayrağını alır (statik değil, üye değişken kullanır)
    void simdClear(uint8_t* buf, uint64_t pixels, uint32_t rgba32) const;
    void simdClearFloat(float* buf, uint64_t count, float val) const;
};

#endif // FX150_H
