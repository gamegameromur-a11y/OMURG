#pragma once
// =============================================================================
// OMURG - FX160 Virtual GPU  [v1.2.0]
// =============================================================================
// FX150'den farklar:
//   - 3 GB VRAM (3072 MB)
//   - %50 daha yüksek CPU uyumluluğu ve işlem kapasitesi
//   - 12 compute unit (FX150: 8)
//   - 1800 MHz saat hızı (FX150: 1200 MHz)
//   - Async compute, MSAA, Geometry Shader, Tessellation, Texture Cube desteği
//   - Tile size 32px (FX150: 64px) — daha ince granularite
//   - Aygıt Yöneticisi entegrasyonu (Device Manager PnP)
// =============================================================================
#ifndef FX160_H
#define FX160_H

#include "VirtualGPU.h"

#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <queue>
#include <functional>

// ---------------------------------------------------------------------------
// FX160 donanım sabitleri
// ---------------------------------------------------------------------------
namespace FX160_SPEC {
    constexpr uint64_t DEFAULT_VRAM_BYTES    = 3072ull * 1024 * 1024; // 3 GB
    constexpr uint64_t MAX_VRAM_BYTES        = 3072ull * 1024 * 1024; // 3 GB sabit
    constexpr uint32_t DEFAULT_COMPUTE_UNITS = 12;
    constexpr uint32_t TILE_SIZE             = 32;   // FX150'den daha ince
    constexpr uint32_t MAX_UNIFORMS          = 512;
    constexpr uint32_t MAX_TEXTURES          = 256;
    constexpr uint32_t MAX_BUFFERS           = 2048;
    constexpr uint32_t CLOCK_MHZ             = 1800; // %50 hız artışı
    constexpr float    TDP_WATTS             = 110.0f;
    constexpr float    IDLE_TEMP_C           = 38.0f;
    constexpr float    MAX_TEMP_C            = 90.0f;
    // %50 daha yüksek CPU uyumluluğu için çarpan
    constexpr float    CPU_COMPAT_BOOST      = 1.5f;
    constexpr float    PROC_CAPACITY_MULT    = 1.5f;
}

// ---------------------------------------------------------------------------
// FX160 — somut VirtualGPU implementasyonu
// FX150 mimarisinden türetilmiş, FX160 özellikleri eklenmiş
// ---------------------------------------------------------------------------
class FX160 : public VirtualGPU {
public:
    explicit FX160(uint64_t vramBytes    = FX160_SPEC::DEFAULT_VRAM_BYTES,
                   uint32_t computeUnits = 0);
    ~FX160() override;

    FX160(const FX160&)            = delete;
    FX160& operator=(const FX160&) = delete;

    // ── VirtualGPU arayüzü ────────────────────────────────────────────────
    bool initialize() override;
    void shutdown()   override;
    bool isReady()    const override;

    uint32_t allocateBuffer(uint64_t bytes) override;
    void     freeBuffer(uint32_t handle)    override;
    bool     uploadData(uint32_t handle, const void* data, uint64_t bytes) override;
    bool     readbackData(uint32_t handle, void* out, uint64_t bytes)       override;

    uint32_t createTexture(uint32_t w, uint32_t h, const uint8_t* rgbaData) override;
    void     destroyTexture(uint32_t handle) override;

    bool createRenderTarget(RenderTarget& rt, uint32_t w, uint32_t h) override;
    void destroyRenderTarget(RenderTarget& rt) override;
    void clearRenderTarget(RenderTarget& rt, float r, float g, float b, float a) override;

    void setVertexShader  (VertexShaderFn  vs) override;
    void setFragmentShader(FragmentShaderFn fs) override;
    void setUniforms(const float* data, uint32_t count) override;

    bool draw(const DrawCall& dc, RenderTarget& rt) override;
    void present(const RenderTarget& rt, void* destPixels, uint32_t destStride) override;

    const GPUDescriptor& descriptor() const override;
    GPUStats             queryStats()  const override;
    std::string          dumpMemoryMap() const override;

    void dispatchCompute(ComputeJob job, uint32_t groupCount = 0) override;

    float simulatedTemperature() const override;
    float simulatedPowerDraw()   const override;

    // ── FX160'a özgü ek fonksiyonlar ──────────────────────────────────────
    /** Async compute kuyruğuna iş gönder (4 paralel kuyruk) */
    void dispatchAsyncCompute(ComputeJob job, uint32_t queueIndex = 0);

    /** CPU benzeşim boost faktörünü döndür (%50 artış = 1.5f) */
    float cpuCompatBoost() const { return FX160_SPEC::CPU_COMPAT_BOOST; }

    /** VRAM kullanımı */
    uint64_t vramUsed() const;

    const uint8_t* vramPoolPtr() const { return m_vramPool.get(); }

private:
    bool m_hasAVX2 = false;

    // ── VRAM havuzu ───────────────────────────────────────────────────────
    std::unique_ptr<uint8_t[]> m_vramPool;
    uint64_t                   m_vramSize      = 0;
    uint64_t                   m_vramWatermark = 0;
    mutable std::mutex         m_vramMutex;

    // ── Freelist ─────────────────────────────────────────────────────────
    std::multimap<uint64_t, uint64_t> m_freeList;

    // ── Buffer kaydı ──────────────────────────────────────────────────────
    std::unordered_map<uint32_t, BufferAlloc> m_buffers;
    std::atomic<uint32_t>                     m_nextHandle{1};

    // ── Texture kaydı ────────────────────────────────────────────────────
    std::unordered_map<uint32_t, TextureEntry> m_textures;
    mutable std::shared_mutex                  m_texMutex;

    // ── Ana thread pool ───────────────────────────────────────────────────
    uint32_t                               m_computeUnits = 0;
    std::vector<std::thread>               m_workers;
    std::queue<std::function<void()>>      m_jobQueue;
    std::mutex                             m_jobMutex;
    std::condition_variable                m_jobCv;
    std::mutex                             m_doneMutex;
    std::condition_variable                m_doneCv;
    std::atomic<uint32_t>                  m_pendingJobs{0};
    std::atomic<bool>                      m_shutdown{false};

    // ── Async compute kuyrukları (4 adet) ────────────────────────────────
    static constexpr int ASYNC_QUEUES = 4;
    std::vector<std::thread>          m_asyncWorkers[ASYNC_QUEUES];
    std::queue<std::function<void()>> m_asyncQueues[ASYNC_QUEUES];
    std::mutex                        m_asyncMutex[ASYNC_QUEUES];
    std::condition_variable           m_asyncCv[ASYNC_QUEUES];
    std::atomic<bool>                 m_asyncShutdown{false};

    void workerLoop(uint32_t idx);
    void asyncWorkerLoop(uint32_t queueIdx);
    void submitJob(std::function<void()> job);
    void waitAllJobs();

    // ── Shader durumu ─────────────────────────────────────────────────────
    VertexShaderFn   m_vs;
    FragmentShaderFn m_fs;
    float            m_uniforms[FX160_SPEC::MAX_UNIFORMS] = {};
    uint32_t         m_uniformCount = 0;

    // ── İstatistikler ─────────────────────────────────────────────────────
    mutable std::mutex m_statsMutex;
    mutable GPUStats   m_stats;
    double             m_frameStart = 0.0;
    std::atomic<float> m_thermalLoad{0.0f};

    // ── Tanımlayıcı ──────────────────────────────────────────────────────
    GPUDescriptor m_desc;
    bool          m_ready = false;

    // ── Dahili yardımcılar ────────────────────────────────────────────────
    void rasterizeTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2,
                           RenderTarget& rt, const RasterTile& tile);
    void drawTiled(const DrawCall& dc, RenderTarget& rt);
    void sampleTexture(uint32_t handle, float u, float v,
                       uint8_t outRGBA[4]) const;

    void simdClear(uint8_t* buf, uint64_t pixels, uint32_t rgba32) const;
    void simdClearFloat(float* buf, uint64_t count, float val) const;

    static Vertex defaultVS(const Vertex& in, const float*) { return in; }
    static void   defaultFS(float, float, const Vertex& v,
                            const float*, uint8_t out[4]) {
        out[0] = static_cast<uint8_t>(v.r * 255.f);
        out[1] = static_cast<uint8_t>(v.g * 255.f);
        out[2] = static_cast<uint8_t>(v.b * 255.f);
        out[3] = static_cast<uint8_t>(v.a * 255.f);
    }
};

#endif // FX160_H
