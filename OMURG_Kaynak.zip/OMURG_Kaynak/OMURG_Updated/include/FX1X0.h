#pragma once
// =============================================================================
// OMURG - FX170 / FX180 / FX190 Virtual GPUs  [v1.0.0]
// =============================================================================
// FX170 → Entry  : 1 GB VRAM, 14 CU, 2000 MHz, +60% CPU boost
// FX180 → Mid    : 2 GB VRAM, 18 CU, 2400 MHz, +70% CPU boost
// FX190 → Flagship: 4 GB VRAM, 24 CU, 2800 MHz, +80% CPU boost
// All support: MSAA, GS, Tess, Async Compute, Mesh Shaders (sim)
// =============================================================================
#ifndef FX1X0_H
#define FX1X0_H

#include "VirtualGPU.h"

#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <queue>
#include <functional>

// ---------------------------------------------------------------------------
// Shared next-gen spec helpers
// ---------------------------------------------------------------------------
namespace FX1X0_COMMON {
    constexpr uint32_t TILE_SIZE    = 16;   // 16px — finest granularity
    constexpr uint32_t MAX_UNIFORMS = 1024;
    constexpr uint32_t MAX_TEXTURES = 512;
    constexpr uint32_t MAX_BUFFERS  = 4096;
    constexpr int      ASYNC_QUEUES = 8;    // 8 async compute queues
}

// ---------------------------------------------------------------------------
// FX170 — Entry next-gen
// ---------------------------------------------------------------------------
namespace FX170_SPEC {
    constexpr uint64_t DEFAULT_VRAM_BYTES = 1024ull * 1024 * 1024; // 1 GB
    constexpr uint64_t MAX_VRAM_BYTES     = 1024ull * 1024 * 1024;
    constexpr uint32_t DEFAULT_CU        = 14;
    constexpr uint32_t CLOCK_MHZ         = 2000;
    constexpr float    TDP_WATTS         = 85.f;
    constexpr float    IDLE_TEMP_C       = 36.f;
    constexpr float    MAX_TEMP_C        = 88.f;
    constexpr float    CPU_BOOST         = 1.6f;  // +60%
    constexpr float    PROC_MULT         = 1.6f;
}

// ---------------------------------------------------------------------------
// FX180 — Mid next-gen
// ---------------------------------------------------------------------------
namespace FX180_SPEC {
    constexpr uint64_t DEFAULT_VRAM_BYTES = 2048ull * 1024 * 1024; // 2 GB
    constexpr uint64_t MAX_VRAM_BYTES     = 2048ull * 1024 * 1024;
    constexpr uint32_t DEFAULT_CU        = 18;
    constexpr uint32_t CLOCK_MHZ         = 2400;
    constexpr float    TDP_WATTS         = 130.f;
    constexpr float    IDLE_TEMP_C       = 40.f;
    constexpr float    MAX_TEMP_C        = 92.f;
    constexpr float    CPU_BOOST         = 1.7f;  // +70%
    constexpr float    PROC_MULT         = 1.7f;
}

// ---------------------------------------------------------------------------
// FX190 — Flagship next-gen
// ---------------------------------------------------------------------------
namespace FX190_SPEC {
    constexpr uint64_t DEFAULT_VRAM_BYTES = 4096ull * 1024 * 1024; // 4 GB
    constexpr uint64_t MAX_VRAM_BYTES     = 4096ull * 1024 * 1024;
    constexpr uint32_t DEFAULT_CU        = 24;
    constexpr uint32_t CLOCK_MHZ         = 2800;
    constexpr float    TDP_WATTS         = 180.f;
    constexpr float    IDLE_TEMP_C       = 42.f;
    constexpr float    MAX_TEMP_C        = 95.f;
    constexpr float    CPU_BOOST         = 1.8f;  // +80%
    constexpr float    PROC_MULT         = 1.8f;
}

// ---------------------------------------------------------------------------
// Base class shared by FX170/180/190 — avoids code triplication
// ---------------------------------------------------------------------------
class FX1X0Base : public VirtualGPU {
public:
    explicit FX1X0Base(const char* modelName,
                       uint64_t vramBytes,
                       uint32_t computeUnits,
                       uint32_t clockMHz,
                       float    tdpWatts,
                       float    idleTemp,
                       float    maxTemp,
                       float    cpuBoost,
                       float    procMult);
    ~FX1X0Base() override;

    FX1X0Base(const FX1X0Base&)            = delete;
    FX1X0Base& operator=(const FX1X0Base&) = delete;

    // VirtualGPU interface
    bool initialize() override;
    void shutdown()   override;
    bool isReady()    const override { return m_ready; }

    uint32_t allocateBuffer(uint64_t bytes) override;
    void     freeBuffer(uint32_t handle)    override;
    bool     uploadData(uint32_t handle, const void* data, uint64_t bytes) override;
    bool     readbackData(uint32_t handle, void* out, uint64_t bytes)       override;

    uint32_t createTexture(uint32_t w, uint32_t h, const uint8_t* rgbaData) override;
    void     destroyTexture(uint32_t handle) override;

    bool createRenderTarget(RenderTarget& rt, uint32_t w, uint32_t h) override;
    void destroyRenderTarget(RenderTarget& rt) override;
    void clearRenderTarget(RenderTarget& rt, float r, float g, float b, float a) override;

    void setVertexShader  (VertexShaderFn  vs) override;
    void setFragmentShader(FragmentShaderFn fs) override;
    void setUniforms(const float* data, uint32_t count) override;

    bool draw(const DrawCall& dc, RenderTarget& rt) override;
    void present(const RenderTarget& rt, void* destPixels, uint32_t destStride) override;

    const GPUDescriptor& descriptor() const override { return m_desc; }
    GPUStats             queryStats()  const override;
    std::string          dumpMemoryMap() const override;

    void dispatchCompute(ComputeJob job, uint32_t groupCount = 0) override;

    float simulatedTemperature() const override;
    float simulatedPowerDraw()   const override;

    // Next-gen extras
    void  dispatchAsyncCompute(ComputeJob job, uint32_t queueIndex = 0);
    float cpuBoost()  const { return m_cpuBoost; }
    float procMult()  const { return m_procMult; }
    uint64_t vramUsed() const;

protected:
    // Hardware params (set by derived spec)
    float    m_cpuBoost;
    float    m_procMult;
    float    m_tdpWatts;
    float    m_idleTemp;
    float    m_maxTemp;

    bool     m_hasAVX2 = false;

    // VRAM pool
    std::unique_ptr<uint8_t[]> m_vramPool;
    uint64_t                   m_vramSize      = 0;
    uint64_t                   m_vramWatermark = 0;
    mutable std::mutex         m_vramMutex;
    std::multimap<uint64_t, uint64_t> m_freeList;

    // Buffer/Texture maps
    std::unordered_map<uint32_t, BufferAlloc>  m_buffers;
    std::atomic<uint32_t>                      m_nextHandle{1};
    std::unordered_map<uint32_t, TextureEntry> m_textures;
    mutable std::shared_mutex                  m_texMutex;

    // Main thread pool
    uint32_t                               m_computeUnits = 0;
    std::vector<std::thread>               m_workers;
    std::queue<std::function<void()>>      m_jobQueue;
    std::mutex                             m_jobMutex;
    std::condition_variable                m_jobCv;
    std::mutex                             m_doneMutex;
    std::condition_variable                m_doneCv;
    std::atomic<uint32_t>                  m_pendingJobs{0};
    std::atomic<bool>                      m_shutdown{false};

    // Async queues (8)
    static constexpr int ASYNC_Q = 8;
    std::vector<std::thread>          m_asyncWorkers[ASYNC_Q];
    std::queue<std::function<void()>> m_asyncQueues[ASYNC_Q];
    std::mutex                        m_asyncMutex[ASYNC_Q];
    std::condition_variable           m_asyncCv[ASYNC_Q];
    std::atomic<bool>                 m_asyncShutdown{false};

    // Shaders
    VertexShaderFn   m_vs;
    FragmentShaderFn m_fs;
    float            m_uniforms[FX1X0_COMMON::MAX_UNIFORMS] = {};
    uint32_t         m_uniformCount = 0;

    // Stats
    mutable std::mutex m_statsMutex;
    mutable GPUStats   m_stats;
    double             m_frameStart = 0.0;
    std::atomic<float> m_thermalLoad{0.0f};

    GPUDescriptor m_desc;
    bool          m_ready = false;

    // Internal
    void workerLoop(uint32_t idx);
    void asyncWorkerLoop(uint32_t queueIdx);
    void submitJob(std::function<void()> job);
    void waitAllJobs();

    void rasterizeTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2,
                           RenderTarget& rt, const RasterTile& tile);
    void drawTiled(const DrawCall& dc, RenderTarget& rt);
    void sampleTexture(uint32_t handle, float u, float v, uint8_t outRGBA[4]) const;
    void simdClear(uint8_t* buf, uint64_t pixels, uint32_t rgba32) const;
    void simdClearFloat(float* buf, uint64_t count, float val) const;

    static Vertex defaultVS(const Vertex& in, const float*) { return in; }
    static void   defaultFS(float, float, const Vertex& v, const float*, uint8_t out[4]) {
        out[0] = (uint8_t)(v.r*255.f); out[1] = (uint8_t)(v.g*255.f);
        out[2] = (uint8_t)(v.b*255.f); out[3] = (uint8_t)(v.a*255.f);
    }
};

// ---------------------------------------------------------------------------
// Concrete GPU classes — thin wrappers that pass spec constants to base
// ---------------------------------------------------------------------------

class FX170 : public FX1X0Base {
public:
    explicit FX170(uint64_t vramBytes = FX170_SPEC::DEFAULT_VRAM_BYTES,
                   uint32_t cu = 0)
        : FX1X0Base("OMURG FX170", vramBytes,
                    cu == 0 ? (uint32_t)(std::thread::hardware_concurrency()
                               * FX170_SPEC::CPU_BOOST) : cu,
                    FX170_SPEC::CLOCK_MHZ, FX170_SPEC::TDP_WATTS,
                    FX170_SPEC::IDLE_TEMP_C, FX170_SPEC::MAX_TEMP_C,
                    FX170_SPEC::CPU_BOOST, FX170_SPEC::PROC_MULT) {}
};

class FX180 : public FX1X0Base {
public:
    explicit FX180(uint64_t vramBytes = FX180_SPEC::DEFAULT_VRAM_BYTES,
                   uint32_t cu = 0)
        : FX1X0Base("OMURG FX180", vramBytes,
                    cu == 0 ? (uint32_t)(std::thread::hardware_concurrency()
                               * FX180_SPEC::CPU_BOOST) : cu,
                    FX180_SPEC::CLOCK_MHZ, FX180_SPEC::TDP_WATTS,
                    FX180_SPEC::IDLE_TEMP_C, FX180_SPEC::MAX_TEMP_C,
                    FX180_SPEC::CPU_BOOST, FX180_SPEC::PROC_MULT) {}
};

class FX190 : public FX1X0Base {
public:
    explicit FX190(uint64_t vramBytes = FX190_SPEC::DEFAULT_VRAM_BYTES,
                   uint32_t cu = 0)
        : FX1X0Base("OMURG FX190", vramBytes,
                    cu == 0 ? (uint32_t)(std::thread::hardware_concurrency()
                               * FX190_SPEC::CPU_BOOST) : cu,
                    FX190_SPEC::CLOCK_MHZ, FX190_SPEC::TDP_WATTS,
                    FX190_SPEC::IDLE_TEMP_C, FX190_SPEC::MAX_TEMP_C,
                    FX190_SPEC::CPU_BOOST, FX190_SPEC::PROC_MULT) {}
};

#endif // FX1X0_H
