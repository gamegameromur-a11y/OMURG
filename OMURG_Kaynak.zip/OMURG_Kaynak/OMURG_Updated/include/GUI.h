#pragma once
// =============================================================================
// OMURG - GUI.h  [v3.0]
// =============================================================================
#ifndef OMURG_GUI_H
#define OMURG_GUI_H

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <memory>

struct Lang;

class OMURGGui {
public:
    OMURGGui();
    ~OMURGGui();

    bool init(HWND hwnd);
    void render();
    void resize(UINT w, UINT h);
    void shutdown();

private:
    struct Impl;
    std::unique_ptr<Impl> m;

    void createRTV();

    void renderGPU();
    void renderPerf();
    void renderDriver();
    void renderUpdate();
    void renderSupport();
    void renderSettings();
};

#define IDI_OMURG 101
#endif // OMURG_GUI_H
