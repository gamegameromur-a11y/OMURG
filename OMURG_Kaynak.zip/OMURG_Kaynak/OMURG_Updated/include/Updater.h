#pragma once
// =============================================================================
// OMURG - Updater.h
// GitHub-based auto-updater using WinINet
// =============================================================================
#ifndef OMURG_UPDATER_H
#define OMURG_UPDATER_H

#include <string>
#include <vector>
#include <functional>
#include <atomic>
#include <thread>

// ---------------------------------------------------------------------------
// Version manifest entry (mirrors version_manifest.json structure)
// ---------------------------------------------------------------------------
struct GPUManifestEntry {
    std::string modelId;       // e.g. "FX150", "FX200"
    std::string version;       // semver "1.2.3"
    std::string configUrl;     // URL to .json config
    std::string binaryUrl;     // URL to driver DLL (optional)
    std::string sha256;        // expected hash of downloaded file
    std::string changelog;     // human-readable changes
};

struct VersionManifest {
    std::string               appVersion;   // OMURG app version
    std::string               minVersion;   // minimum compatible version
    std::vector<GPUManifestEntry> gpuEntries;
    bool                      valid = false;
};

// ---------------------------------------------------------------------------
// Download progress callback
// ---------------------------------------------------------------------------
struct DownloadProgress {
    std::string filename;
    uint64_t    bytesReceived = 0;
    uint64_t    totalBytes    = 0;  // 0 if unknown
    bool        finished      = false;
    bool        success       = false;
    std::string errorMsg;
};
using ProgressCb = std::function<void(const DownloadProgress&)>;

// ---------------------------------------------------------------------------
// Updater class
// ---------------------------------------------------------------------------
class Updater {
public:
    // GitHub raw content base URL
    static constexpr const char* DEFAULT_MANIFEST_URL =
        "https://raw.githubusercontent.com/gamegameromur-a11y/OMURG/main"
        "/version_manifest.json";

    static constexpr const char* DRIVERS_DIR = "drivers\\";

    explicit Updater(std::string manifestUrl = DEFAULT_MANIFEST_URL);
    ~Updater();

    // -- Configuration -------------------------------------------------------
    void setManifestUrl(const std::string& url) { m_manifestUrl = url; }
    void setDriversDir (const std::string& dir) { m_driversDir  = dir; }
    void setUserAgent  (const std::string& ua)  { m_userAgent   = ua;  }

    // -- Synchronous API -----------------------------------------------------
    /** Fetch and parse the manifest JSON. */
    VersionManifest fetchManifest();

    /** Download a single file to disk. Returns true on success. */
    bool downloadFile(const std::string& url,
                      const std::string& localPath,
                      ProgressCb         progress = nullptr);

    /** Verify SHA-256 of a local file. */
    static bool verifySHA256(const std::string& filePath,
                             const std::string& expectedHex);

    /** Check installed GPU driver version vs manifest. */
    static bool isUpdateRequired(const std::string& installed,
                                 const std::string& latest);

    // -- Asynchronous API ----------------------------------------------------
    /** Start a background check + download. Non-blocking. */
    void startAsyncUpdate(ProgressCb progress,
                          std::function<void(bool success,
                                             const std::string& msg)> done);

    /** Cancel any pending async operation. */
    void cancelAsync();

    bool isRunning() const { return m_running.load(); }

    // -- App self-update ------------------------------------------------------
    /** Replace the current binary with a downloaded one (Win32 move + restart). */
    static bool applyAppUpdate(const std::string& newExePath);

private:
    std::string m_manifestUrl;
    std::string m_driversDir;
    std::string m_userAgent;
    std::atomic<bool> m_running{false};
    std::atomic<bool> m_cancel {false};
    std::thread       m_asyncThread;

    /** Internal HTTP GET via WinINet → string. */
    std::string httpGet(const std::string& url);

    /** Internal HTTP GET → file. */
    bool httpGetToFile(const std::string& url,
                       const std::string& localPath,
                       ProgressCb         progress);

    /** Minimal JSON field extractor (no dependency on nlohmann). */
    static std::string jsonField(const std::string& json,
                                 const std::string& key);
    static std::vector<std::string> jsonArray(const std::string& json,
                                              const std::string& key);

    /** Create drivers directory if it doesn't exist. */
    static void ensureDriversDir(const std::string& dir);
};

#endif // OMURG_UPDATER_H
