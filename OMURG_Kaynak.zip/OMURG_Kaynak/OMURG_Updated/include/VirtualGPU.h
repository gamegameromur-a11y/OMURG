#pragma once
// =============================================================================
// OMURG - Open Multi-Use Rendering GPU
// VirtualGPU.h  -  Abstract base class for all virtual GPU implementations
// =============================================================================
#ifndef VIRTUAL_GPU_H
#define VIRTUAL_GPU_H

#include <cstdint>
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <atomic>
#include <chrono>

// ---------------------------------------------------------------------------
// Forward declarations
// ---------------------------------------------------------------------------
struct RenderTarget;
struct DrawCall;
struct GPUStats;

// ---------------------------------------------------------------------------
// GPU Capability flags (bitmask)
// ---------------------------------------------------------------------------
enum class GPUFeature : uint32_t {
    NONE            = 0,
    RASTERIZATION   = (1u << 0),
    DEPTH_BUFFER    = (1u << 1),
    STENCIL_BUFFER  = (1u << 2),
    TEXTURE_2D      = (1u << 3),
    TEXTURE_CUBE    = (1u << 4),
    MIPMAPPING      = (1u << 5),
    MSAA            = (1u << 6),
    COMPUTE_SHADERS = (1u << 7),
    GEOMETRY_SHADER = (1u << 8),
    TESSELLATION    = (1u << 9),
    RAYTRACING      = (1u << 10),
    SIMD_SSE4       = (1u << 11),
    SIMD_AVX2       = (1u << 12),
    ASYNC_COMPUTE   = (1u << 13),
};

inline GPUFeature operator|(GPUFeature a, GPUFeature b) {
    return static_cast<GPUFeature>(static_cast<uint32_t>(a) | static_cast<uint32_t>(b));
}
inline bool operator&(GPUFeature a, GPUFeature b) {
    return (static_cast<uint32_t>(a) & static_cast<uint32_t>(b)) != 0;
}

// ---------------------------------------------------------------------------
// GPU Descriptor — identity & capabilities
// ---------------------------------------------------------------------------
struct GPUDescriptor {
    std::string  modelName;         // e.g. "OMURG FX150"
    std::string  vendorName;        // e.g. "OMURG Virtual"
    std::string  driverVersion;     // semver string
    uint64_t     vramBytes;         // allocated VRAM in system RAM
    uint32_t     computeUnits;      // number of SW compute units (threads)
    uint32_t     clockSpeedMHz;     // simulated clock (for perf scaling)
    uint32_t     maxTextureSize;    // max 1D/2D texture dimension
    uint32_t     maxRenderTargets;  // MRT count
    GPUFeature   features;          // capability bitmask
};

// ---------------------------------------------------------------------------
// Render Target
// ---------------------------------------------------------------------------
struct RenderTarget {
    uint32_t  width  = 0;
    uint32_t  height = 0;
    uint8_t*  colorBuffer  = nullptr;  // RGBA8
    float*    depthBuffer  = nullptr;  // 32-bit float
    uint8_t*  stencilBuffer = nullptr; // 8-bit

    uint64_t byteSize() const {
        return static_cast<uint64_t>(width) * height * 4   // RGBA
             + static_cast<uint64_t>(width) * height * 4   // depth
             + static_cast<uint64_t>(width) * height;      // stencil
    }
};

// ---------------------------------------------------------------------------
// Minimal vertex / draw-call types
// ---------------------------------------------------------------------------
struct Vertex {
    float x, y, z, w;   // clip-space position
    float r, g, b, a;   // color
    float u, v;          // texcoord
    float nx, ny, nz;   // normal
};

struct DrawCall {
    const Vertex*  vertices  = nullptr;
    const uint32_t* indices  = nullptr;
    uint32_t  vertexCount    = 0;
    uint32_t  indexCount     = 0;
    uint32_t  textureHandle  = 0;
    bool      wireframe      = false;
    bool      depthTest      = true;
    bool      alphaBlend     = false;
};

// ---------------------------------------------------------------------------
// Per-frame GPU statistics
// ---------------------------------------------------------------------------
struct GPUStats {
    uint64_t  framesRendered    = 0;
    uint64_t  drawCallsPerFrame = 0;
    uint64_t  trianglesPerFrame = 0;
    uint64_t  textureMemoryUsed = 0;  // bytes
    uint64_t  vramUsed          = 0;  // bytes
    double    gpuTimeMs         = 0.0;
    double    fps               = 0.0;
    double    memBandwidthGBs   = 0.0;
    uint32_t  activeThreads     = 0;
};

// ---------------------------------------------------------------------------
// Shader callback types (SW shader simulation)
// ---------------------------------------------------------------------------
using VertexShaderFn  = std::function<Vertex(const Vertex& in, const float* uniforms)>;
using FragmentShaderFn= std::function<void(float x, float y, const Vertex& interp,
                                           const float* uniforms,
                                           uint8_t outRGBA[4])>;

// ---------------------------------------------------------------------------
// VirtualGPU  —  abstract base
// ---------------------------------------------------------------------------
class VirtualGPU {
public:
    // ── Lifecycle ──────────────────────────────────────────────────────────
    virtual ~VirtualGPU() = default;

    /** Initialize VRAM pool and compute units. Returns false on failure. */
    virtual bool initialize() = 0;

    /** Release all GPU resources. Must be idempotent. */
    virtual void shutdown() = 0;

    /** Returns true if initialize() has succeeded and shutdown() not yet called. */
    virtual bool isReady() const = 0;

    // ── Memory management ─────────────────────────────────────────────────
    /** Allocate a block inside the VRAM pool. Returns handle (0 = failure). */
    virtual uint32_t allocateBuffer(uint64_t bytes) = 0;

    /** Free a previously allocated buffer. */
    virtual void freeBuffer(uint32_t handle) = 0;

    /** Upload CPU data into a VRAM buffer. */
    virtual bool uploadData(uint32_t handle, const void* data, uint64_t bytes) = 0;

    /** Read back GPU buffer to CPU. */
    virtual bool readbackData(uint32_t handle, void* out, uint64_t bytes) = 0;

    // ── Texture management ────────────────────────────────────────────────
    virtual uint32_t createTexture(uint32_t w, uint32_t h,
                                   const uint8_t* rgbaData) = 0;
    virtual void destroyTexture(uint32_t handle) = 0;

    // ── Render pipeline ───────────────────────────────────────────────────
    virtual bool createRenderTarget(RenderTarget& rt,
                                    uint32_t w, uint32_t h) = 0;
    virtual void destroyRenderTarget(RenderTarget& rt) = 0;

    virtual void clearRenderTarget(RenderTarget& rt,
                                   float r, float g,
                                   float b, float a) = 0;

    /** Install per-draw-call SW shaders. */
    virtual void setVertexShader  (VertexShaderFn  vs) = 0;
    virtual void setFragmentShader(FragmentShaderFn fs) = 0;

    /** Set uniform data (raw float array, max 256 floats). */
    virtual void setUniforms(const float* data, uint32_t count) = 0;

    /** Execute a draw call into the given render target. */
    virtual bool draw(const DrawCall& dc, RenderTarget& rt) = 0;

    /** Present: copy the render target to a Win32 HDC / raw pixel buffer. */
    virtual void present(const RenderTarget& rt, void* destPixels,
                         uint32_t destStride) = 0;

    // ── Query & diagnostics ───────────────────────────────────────────────
    virtual const GPUDescriptor& descriptor() const = 0;
    virtual GPUStats             queryStats()  const = 0;

    /** Dump current VRAM usage map to a string (debug). */
    virtual std::string dumpMemoryMap() const = 0;

    // ── Compute dispatch (generic) ────────────────────────────────────────
    /** Dispatch a CPU-side compute job on the GPU's thread pool. */
    using ComputeJob = std::function<void(uint32_t threadIdx, uint32_t totalThreads)>;
    virtual void dispatchCompute(ComputeJob job, uint32_t groupCount = 0) = 0;

    // ── Power / thermal simulation ────────────────────────────────────────
    /** Simulated GPU temperature (°C) based on workload. */
    virtual float simulatedTemperature() const = 0;

    /** Simulated power draw (Watts). */
    virtual float simulatedPowerDraw() const = 0;

protected:
    // Shared utility: high-resolution timer
    static double nowMs() {
        using namespace std::chrono;
        return duration<double, std::milli>(
            high_resolution_clock::now().time_since_epoch()).count();
    }
};

// ---------------------------------------------------------------------------
// Shared internal structs — used by FX150, FX160 and any future GPU impl.
// Defined here so that all concrete GPU headers can include VirtualGPU.h
// without depending on each other.
// ---------------------------------------------------------------------------

/// Internal VRAM buffer allocation record.
struct BufferAlloc {
    uint32_t handle = 0;
    uint64_t offset = 0;
    uint64_t size   = 0;
    bool     inUse  = false;
};

/// Internal texture allocation record.
struct TextureEntry {
    uint32_t handle  = 0;
    uint32_t width   = 0;
    uint32_t height  = 0;
    uint64_t vramOff = 0;
    bool     valid   = false;
};

/// Rasterizer tile — one work unit dispatched to the thread pool.
struct RasterTile {
    uint32_t x0, y0, x1, y1;
};

#endif // VIRTUAL_GPU_H
