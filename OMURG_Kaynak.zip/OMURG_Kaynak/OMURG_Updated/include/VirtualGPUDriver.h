#pragma once
// =============================================================================
// OMURG - VirtualGPUDriver.h
// Windows PnP sanal GPU aygıt kaydı.
// SetupAPI + devmgr ile sisteme fiziksel GPU gibi görünen sanal aygıt ekler.
// WDDM uyumlu INF dosyası üretir ve sürücüyü sisteme işler.
// =============================================================================
#ifndef VIRTUAL_GPU_DRIVER_H
#define VIRTUAL_GPU_DRIVER_H

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <setupapi.h>
#include <devguid.h>
#include <newdev.h>
#include <cfgmgr32.h>
#include <string>
#include <vector>
#include <functional>

#pragma comment(lib, "setupapi.lib")
#pragma comment(lib, "cfgmgr32.lib")
#pragma comment(lib, "newdev.lib")

// ---------------------------------------------------------------------------
// Sanal GPU model tanımı
// ---------------------------------------------------------------------------
struct VGPUDeviceInfo {
    std::wstring modelName;       // L"OMURG FX160"
    std::wstring hardwareId;      // L"ROOT\\OMURG_FX160"
    std::wstring description;     // Device Manager'da görünen açıklama
    std::wstring manufacturer;    // L"OMURG Virtual Hardware"
    std::wstring driverVersion;   // L"2.0.0.0"
    std::string  vramStr;         // "3072 MB"
    bool         installed = false;
    bool         enabled   = false;
    DEVINST      devInst   = 0;
};

// ---------------------------------------------------------------------------
// Kurulum/kaldırma sonucu
// ---------------------------------------------------------------------------
struct DriverInstallResult {
    bool    success    = false;
    bool    rebootReq  = false;
    DWORD   errorCode  = 0;
    std::wstring message;
};

// ---------------------------------------------------------------------------
// VirtualGPUDriver — ana sınıf
// ---------------------------------------------------------------------------
class VirtualGPUDriver {
public:
    VirtualGPUDriver() = default;
    ~VirtualGPUDriver() = default;

    // Sisteme kayıtlı OMURG aygıtlarını tara
    std::vector<VGPUDeviceInfo> enumInstalledDevices();

    // INF dosyası oluştur + aygıtı sisteme ekle (Yönetici gerektirir)
    DriverInstallResult installDevice(const VGPUDeviceInfo& info,
                                      const std::wstring& infDir);

    // Aygıtı sistemden kaldır
    DriverInstallResult removeDevice(const VGPUDeviceInfo& info);

    // Aygıtı etkinleştir / devre dışı bırak
    bool enableDevice (const VGPUDeviceInfo& info);
    bool disableDevice(const VGPUDeviceInfo& info);

    // INF içeriği üret (temp dizinine yazar, yolu döndürür)
    std::wstring generateINF(const VGPUDeviceInfo& info,
                             const std::wstring& outDir);

    // Yönetici ayrıcalığı var mı?
    static bool isElevated();

    // UAC ile yönetici olarak yeniden başlat
    static bool relaunchAsAdmin(const wchar_t* args = L"--install");

    // Hata kodunu string'e çevir
    static std::wstring errorString(DWORD code);

private:
    // SetupAPI ile doğrudan aygıt oluştur (devnode)
    bool createRootEnumeratedDevice(const std::wstring& hardwareId,
                                    HDEVINFO* phDevInfo,
                                    SP_DEVINFO_DATA* pDevInfoData);

    // Registry'e özellik yaz
    bool setDeviceProperty(HDEVINFO hDevInfo,
                           SP_DEVINFO_DATA* pDid,
                           DWORD property,
                           const std::wstring& value);

    bool setDevicePropertyDword(HDEVINFO hDevInfo,
                                SP_DEVINFO_DATA* pDid,
                                DWORD property,
                                DWORD value);
};

#endif // VIRTUAL_GPU_DRIVER_H
