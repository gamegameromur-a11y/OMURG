// =============================================================================
// OMURG - FX160 Virtual GPU Implementation  [v1.2.0]
// =============================================================================
// FX150'den üstünlükler:
//   - 3 GB VRAM (3072 MB sabit)
//   - %50 daha yüksek CPU uyumluluğu (CPU_COMPAT_BOOST = 1.5f)
//   - %50 daha yüksek işlem kapasitesi (PROC_CAPACITY_MULT = 1.5f)
//   - 12 compute unit (FX150: 8)
//   - 1800 MHz saat hızı (FX150: 1200 MHz)
//   - Tile boyutu 32px (FX150: 64px) — daha ince granularite
//   - 4 async compute kuyruğu
//   - Aygıt Yöneticisi (Device Manager) PnP entegrasyonu
// =============================================================================

#include "FX160.h"

#include <cstring>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <stdexcept>

#if defined(_MSC_VER)
#   include <intrin.h>
#   include <immintrin.h>
#elif defined(__GNUC__) || defined(__clang__)
#   include <immintrin.h>
#   include <cpuid.h>
#endif

// =============================================================================
// cpuHasAVX2 — static local, tek seferlik
// =============================================================================
static bool cpuHasAVX2_FX160() {
    static const bool result = []() -> bool {
#if defined(_MSC_VER)
        int info[4] = {};
        __cpuidex(info, 7, 0);
        return (info[1] & (1 << 5)) != 0;
#elif defined(__GNUC__) || defined(__clang__)
        unsigned eax, ebx, ecx, edx;
        if (__get_cpuid_count(7, 0, &eax, &ebx, &ecx, &edx))
            return (ebx & (1u << 5)) != 0;
        return false;
#else
        return false;
#endif
    }();
    return result;
}

// ---------------------------------------------------------------------------
// Matematik yardımcıları
// ---------------------------------------------------------------------------
static inline float edgeFn160(const Vertex& a, const Vertex& b,
                               float px, float py) {
    return (px - a.x) * (b.y - a.y) - (py - a.y) * (b.x - a.x);
}

static inline uint8_t toU8_160(float f) {
    int i = static_cast<int>(f * 255.f + 0.5f);
    return static_cast<uint8_t>(i < 0 ? 0 : i > 255 ? 255 : i);
}

// =============================================================================
// Yapı / Yıkım
// =============================================================================

FX160::FX160(uint64_t vramBytes, uint32_t computeUnits)
    : m_hasAVX2(cpuHasAVX2_FX160())
    , m_vramSize(FX160_SPEC::DEFAULT_VRAM_BYTES) // Her zaman 3 GB
    , m_computeUnits(computeUnits == 0
          // %50 boost: hardware_concurrency * 1.5, en az 12
          ? std::max(12u, static_cast<uint32_t>(
                std::thread::hardware_concurrency()
                * FX160_SPEC::CPU_COMPAT_BOOST))
          : computeUnits)
{
    (void)vramBytes; // FX160 her zaman 3 GB VRAM kullanır

    if (m_computeUnits > 96) m_computeUnits = 96;

    m_desc.modelName        = "OMURG FX160";
    m_desc.vendorName       = "OMURG Virtual Hardware";
    m_desc.driverVersion    = "1.2.0";
    m_desc.vramBytes        = FX160_SPEC::DEFAULT_VRAM_BYTES;
    m_desc.computeUnits     = m_computeUnits;
    m_desc.clockSpeedMHz    = FX160_SPEC::CLOCK_MHZ;
    m_desc.maxTextureSize   = 8192;
    m_desc.maxRenderTargets = 8;
    m_desc.features         = GPUFeature::RASTERIZATION
                            | GPUFeature::DEPTH_BUFFER
                            | GPUFeature::STENCIL_BUFFER
                            | GPUFeature::TEXTURE_2D
                            | GPUFeature::TEXTURE_CUBE
                            | GPUFeature::MIPMAPPING
                            | GPUFeature::MSAA
                            | GPUFeature::COMPUTE_SHADERS
                            | GPUFeature::GEOMETRY_SHADER
                            | GPUFeature::TESSELLATION
                            | GPUFeature::ASYNC_COMPUTE
                            | GPUFeature::SIMD_SSE4
                            | (m_hasAVX2 ? GPUFeature::SIMD_AVX2
                                         : GPUFeature::NONE);

    m_vs = FX160::defaultVS;
    m_fs = FX160::defaultFS;
}

FX160::~FX160() {
    shutdown();
}

// =============================================================================
// Yaşam döngüsü
// =============================================================================

bool FX160::initialize() {
    if (m_ready) return true;

    // 3 GB VRAM havuzu tahsis et
#if defined(_MSC_VER) || defined(__MINGW32__)
    m_vramPool.reset(static_cast<uint8_t*>(
        _aligned_malloc(static_cast<size_t>(m_vramSize), 64)));
#else
    void* ptr = nullptr;
    if (posix_memalign(&ptr, 64, static_cast<size_t>(m_vramSize)) != 0)
        ptr = nullptr;
    m_vramPool.reset(static_cast<uint8_t*>(ptr));
#endif

    if (!m_vramPool) {
        try {
            m_vramPool = std::make_unique<uint8_t[]>(
                static_cast<size_t>(m_vramSize));
        } catch (...) {
            return false;
        }
    }

    std::memset(m_vramPool.get(), 0, static_cast<size_t>(m_vramSize));
    m_vramWatermark = 0;
    m_freeList.clear();

    // Ana thread pool başlat
    m_shutdown.store(false);
    m_workers.reserve(m_computeUnits);
    for (uint32_t i = 0; i < m_computeUnits; ++i)
        m_workers.emplace_back([this, i]{ workerLoop(i); });

    // Async compute kuyrukları başlat (4 kuyruk, her biri 3 worker)
    m_asyncShutdown.store(false);
    for (int q = 0; q < ASYNC_QUEUES; ++q) {
        for (int w = 0; w < 3; ++w) {
            m_asyncWorkers[q].emplace_back([this, q]{ asyncWorkerLoop(q); });
        }
    }

    m_ready = true;
    m_desc.vramBytes    = m_vramSize;
    m_desc.computeUnits = m_computeUnits;
    return true;
}

void FX160::shutdown() {
    if (!m_ready) return;

    // Ana worker'ları durdur
    {
        std::unique_lock<std::mutex> lk(m_jobMutex);
        m_shutdown.store(true);
    }
    m_jobCv.notify_all();
    for (auto& t : m_workers)
        if (t.joinable()) t.join();
    m_workers.clear();

    // Async worker'ları durdur
    m_asyncShutdown.store(true);
    for (int q = 0; q < ASYNC_QUEUES; ++q) {
        m_asyncCv[q].notify_all();
        for (auto& t : m_asyncWorkers[q])
            if (t.joinable()) t.join();
        m_asyncWorkers[q].clear();
    }

#if defined(_MSC_VER) || defined(__MINGW32__)
    if (m_vramPool) _aligned_free(m_vramPool.release());
#else
    m_vramPool.reset();
#endif

    m_vramWatermark = 0;
    m_freeList.clear();
    m_buffers.clear();
    m_textures.clear();
    m_ready = false;
}

bool FX160::isReady() const { return m_ready; }

// =============================================================================
// Thread pool
// =============================================================================

void FX160::workerLoop(uint32_t /*idx*/) {
    while (true) {
        std::function<void()> job;
        {
            std::unique_lock<std::mutex> lk(m_jobMutex);
            m_jobCv.wait(lk, [this]{
                return !m_jobQueue.empty() || m_shutdown.load();
            });
            if (m_shutdown.load() && m_jobQueue.empty()) return;
            job = std::move(m_jobQueue.front());
            m_jobQueue.pop();
        }
        job();
        if (m_pendingJobs.fetch_sub(1, std::memory_order_acq_rel) == 1) {
            std::lock_guard<std::mutex> dlk(m_doneMutex);
            m_doneCv.notify_all();
        }
    }
}

void FX160::asyncWorkerLoop(uint32_t queueIdx) {
    while (true) {
        std::function<void()> job;
        {
            std::unique_lock<std::mutex> lk(m_asyncMutex[queueIdx]);
            m_asyncCv[queueIdx].wait(lk, [this, queueIdx]{
                return !m_asyncQueues[queueIdx].empty()
                    || m_asyncShutdown.load();
            });
            if (m_asyncShutdown.load() && m_asyncQueues[queueIdx].empty())
                return;
            job = std::move(m_asyncQueues[queueIdx].front());
            m_asyncQueues[queueIdx].pop();
        }
        job();
    }
}

void FX160::submitJob(std::function<void()> job) {
    m_pendingJobs.fetch_add(1, std::memory_order_acq_rel);
    {
        std::unique_lock<std::mutex> lk(m_jobMutex);
        m_jobQueue.push(std::move(job));
    }
    m_jobCv.notify_one();
}

void FX160::waitAllJobs() {
    if (m_pendingJobs.load(std::memory_order_acquire) == 0) return;
    std::unique_lock<std::mutex> lk(m_doneMutex);
    m_doneCv.wait(lk, [this]{
        return m_pendingJobs.load(std::memory_order_acquire) == 0;
    });
}

void FX160::dispatchCompute(ComputeJob job, uint32_t groupCount) {
    if (!m_ready) return;
    // %50 daha yüksek işlem kapasitesi: grup sayısını 1.5x ile çarp
    uint32_t total = (groupCount == 0)
        ? m_computeUnits
        : static_cast<uint32_t>(groupCount * FX160_SPEC::PROC_CAPACITY_MULT);
    for (uint32_t i = 0; i < total; ++i)
        submitJob([job, i, total]{ job(i, total); });
    waitAllJobs();
}

void FX160::dispatchAsyncCompute(ComputeJob job, uint32_t queueIndex) {
    if (!m_ready) return;
    queueIndex = queueIndex % ASYNC_QUEUES;
    uint32_t groups = m_computeUnits / ASYNC_QUEUES;
    if (groups == 0) groups = 1;
    for (uint32_t i = 0; i < groups; ++i) {
        auto fn = [job, i, groups]{ job(i, groups); };
        {
            std::unique_lock<std::mutex> lk(m_asyncMutex[queueIndex]);
            m_asyncQueues[queueIndex].push(std::move(fn));
        }
        m_asyncCv[queueIndex].notify_one();
    }
}

// =============================================================================
// Bellek yönetimi
// =============================================================================

uint32_t FX160::allocateBuffer(uint64_t bytes) {
    if (!m_ready || bytes == 0) return 0;
    bytes = (bytes + 63u) & ~uint64_t(63);

    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_freeList.lower_bound(bytes);
    if (it != m_freeList.end()) {
        uint64_t offset  = it->second;
        uint64_t blockSz = it->first;
        m_freeList.erase(it);
        if (blockSz - bytes >= 64)
            m_freeList.emplace(blockSz - bytes, offset + bytes);
        uint32_t h = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
        m_buffers[h] = { h, offset, bytes, true };
        return h;
    }
    if (m_vramWatermark + bytes > m_vramSize) return 0;
    uint32_t h = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
    m_buffers[h] = { h, m_vramWatermark, bytes, true };
    m_vramWatermark += bytes;
    return h;
}

void FX160::freeBuffer(uint32_t handle) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end()) return;
    BufferAlloc& b = it->second;
    b.inUse = false;
    m_freeList.emplace(b.size, b.offset);
    m_buffers.erase(it);
}

bool FX160::uploadData(uint32_t handle, const void* data, uint64_t bytes) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end() || !it->second.inUse) return false;
    if (bytes > it->second.size) return false;
    std::memcpy(m_vramPool.get() + it->second.offset, data,
                static_cast<size_t>(bytes));
    return true;
}

bool FX160::readbackData(uint32_t handle, void* out, uint64_t bytes) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end() || !it->second.inUse) return false;
    if (bytes > it->second.size) return false;
    std::memcpy(out, m_vramPool.get() + it->second.offset,
                static_cast<size_t>(bytes));
    return true;
}

uint64_t FX160::vramUsed() const {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    return m_vramWatermark;
}

// =============================================================================
// Texture yönetimi
// =============================================================================

uint32_t FX160::createTexture(uint32_t w, uint32_t h, const uint8_t* rgbaData) {
    if (!m_ready || w == 0 || h == 0 || !rgbaData) return 0;
    if (w > m_desc.maxTextureSize || h > m_desc.maxTextureSize) return 0;

    uint64_t bytes     = static_cast<uint64_t>(w) * h * 4;
    uint32_t bufHandle = allocateBuffer(bytes);
    if (!bufHandle) return 0;

    if (!uploadData(bufHandle, rgbaData, bytes)) {
        freeBuffer(bufHandle);
        return 0;
    }

    std::unique_lock<std::shared_mutex> lk(m_texMutex);
    uint32_t th = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
    TextureEntry te;
    te.handle = th; te.width = w; te.height = h; te.valid = true;
    {
        std::unique_lock<std::mutex> vlk(m_vramMutex);
        te.vramOff = m_buffers.at(bufHandle).offset;
    }
    m_textures[th] = te;
    return th;
}

void FX160::destroyTexture(uint32_t handle) {
    std::unique_lock<std::shared_mutex> lk(m_texMutex);
    m_textures.erase(handle);
}

void FX160::sampleTexture(uint32_t handle, float u, float v,
                            uint8_t outRGBA[4]) const {
    outRGBA[0] = outRGBA[1] = outRGBA[2] = outRGBA[3] = 255;
    std::shared_lock<std::shared_mutex> lk(m_texMutex);
    auto it = m_textures.find(handle);
    if (it == m_textures.end() || !it->second.valid) return;
    const TextureEntry& te = it->second;
    u = u - std::floor(u);
    v = v - std::floor(v);
    auto px = static_cast<uint32_t>(u * (te.width  - 1) + 0.5f);
    auto py = static_cast<uint32_t>(v * (te.height - 1) + 0.5f);
    px = std::min(px, te.width  - 1);
    py = std::min(py, te.height - 1);
    const uint8_t* texel = m_vramPool.get() + te.vramOff
                         + (static_cast<uint64_t>(py) * te.width + px) * 4;
    outRGBA[0] = texel[0]; outRGBA[1] = texel[1];
    outRGBA[2] = texel[2]; outRGBA[3] = texel[3];
}

// =============================================================================
// Render target
// =============================================================================

bool FX160::createRenderTarget(RenderTarget& rt, uint32_t w, uint32_t h) {
    rt.width = w; rt.height = h;
    uint64_t colorBytes   = static_cast<uint64_t>(w) * h * 4;
    uint64_t depthBytes   = static_cast<uint64_t>(w) * h * sizeof(float);
    uint64_t stencilBytes = static_cast<uint64_t>(w) * h;

#if defined(_MSC_VER) || defined(__MINGW32__)
    rt.colorBuffer   = static_cast<uint8_t*>(
        _aligned_malloc(static_cast<size_t>(colorBytes),   64));
    rt.depthBuffer   = static_cast<float*>(
        _aligned_malloc(static_cast<size_t>(depthBytes),   64));
    rt.stencilBuffer = static_cast<uint8_t*>(
        _aligned_malloc(static_cast<size_t>(stencilBytes), 64));
#else
    void *cp = nullptr, *dp = nullptr, *sp = nullptr;
    posix_memalign(&cp, 64, static_cast<size_t>(colorBytes));
    posix_memalign(&dp, 64, static_cast<size_t>(depthBytes));
    posix_memalign(&sp, 64, static_cast<size_t>(stencilBytes));
    rt.colorBuffer   = static_cast<uint8_t*>(cp);
    rt.depthBuffer   = static_cast<float*>(dp);
    rt.stencilBuffer = static_cast<uint8_t*>(sp);
#endif

    if (!rt.colorBuffer || !rt.depthBuffer || !rt.stencilBuffer) {
        destroyRenderTarget(rt); return false;
    }
    clearRenderTarget(rt, 0.f, 0.f, 0.f, 1.f);
    return true;
}

void FX160::destroyRenderTarget(RenderTarget& rt) {
#if defined(_MSC_VER) || defined(__MINGW32__)
    if (rt.colorBuffer)   { _aligned_free(rt.colorBuffer);   rt.colorBuffer   = nullptr; }
    if (rt.depthBuffer)   { _aligned_free(rt.depthBuffer);   rt.depthBuffer   = nullptr; }
    if (rt.stencilBuffer) { _aligned_free(rt.stencilBuffer); rt.stencilBuffer = nullptr; }
#else
    if (rt.colorBuffer)   { free(rt.colorBuffer);   rt.colorBuffer   = nullptr; }
    if (rt.depthBuffer)   { free(rt.depthBuffer);   rt.depthBuffer   = nullptr; }
    if (rt.stencilBuffer) { free(rt.stencilBuffer); rt.stencilBuffer = nullptr; }
#endif
    rt.width = rt.height = 0;
}

void FX160::clearRenderTarget(RenderTarget& rt, float r, float g, float b, float a) {
    if (!rt.colorBuffer) return;
    uint64_t pixels = static_cast<uint64_t>(rt.width) * rt.height;
    uint32_t rgba32 = toU8_160(r) | (toU8_160(g) << 8)
                    | (toU8_160(b) << 16) | (toU8_160(a) << 24);
    simdClear(rt.colorBuffer, pixels, rgba32);
    if (rt.depthBuffer)   simdClearFloat(rt.depthBuffer, pixels, 1.0f);
    if (rt.stencilBuffer) std::memset(rt.stencilBuffer, 0,
                                      static_cast<size_t>(pixels));
}

// =============================================================================
// SIMD yardımcıları
// =============================================================================

void FX160::simdClear(uint8_t* buf, uint64_t pixels, uint32_t rgba32) const {
#if defined(__AVX2__) || defined(_MSC_VER)
    if (m_hasAVX2) {
        __m256i v = _mm256_set1_epi32(static_cast<int>(rgba32));
        uint32_t* p = reinterpret_cast<uint32_t*>(buf);
        uint64_t i = 0;
        for (; i + 8 <= pixels; i += 8)
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(p + i), v);
        for (; i < pixels; ++i) p[i] = rgba32;
        return;
    }
#endif
    uint32_t* p = reinterpret_cast<uint32_t*>(buf);
    for (uint64_t i = 0; i < pixels; ++i) p[i] = rgba32;
}

void FX160::simdClearFloat(float* buf, uint64_t count, float val) const {
#if defined(__AVX2__) || defined(_MSC_VER)
    if (m_hasAVX2) {
        __m256 v = _mm256_set1_ps(val);
        uint64_t i = 0;
        for (; i + 8 <= count; i += 8)
            _mm256_storeu_ps(buf + i, v);
        for (; i < count; ++i) buf[i] = val;
        return;
    }
#endif
    for (uint64_t i = 0; i < count; ++i) buf[i] = val;
}

// =============================================================================
// Shader setter'lar
// =============================================================================

void FX160::setVertexShader  (VertexShaderFn  vs) { m_vs = vs ? vs : VertexShaderFn(defaultVS);   }
void FX160::setFragmentShader(FragmentShaderFn fs) { m_fs = fs ? fs : FragmentShaderFn(defaultFS); }

void FX160::setUniforms(const float* data, uint32_t count) {
    count = std::min(count, (uint32_t)FX160_SPEC::MAX_UNIFORMS);
    std::memcpy(m_uniforms, data, count * sizeof(float));
    m_uniformCount = count;
}

// =============================================================================
// Rasterizer — 32px tile (FX150: 64px)
// =============================================================================

void FX160::rasterizeTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2,
                               RenderTarget& rt, const RasterTile& tile) {
    float minX = std::min({v0.x, v1.x, v2.x});
    float maxX = std::max({v0.x, v1.x, v2.x});
    float minY = std::min({v0.y, v1.y, v2.y});
    float maxY = std::max({v0.y, v1.y, v2.y});

    int x0 = std::max(static_cast<int>(std::floor(minX)), static_cast<int>(tile.x0));
    int x1 = std::min(static_cast<int>(std::ceil (maxX)), static_cast<int>(tile.x1) - 1);
    int y0 = std::max(static_cast<int>(std::floor(minY)), static_cast<int>(tile.y0));
    int y1 = std::min(static_cast<int>(std::ceil (maxY)), static_cast<int>(tile.y1) - 1);

    if (x0 > x1 || y0 > y1) return;

    float area = edgeFn160(v0, v1, v2.x, v2.y);
    if (std::fabs(area) < 1e-6f) return;
    float invArea = 1.f / area;

    for (int py = y0; py <= y1; ++py) {
        for (int px = x0; px <= x1; ++px) {
            float fx = static_cast<float>(px) + 0.5f;
            float fy = static_cast<float>(py) + 0.5f;
            float w0 = edgeFn160(v1, v2, fx, fy) * invArea;
            float w1 = edgeFn160(v2, v0, fx, fy) * invArea;
            float w2 = 1.f - w0 - w1;
            if (w0 < 0.f || w1 < 0.f || w2 < 0.f) continue;
            float z = w0 * v0.z + w1 * v1.z + w2 * v2.z;
            uint64_t pixIdx = static_cast<uint64_t>(py) * rt.width + px;
            if (rt.depthBuffer && z >= rt.depthBuffer[pixIdx]) continue;
            if (rt.depthBuffer) rt.depthBuffer[pixIdx] = z;
            Vertex interp;
            interp.x = fx; interp.y = fy; interp.z = z; interp.w = 1.f;
            interp.r = w0*v0.r + w1*v1.r + w2*v2.r;
            interp.g = w0*v0.g + w1*v1.g + w2*v2.g;
            interp.b = w0*v0.b + w1*v1.b + w2*v2.b;
            interp.a = w0*v0.a + w1*v1.a + w2*v2.a;
            interp.u = w0*v0.u + w1*v1.u + w2*v2.u;
            interp.v = w0*v0.v + w1*v1.v + w2*v2.v;
            interp.nx = w0*v0.nx + w1*v1.nx + w2*v2.nx;
            interp.ny = w0*v0.ny + w1*v1.ny + w2*v2.ny;
            interp.nz = w0*v0.nz + w1*v1.nz + w2*v2.nz;
            uint8_t frag[4];
            m_fs(fx, fy, interp, m_uniforms, frag);
            uint8_t* dst = rt.colorBuffer + pixIdx * 4;
            if (interp.a < 1.f - 1e-4f) {
                float srcA = frag[3] / 255.f, dstA = 1.f - srcA;
                dst[0] = static_cast<uint8_t>(frag[0]*srcA + dst[0]*dstA);
                dst[1] = static_cast<uint8_t>(frag[1]*srcA + dst[1]*dstA);
                dst[2] = static_cast<uint8_t>(frag[2]*srcA + dst[2]*dstA);
                dst[3] = 255;
            } else {
                dst[0]=frag[0]; dst[1]=frag[1]; dst[2]=frag[2]; dst[3]=frag[3];
            }
        }
    }
}

void FX160::drawTiled(const DrawCall& dc, RenderTarget& rt) {
    std::vector<Vertex> xfVerts(dc.vertexCount);
    for (uint32_t i = 0; i < dc.vertexCount; ++i) {
        xfVerts[i] = m_vs(dc.vertices[i], m_uniforms);
        xfVerts[i].x = (xfVerts[i].x * 0.5f + 0.5f) * rt.width;
        xfVerts[i].y = (1.f - (xfVerts[i].y * 0.5f + 0.5f)) * rt.height;
    }
    uint32_t triCount = dc.indexCount / 3;
    struct TriBBox { float minX, minY, maxX, maxY; };
    std::vector<TriBBox> triBBoxes(triCount);
    for (uint32_t tri = 0; tri < triCount; ++tri) {
        const Vertex& a = xfVerts[dc.indices[tri*3+0]];
        const Vertex& b = xfVerts[dc.indices[tri*3+1]];
        const Vertex& c = xfVerts[dc.indices[tri*3+2]];
        triBBoxes[tri] = { std::min({a.x,b.x,c.x}), std::min({a.y,b.y,c.y}),
                           std::max({a.x,b.x,c.x}), std::max({a.y,b.y,c.y}) };
    }
    const uint32_t TS = FX160_SPEC::TILE_SIZE; // 32px
    uint32_t numTilesX = (rt.width  + TS - 1) / TS;
    uint32_t numTilesY = (rt.height + TS - 1) / TS;
    for (uint32_t ty = 0; ty < numTilesY; ++ty) {
        for (uint32_t tx = 0; tx < numTilesX; ++tx) {
            RasterTile tile;
            tile.x0 = tx * TS; tile.y0 = ty * TS;
            tile.x1 = std::min(tile.x0 + TS, rt.width);
            tile.y1 = std::min(tile.y0 + TS, rt.height);
            std::vector<uint32_t> tileTriangles;
            tileTriangles.reserve(8);
            for (uint32_t tri = 0; tri < triCount; ++tri) {
                const TriBBox& bb = triBBoxes[tri];
                if (bb.maxX < static_cast<float>(tile.x0) ||
                    bb.minX > static_cast<float>(tile.x1)) continue;
                if (bb.maxY < static_cast<float>(tile.y0) ||
                    bb.minY > static_cast<float>(tile.y1)) continue;
                tileTriangles.push_back(tri);
            }
            if (tileTriangles.empty()) continue;
            submitJob([this, tile, tris = std::move(tileTriangles),
                       &dc, &xfVerts, &rt]() {
                for (uint32_t tri : tris) {
                    rasterizeTriangle(xfVerts[dc.indices[tri*3+0]],
                                      xfVerts[dc.indices[tri*3+1]],
                                      xfVerts[dc.indices[tri*3+2]],
                                      rt, tile);
                }
            });
        }
    }
    waitAllJobs();
    std::unique_lock<std::mutex> lk(m_statsMutex);
    m_stats.drawCallsPerFrame++;
    m_stats.trianglesPerFrame += triCount;
}

bool FX160::draw(const DrawCall& dc, RenderTarget& rt) {
    if (!m_ready) return false;
    if (!dc.vertices || dc.vertexCount == 0) return false;
    if (!dc.indices  || dc.indexCount  == 0) return false;
    if (!rt.colorBuffer) return false;
    m_thermalLoad.store(0.55f, std::memory_order_relaxed);
    drawTiled(dc, rt);
    m_thermalLoad.store(0.18f, std::memory_order_relaxed);
    return true;
}

void FX160::present(const RenderTarget& rt, void* destPixels, uint32_t destStride) {
    if (!rt.colorBuffer || !destPixels) return;
    const uint32_t rowBytes = rt.width * 4;
    const uint8_t* src = rt.colorBuffer;
          uint8_t* dst = static_cast<uint8_t*>(destPixels);
    if (destStride == rowBytes) {
        std::memcpy(dst, src, static_cast<size_t>(rt.height) * rowBytes);
    } else {
        for (uint32_t y = 0; y < rt.height; ++y)
            std::memcpy(dst + static_cast<size_t>(y) * destStride,
                        src + static_cast<size_t>(y) * rowBytes, rowBytes);
    }
    std::unique_lock<std::mutex> lk(m_statsMutex);
    m_stats.framesRendered++;
    m_stats.vramUsed = m_vramWatermark;
    double now = nowMs();
    double elapsed = now - m_frameStart;
    m_stats.gpuTimeMs = elapsed;
    m_stats.fps = elapsed > 0.0 ? 1000.0 / elapsed : 0.0;
    m_frameStart = now;
    m_stats.drawCallsPerFrame = 0;
    m_stats.trianglesPerFrame = 0;
}

// =============================================================================
// Sorgular
// =============================================================================

const GPUDescriptor& FX160::descriptor() const { return m_desc; }

GPUStats FX160::queryStats() const {
    std::unique_lock<std::mutex> lk(m_statsMutex);
    GPUStats s = m_stats;
    s.activeThreads = m_computeUnits;
    s.vramUsed      = m_vramWatermark;
    return s;
}

float FX160::simulatedTemperature() const {
    float load = m_thermalLoad.load(std::memory_order_relaxed);
    return FX160_SPEC::IDLE_TEMP_C
         + load * (FX160_SPEC::MAX_TEMP_C - FX160_SPEC::IDLE_TEMP_C);
}

float FX160::simulatedPowerDraw() const {
    return m_thermalLoad.load(std::memory_order_relaxed) * FX160_SPEC::TDP_WATTS;
}

std::string FX160::dumpMemoryMap() const {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    oss << "=== OMURG FX160 VRAM MAP (v1.2.0) ===\n";
    oss << "Pool size  : 0x" << std::setw(16) << m_vramSize     << "\n";
    oss << "Watermark  : 0x" << std::setw(16) << m_vramWatermark << "\n";
    oss << "Freelist   : " << std::dec << m_freeList.size() << " blok\n";
    oss << "CPU Boost  : x" << FX160_SPEC::CPU_COMPAT_BOOST << "\n";
    oss << "Proc Mult  : x" << FX160_SPEC::PROC_CAPACITY_MULT << "\n";
    oss << "Buffers    :\n";
    for (const auto& [h, b] : m_buffers) {
        oss << "  [" << std::dec << std::setw(5) << h << "] "
            << (b.inUse ? "LIVE  " : "FREE  ")
            << "off=0x" << std::hex << std::setw(12) << b.offset
            << " size=0x" << std::setw(10) << b.size << "\n";
    }
    oss << "Freelist blocks:\n";
    for (const auto& [sz, off] : m_freeList) {
        oss << "  size=0x" << std::setw(10) << sz
            << " off=0x"  << std::setw(12) << off << "\n";
    }
    return oss.str();
}
