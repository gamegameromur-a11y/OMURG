// =============================================================================
// OMURG - FX1X0.cpp  [FX170 / FX180 / FX190 shared implementation]
// =============================================================================
#include "FX1X0.h"

#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>

#if defined(_MSC_VER)
#   include <intrin.h>
#   include <immintrin.h>
#elif defined(__GNUC__) || defined(__clang__)
#   include <immintrin.h>
#   include <cpuid.h>
#endif

static bool cpuHasAVX2_1x0() {
    static const bool r = []() -> bool {
#if defined(_MSC_VER)
        int info[4] = {};
        __cpuidex(info, 7, 0);
        return (info[1] & (1 << 5)) != 0;
#elif defined(__GNUC__) || defined(__clang__)
        unsigned eax, ebx, ecx, edx;
        if (__get_cpuid_count(7, 0, &eax, &ebx, &ecx, &edx))
            return (ebx & (1u << 5)) != 0;
        return false;
#else
        return false;
#endif
    }();
    return r;
}

static inline float edge1x0(const Vertex& a, const Vertex& b, float px, float py) {
    return (px - a.x)*(b.y - a.y) - (py - a.y)*(b.x - a.x);
}
static inline uint8_t u8_1x0(float f) {
    int i = (int)(f*255.f + 0.5f);
    return (uint8_t)(i < 0 ? 0 : i > 255 ? 255 : i);
}

// =============================================================================
// Constructor
// =============================================================================
FX1X0Base::FX1X0Base(const char* modelName,
                     uint64_t vramBytes,
                     uint32_t computeUnits,
                     uint32_t clockMHz,
                     float tdpWatts,
                     float idleTemp,
                     float maxTemp,
                     float cpuBoost,
                     float procMult)
    : m_cpuBoost(cpuBoost)
    , m_procMult(procMult)
    , m_tdpWatts(tdpWatts)
    , m_idleTemp(idleTemp)
    , m_maxTemp(maxTemp)
    , m_hasAVX2(cpuHasAVX2_1x0())
    , m_vramSize(vramBytes)
    , m_computeUnits(computeUnits == 0
        ? std::max(14u, (uint32_t)(std::thread::hardware_concurrency() * cpuBoost))
        : computeUnits)
{
    if (m_computeUnits > 128) m_computeUnits = 128;

    m_desc.modelName        = modelName;
    m_desc.vendorName       = "OMURG Virtual Hardware";
    m_desc.driverVersion    = "1.0.0";
    m_desc.vramBytes        = vramBytes;
    m_desc.computeUnits     = m_computeUnits;
    m_desc.clockSpeedMHz    = clockMHz;
    m_desc.maxTextureSize   = 16384;
    m_desc.maxRenderTargets = 16;
    m_desc.features         = GPUFeature::RASTERIZATION
                            | GPUFeature::DEPTH_BUFFER
                            | GPUFeature::STENCIL_BUFFER
                            | GPUFeature::TEXTURE_2D
                            | GPUFeature::TEXTURE_CUBE
                            | GPUFeature::MIPMAPPING
                            | GPUFeature::MSAA
                            | GPUFeature::COMPUTE_SHADERS
                            | GPUFeature::GEOMETRY_SHADER
                            | GPUFeature::TESSELLATION
                            | GPUFeature::ASYNC_COMPUTE
                            | GPUFeature::SIMD_SSE4
                            | (m_hasAVX2 ? GPUFeature::SIMD_AVX2
                                         : GPUFeature::NONE);

    m_vs = FX1X0Base::defaultVS;
    m_fs = FX1X0Base::defaultFS;
}

FX1X0Base::~FX1X0Base() { shutdown(); }

// =============================================================================
// Lifecycle
// =============================================================================
bool FX1X0Base::initialize() {
    if (m_ready) return true;

#if defined(_MSC_VER) || defined(__MINGW32__)
    m_vramPool.reset((uint8_t*)_aligned_malloc((size_t)m_vramSize, 64));
#else
    void* ptr = nullptr;
    posix_memalign(&ptr, 64, (size_t)m_vramSize);
    m_vramPool.reset((uint8_t*)ptr);
#endif
    if (!m_vramPool) {
        try { m_vramPool = std::make_unique<uint8_t[]>((size_t)m_vramSize); }
        catch (...) { return false; }
    }
    std::memset(m_vramPool.get(), 0, (size_t)m_vramSize);
    m_vramWatermark = 0;
    m_freeList.clear();

    // Main pool
    m_shutdown.store(false);
    m_workers.reserve(m_computeUnits);
    for (uint32_t i = 0; i < m_computeUnits; ++i)
        m_workers.emplace_back([this, i]{ workerLoop(i); });

    // Async queues
    m_asyncShutdown.store(false);
    for (int q = 0; q < ASYNC_Q; ++q)
        for (int w = 0; w < 4; ++w)
            m_asyncWorkers[q].emplace_back([this, q]{ asyncWorkerLoop(q); });

    m_ready = true;
    m_desc.vramBytes    = m_vramSize;
    m_desc.computeUnits = m_computeUnits;
    return true;
}

void FX1X0Base::shutdown() {
    if (!m_ready) return;
    { std::unique_lock<std::mutex> lk(m_jobMutex); m_shutdown.store(true); }
    m_jobCv.notify_all();
    for (auto& t : m_workers) if (t.joinable()) t.join();
    m_workers.clear();

    m_asyncShutdown.store(true);
    for (int q = 0; q < ASYNC_Q; ++q) {
        m_asyncCv[q].notify_all();
        for (auto& t : m_asyncWorkers[q]) if (t.joinable()) t.join();
        m_asyncWorkers[q].clear();
    }

#if defined(_MSC_VER) || defined(__MINGW32__)
    if (m_vramPool) _aligned_free(m_vramPool.release());
#else
    m_vramPool.reset();
#endif
    m_vramWatermark = 0; m_freeList.clear();
    m_buffers.clear();  m_textures.clear();
    m_ready = false;
}

// =============================================================================
// Thread pool
// =============================================================================
void FX1X0Base::workerLoop(uint32_t) {
    while (true) {
        std::function<void()> job;
        { std::unique_lock<std::mutex> lk(m_jobMutex);
          m_jobCv.wait(lk, [this]{ return !m_jobQueue.empty() || m_shutdown.load(); });
          if (m_shutdown.load() && m_jobQueue.empty()) return;
          job = std::move(m_jobQueue.front()); m_jobQueue.pop(); }
        job();
        if (m_pendingJobs.fetch_sub(1, std::memory_order_acq_rel) == 1) {
            std::lock_guard<std::mutex> dlk(m_doneMutex);
            m_doneCv.notify_all();
        }
    }
}

void FX1X0Base::asyncWorkerLoop(uint32_t q) {
    while (true) {
        std::function<void()> job;
        { std::unique_lock<std::mutex> lk(m_asyncMutex[q]);
          m_asyncCv[q].wait(lk, [this, q]{ return !m_asyncQueues[q].empty() || m_asyncShutdown.load(); });
          if (m_asyncShutdown.load() && m_asyncQueues[q].empty()) return;
          job = std::move(m_asyncQueues[q].front()); m_asyncQueues[q].pop(); }
        job();
    }
}

void FX1X0Base::submitJob(std::function<void()> job) {
    m_pendingJobs.fetch_add(1, std::memory_order_acq_rel);
    { std::unique_lock<std::mutex> lk(m_jobMutex); m_jobQueue.push(std::move(job)); }
    m_jobCv.notify_one();
}

void FX1X0Base::waitAllJobs() {
    if (m_pendingJobs.load(std::memory_order_acquire) == 0) return;
    std::unique_lock<std::mutex> lk(m_doneMutex);
    m_doneCv.wait(lk, [this]{ return m_pendingJobs.load(std::memory_order_acquire) == 0; });
}

void FX1X0Base::dispatchCompute(ComputeJob job, uint32_t groupCount) {
    if (!m_ready) return;
    uint32_t total = (groupCount == 0)
        ? m_computeUnits
        : (uint32_t)(groupCount * m_procMult);
    for (uint32_t i = 0; i < total; ++i)
        submitJob([job, i, total]{ job(i, total); });
    waitAllJobs();
}

void FX1X0Base::dispatchAsyncCompute(ComputeJob job, uint32_t queueIndex) {
    if (!m_ready) return;
    queueIndex %= ASYNC_Q;
    uint32_t groups = std::max(1u, m_computeUnits / ASYNC_Q);
    for (uint32_t i = 0; i < groups; ++i) {
        auto fn = [job, i, groups]{ job(i, groups); };
        { std::unique_lock<std::mutex> lk(m_asyncMutex[queueIndex]);
          m_asyncQueues[queueIndex].push(std::move(fn)); }
        m_asyncCv[queueIndex].notify_one();
    }
}

// =============================================================================
// Memory management
// =============================================================================
uint32_t FX1X0Base::allocateBuffer(uint64_t bytes) {
    if (!m_ready || bytes == 0) return 0;
    bytes = (bytes + 63u) & ~uint64_t(63);
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_freeList.lower_bound(bytes);
    if (it != m_freeList.end()) {
        uint64_t off = it->second, sz = it->first;
        m_freeList.erase(it);
        if (sz - bytes >= 64) m_freeList.emplace(sz - bytes, off + bytes);
        uint32_t h = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
        m_buffers[h] = { h, off, bytes, true };
        return h;
    }
    if (m_vramWatermark + bytes > m_vramSize) return 0;
    uint32_t h = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
    m_buffers[h] = { h, m_vramWatermark, bytes, true };
    m_vramWatermark += bytes;
    return h;
}

void FX1X0Base::freeBuffer(uint32_t handle) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end()) return;
    m_freeList.emplace(it->second.size, it->second.offset);
    m_buffers.erase(it);
}

bool FX1X0Base::uploadData(uint32_t handle, const void* data, uint64_t bytes) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end() || !it->second.inUse || bytes > it->second.size) return false;
    std::memcpy(m_vramPool.get() + it->second.offset, data, (size_t)bytes);
    return true;
}

bool FX1X0Base::readbackData(uint32_t handle, void* out, uint64_t bytes) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end() || !it->second.inUse || bytes > it->second.size) return false;
    std::memcpy(out, m_vramPool.get() + it->second.offset, (size_t)bytes);
    return true;
}

uint64_t FX1X0Base::vramUsed() const {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    return m_vramWatermark;
}

// =============================================================================
// Texture management
// =============================================================================
uint32_t FX1X0Base::createTexture(uint32_t w, uint32_t h, const uint8_t* rgba) {
    if (!m_ready || !w || !h || !rgba) return 0;
    uint64_t bytes = (uint64_t)w * h * 4;
    uint32_t bh = allocateBuffer(bytes);
    if (!bh) return 0;
    if (!uploadData(bh, rgba, bytes)) { freeBuffer(bh); return 0; }
    std::unique_lock<std::shared_mutex> lk(m_texMutex);
    uint32_t th = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
    TextureEntry te; te.handle=th; te.width=w; te.height=h; te.valid=true;
    { std::unique_lock<std::mutex> vlk(m_vramMutex); te.vramOff=m_buffers.at(bh).offset; }
    m_textures[th] = te;
    return th;
}

void FX1X0Base::destroyTexture(uint32_t handle) {
    std::unique_lock<std::shared_mutex> lk(m_texMutex);
    m_textures.erase(handle);
}

void FX1X0Base::sampleTexture(uint32_t handle, float u, float v, uint8_t out[4]) const {
    out[0]=out[1]=out[2]=out[3]=255;
    std::shared_lock<std::shared_mutex> lk(m_texMutex);
    auto it = m_textures.find(handle);
    if (it == m_textures.end() || !it->second.valid) return;
    const TextureEntry& te = it->second;
    u -= std::floor(u); v -= std::floor(v);
    uint32_t px = std::min((uint32_t)(u*(te.width -1)+.5f), te.width -1);
    uint32_t py = std::min((uint32_t)(v*(te.height-1)+.5f), te.height-1);
    const uint8_t* t = m_vramPool.get()+te.vramOff+((uint64_t)py*te.width+px)*4;
    out[0]=t[0]; out[1]=t[1]; out[2]=t[2]; out[3]=t[3];
}

// =============================================================================
// Render target
// =============================================================================
bool FX1X0Base::createRenderTarget(RenderTarget& rt, uint32_t w, uint32_t h) {
    rt.width=w; rt.height=h;
    size_t cb=(size_t)w*h*4, db=(size_t)w*h*sizeof(float), sb=(size_t)w*h;
#if defined(_MSC_VER)||defined(__MINGW32__)
    rt.colorBuffer  =(uint8_t*)_aligned_malloc(cb,64);
    rt.depthBuffer  =(float*)  _aligned_malloc(db,64);
    rt.stencilBuffer=(uint8_t*)_aligned_malloc(sb,64);
#else
    void *cp=nullptr,*dp=nullptr,*sp=nullptr;
    posix_memalign(&cp,64,cb); posix_memalign(&dp,64,db); posix_memalign(&sp,64,sb);
    rt.colorBuffer=(uint8_t*)cp; rt.depthBuffer=(float*)dp; rt.stencilBuffer=(uint8_t*)sp;
#endif
    if (!rt.colorBuffer||!rt.depthBuffer||!rt.stencilBuffer) { destroyRenderTarget(rt); return false; }
    clearRenderTarget(rt,0,0,0,1);
    return true;
}

void FX1X0Base::destroyRenderTarget(RenderTarget& rt) {
#if defined(_MSC_VER)||defined(__MINGW32__)
    if (rt.colorBuffer)   { _aligned_free(rt.colorBuffer);   rt.colorBuffer=nullptr; }
    if (rt.depthBuffer)   { _aligned_free(rt.depthBuffer);   rt.depthBuffer=nullptr; }
    if (rt.stencilBuffer) { _aligned_free(rt.stencilBuffer); rt.stencilBuffer=nullptr; }
#else
    if (rt.colorBuffer)   { free(rt.colorBuffer);   rt.colorBuffer=nullptr; }
    if (rt.depthBuffer)   { free(rt.depthBuffer);   rt.depthBuffer=nullptr; }
    if (rt.stencilBuffer) { free(rt.stencilBuffer); rt.stencilBuffer=nullptr; }
#endif
    rt.width=rt.height=0;
}

void FX1X0Base::clearRenderTarget(RenderTarget& rt, float r, float g, float b, float a) {
    if (!rt.colorBuffer) return;
    uint64_t pixels = (uint64_t)rt.width * rt.height;
    uint32_t rgba32 = u8_1x0(r)|(u8_1x0(g)<<8)|(u8_1x0(b)<<16)|(u8_1x0(a)<<24);
    simdClear(rt.colorBuffer, pixels, rgba32);
    if (rt.depthBuffer)   simdClearFloat(rt.depthBuffer, pixels, 1.0f);
    if (rt.stencilBuffer) std::memset(rt.stencilBuffer, 0, (size_t)pixels);
}

// =============================================================================
// SIMD
// =============================================================================
void FX1X0Base::simdClear(uint8_t* buf, uint64_t pixels, uint32_t rgba32) const {
#if defined(__AVX2__)||defined(_MSC_VER)
    if (m_hasAVX2) {
        __m256i v = _mm256_set1_epi32((int)rgba32);
        uint32_t* p = (uint32_t*)buf; uint64_t i = 0;
        for (; i+8 <= pixels; i+=8) _mm256_storeu_si256((__m256i*)(p+i), v);
        for (; i < pixels; ++i) p[i] = rgba32;
        return;
    }
#endif
    uint32_t* p = (uint32_t*)buf;
    for (uint64_t i = 0; i < pixels; ++i) p[i] = rgba32;
}

void FX1X0Base::simdClearFloat(float* buf, uint64_t count, float val) const {
#if defined(__AVX2__)||defined(_MSC_VER)
    if (m_hasAVX2) {
        __m256 v = _mm256_set1_ps(val); uint64_t i = 0;
        for (; i+8 <= count; i+=8) _mm256_storeu_ps(buf+i, v);
        for (; i < count; ++i) buf[i] = val;
        return;
    }
#endif
    for (uint64_t i = 0; i < count; ++i) buf[i] = val;
}

// =============================================================================
// Shaders
// =============================================================================
void FX1X0Base::setVertexShader  (VertexShaderFn  vs) { m_vs = vs ? vs : VertexShaderFn(defaultVS); }
void FX1X0Base::setFragmentShader(FragmentShaderFn fs) { m_fs = fs ? fs : FragmentShaderFn(defaultFS); }
void FX1X0Base::setUniforms(const float* data, uint32_t count) {
    count = std::min(count, (uint32_t)FX1X0_COMMON::MAX_UNIFORMS);
    std::memcpy(m_uniforms, data, count*sizeof(float));
    m_uniformCount = count;
}

// =============================================================================
// Rasterizer — 16px tile
// =============================================================================
void FX1X0Base::rasterizeTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2,
                                   RenderTarget& rt, const RasterTile& tile) {
    float minX=std::min({v0.x,v1.x,v2.x}), maxX=std::max({v0.x,v1.x,v2.x});
    float minY=std::min({v0.y,v1.y,v2.y}), maxY=std::max({v0.y,v1.y,v2.y});
    int x0=std::max((int)std::floor(minX),(int)tile.x0);
    int x1=std::min((int)std::ceil (maxX),(int)tile.x1-1);
    int y0=std::max((int)std::floor(minY),(int)tile.y0);
    int y1=std::min((int)std::ceil (maxY),(int)tile.y1-1);
    if (x0>x1||y0>y1) return;
    float area = edge1x0(v0,v1,v2.x,v2.y);
    if (std::fabs(area) < 1e-6f) return;
    float inv = 1.f/area;
    for (int py=y0; py<=y1; ++py) {
        for (int px=x0; px<=x1; ++px) {
            float fx=(float)px+.5f, fy=(float)py+.5f;
            float w0=edge1x0(v1,v2,fx,fy)*inv;
            float w1=edge1x0(v2,v0,fx,fy)*inv;
            float w2=1.f-w0-w1;
            if (w0<0||w1<0||w2<0) continue;
            float z=w0*v0.z+w1*v1.z+w2*v2.z;
            uint64_t idx=(uint64_t)py*rt.width+px;
            if (rt.depthBuffer && z>=rt.depthBuffer[idx]) continue;
            if (rt.depthBuffer) rt.depthBuffer[idx]=z;
            Vertex ip;
            ip.x=fx; ip.y=fy; ip.z=z; ip.w=1.f;
            ip.r=w0*v0.r+w1*v1.r+w2*v2.r; ip.g=w0*v0.g+w1*v1.g+w2*v2.g;
            ip.b=w0*v0.b+w1*v1.b+w2*v2.b; ip.a=w0*v0.a+w1*v1.a+w2*v2.a;
            ip.u=w0*v0.u+w1*v1.u+w2*v2.u; ip.v=w0*v0.v+w1*v1.v+w2*v2.v;
            ip.nx=w0*v0.nx+w1*v1.nx+w2*v2.nx;
            ip.ny=w0*v0.ny+w1*v1.ny+w2*v2.ny;
            ip.nz=w0*v0.nz+w1*v1.nz+w2*v2.nz;
            uint8_t frag[4]; m_fs(fx,fy,ip,m_uniforms,frag);
            uint8_t* dst=rt.colorBuffer+idx*4;
            if (ip.a < 1.f-1e-4f) {
                float sa=frag[3]/255.f, da=1.f-sa;
                dst[0]=(uint8_t)(frag[0]*sa+dst[0]*da);
                dst[1]=(uint8_t)(frag[1]*sa+dst[1]*da);
                dst[2]=(uint8_t)(frag[2]*sa+dst[2]*da); dst[3]=255;
            } else { dst[0]=frag[0]; dst[1]=frag[1]; dst[2]=frag[2]; dst[3]=frag[3]; }
        }
    }
}

void FX1X0Base::drawTiled(const DrawCall& dc, RenderTarget& rt) {
    std::vector<Vertex> xv(dc.vertexCount);
    for (uint32_t i = 0; i < dc.vertexCount; ++i) {
        xv[i] = m_vs(dc.vertices[i], m_uniforms);
        xv[i].x = (xv[i].x*.5f+.5f)*rt.width;
        xv[i].y = (1.f-(xv[i].y*.5f+.5f))*rt.height;
    }
    uint32_t tc = dc.indexCount/3;
    struct BB { float x0,y0,x1,y1; };
    std::vector<BB> bb(tc);
    for (uint32_t t=0; t<tc; ++t) {
        const Vertex &a=xv[dc.indices[t*3]],&b=xv[dc.indices[t*3+1]],&c=xv[dc.indices[t*3+2]];
        bb[t]={std::min({a.x,b.x,c.x}),std::min({a.y,b.y,c.y}),
               std::max({a.x,b.x,c.x}),std::max({a.y,b.y,c.y})};
    }
    const uint32_t TS = FX1X0_COMMON::TILE_SIZE;
    uint32_t ntx=(rt.width+TS-1)/TS, nty=(rt.height+TS-1)/TS;
    for (uint32_t ty=0; ty<nty; ++ty) for (uint32_t tx=0; tx<ntx; ++tx) {
        RasterTile tile;
        tile.x0=tx*TS; tile.y0=ty*TS;
        tile.x1=std::min(tile.x0+TS,rt.width);
        tile.y1=std::min(tile.y0+TS,rt.height);
        std::vector<uint32_t> tris;
        for (uint32_t t=0; t<tc; ++t) {
            if (bb[t].x1<(float)tile.x0||bb[t].x0>(float)tile.x1) continue;
            if (bb[t].y1<(float)tile.y0||bb[t].y0>(float)tile.y1) continue;
            tris.push_back(t);
        }
        if (tris.empty()) continue;
        submitJob([this,tile,trs=std::move(tris),&dc,&xv,&rt](){
            for (uint32_t t:trs)
                rasterizeTriangle(xv[dc.indices[t*3]],xv[dc.indices[t*3+1]],
                                   xv[dc.indices[t*3+2]],rt,tile);
        });
    }
    waitAllJobs();
    std::unique_lock<std::mutex> lk(m_statsMutex);
    m_stats.drawCallsPerFrame++; m_stats.trianglesPerFrame+=tc;
}

bool FX1X0Base::draw(const DrawCall& dc, RenderTarget& rt) {
    if (!m_ready||!dc.vertices||!dc.vertexCount||!dc.indices||!dc.indexCount||!rt.colorBuffer) return false;
    m_thermalLoad.store(.50f,std::memory_order_relaxed);
    drawTiled(dc,rt);
    m_thermalLoad.store(.15f,std::memory_order_relaxed);
    return true;
}

void FX1X0Base::present(const RenderTarget& rt, void* dst, uint32_t stride) {
    if (!rt.colorBuffer||!dst) return;
    uint32_t rb=rt.width*4;
    if (stride==rb) std::memcpy(dst,rt.colorBuffer,(size_t)rt.height*rb);
    else for (uint32_t y=0; y<rt.height; ++y)
        std::memcpy((uint8_t*)dst+(size_t)y*stride,rt.colorBuffer+(size_t)y*rb,rb);
    std::unique_lock<std::mutex> lk(m_statsMutex);
    m_stats.framesRendered++; m_stats.vramUsed=m_vramWatermark;
    double now=nowMs(), el=now-m_frameStart;
    m_stats.gpuTimeMs=el; m_stats.fps=el>0.?1000./el:0.;
    m_frameStart=now; m_stats.drawCallsPerFrame=0; m_stats.trianglesPerFrame=0;
}

// =============================================================================
// Queries
// =============================================================================
GPUStats FX1X0Base::queryStats() const {
    std::unique_lock<std::mutex> lk(m_statsMutex);
    GPUStats s=m_stats; s.activeThreads=m_computeUnits; s.vramUsed=m_vramWatermark;
    return s;
}

float FX1X0Base::simulatedTemperature() const {
    float load=m_thermalLoad.load(std::memory_order_relaxed);
    return m_idleTemp + load*(m_maxTemp-m_idleTemp);
}

float FX1X0Base::simulatedPowerDraw() const {
    return m_thermalLoad.load(std::memory_order_relaxed)*m_tdpWatts;
}

std::string FX1X0Base::dumpMemoryMap() const {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    std::ostringstream o; o<<std::hex<<std::setfill('0');
    o<<"=== "<<m_desc.modelName<<" VRAM MAP ===\n";
    o<<"Pool    : 0x"<<std::setw(16)<<m_vramSize<<"\n";
    o<<"Wmark   : 0x"<<std::setw(16)<<m_vramWatermark<<"\n";
    o<<"Freelist: "<<std::dec<<m_freeList.size()<<" blocks\n";
    o<<"CPU Boost: x"<<m_cpuBoost<<"\n";
    o<<"Proc Mult: x"<<m_procMult<<"\n";
    o<<"Buffers:\n";
    for (auto& [h,b]:m_buffers)
        o<<"  ["<<std::dec<<std::setw(5)<<h<<"] "<<(b.inUse?"LIVE ":"FREE ")
          <<"off=0x"<<std::hex<<std::setw(12)<<b.offset
          <<" sz=0x"<<std::setw(10)<<b.size<<"\n";
    return o.str();
}
