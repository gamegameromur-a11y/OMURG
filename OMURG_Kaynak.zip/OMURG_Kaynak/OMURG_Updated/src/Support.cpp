// =============================================================================
// OMURG - Support.cpp
// Support ticket delivery via EmailJS HTTP API (WinINet).
// SMTP kaldırıldı — EmailJS üzerinden doğrudan gönderim.
// =============================================================================

#include "Support.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <wininet.h>
#pragma comment(lib, "wininet.lib")

#include <sstream>
#include <iomanip>
#include <ctime>

// =============================================================================
// Base64
// =============================================================================

static const char B64_CHARS[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

std::string SupportClient::base64Encode(const std::string& input) {
    std::string result;
    result.reserve((input.size() + 2) / 3 * 4);

    const auto* data = reinterpret_cast<const unsigned char*>(input.c_str());
    size_t len = input.size();

    for (size_t i = 0; i < len; i += 3) {
        unsigned char b0 = data[i];
        unsigned char b1 = (i + 1 < len) ? data[i + 1] : 0;
        unsigned char b2 = (i + 2 < len) ? data[i + 2] : 0;

        result += B64_CHARS[(b0 >> 2) & 0x3F];
        result += B64_CHARS[((b0 & 0x3) << 4) | ((b1 >> 4) & 0xF)];
        result += (i + 1 < len) ? B64_CHARS[((b1 & 0xF) << 2) | ((b2 >> 6) & 0x3)] : '=';
        result += (i + 2 < len) ? B64_CHARS[b2 & 0x3F] : '=';
    }
    return result;
}

// =============================================================================
// JSON string escaping
// =============================================================================

std::string SupportClient::jsonEscape(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (unsigned char c : s) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
        }
    }
    return out;
}

// =============================================================================
// System info collector
// =============================================================================

std::string SupportClient::collectSystemInfo() {
    std::ostringstream oss;

    OSVERSIONINFOEXA osvi = { sizeof(osvi) };
#pragma warning(suppress: 4996)
    GetVersionExA(reinterpret_cast<OSVERSIONINFOA*>(&osvi));
    oss << "OS: Windows " << osvi.dwMajorVersion << "."
        << osvi.dwMinorVersion << " Build " << osvi.dwBuildNumber << "\n";

    SYSTEM_INFO si = {};
    GetNativeSystemInfo(&si);
    oss << "CPU Threads: " << si.dwNumberOfProcessors << "\n";
    oss << "Architecture: " << (si.wProcessorArchitecture == 9 ? "x64" : "x86") << "\n";

    MEMORYSTATUSEX mem = { sizeof(mem) };
    GlobalMemoryStatusEx(&mem);
    oss << "RAM Total: "     << (mem.ullTotalPhys / 1024 / 1024) << " MB\n";
    oss << "RAM Available: " << (mem.ullAvailPhys / 1024 / 1024) << " MB\n";

    char name[256] = {};
    DWORD nameLen = sizeof(name);
    GetComputerNameA(name, &nameLen);
    oss << "Machine: " << name << "\n";

    std::time_t t = std::time(nullptr);
    char timeBuf[64];
    std::strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S UTC", std::gmtime(&t));
    oss << "Time: " << timeBuf << "\n";

    return oss.str();
}

// =============================================================================
// Construction
// =============================================================================

SupportClient::SupportClient()  = default;
SupportClient::~SupportClient() = default;

// =============================================================================
// JSON payload builder for EmailJS
// =============================================================================

std::string SupportClient::buildJsonPayload(const SupportTicket& ticket) {
    // Full message body with system info appended
    std::string fullMessage = ticket.body;
    if (!ticket.osInfo.empty()) {
        fullMessage += "\n\n--- System Info ---\n" + ticket.osInfo;
    }
    if (!ticket.logDump.empty()) {
        fullMessage += "\n\n--- Log (base64) ---\n" + base64Encode(ticket.logDump);
    }

    std::ostringstream oss;
    oss << "{"
        << "\"service_id\":\""  << EMAILJS_SERVICE_ID  << "\","
        << "\"template_id\":\"" << EMAILJS_TEMPLATE_ID << "\","
        << "\"user_id\":\""     << EMAILJS_PUBLIC_KEY  << "\","
        << "\"template_params\":{"
        <<   "\"from_name\":\""    << jsonEscape(ticket.senderName)    << "\","
        <<   "\"from_email\":\""   << jsonEscape(ticket.senderEmail)   << "\","
        <<   "\"subject\":\""      << jsonEscape(ticket.subject)       << "\","
        <<   "\"message\":\""      << jsonEscape(fullMessage)          << "\","
        <<   "\"gpu_model\":\""    << jsonEscape(ticket.gpuModel)      << "\","
        <<   "\"driver_ver\":\""   << jsonEscape(ticket.driverVersion) << "\""
        << "}"
        << "}";
    return oss.str();
}

// =============================================================================
// HTTP POST via WinINet
// =============================================================================

MailResult SupportClient::postToEmailJS(const std::string& jsonPayload) {
    // Parse URL components
    // URL: https://api.emailjs.com/api/v1.0/email/send
    const char* host = "api.emailjs.com";
    const char* path = "/api/v1.0/email/send";
    const INTERNET_PORT port = INTERNET_DEFAULT_HTTPS_PORT;

    HINTERNET hNet = InternetOpenA(
        "OMURG-Support/2.0",
        INTERNET_OPEN_TYPE_PRECONFIG,
        nullptr, nullptr, 0);
    if (!hNet)
        return { false, 0, "InternetOpen failed: " + std::to_string(GetLastError()) };

    HINTERNET hConn = InternetConnectA(
        hNet, host, port,
        nullptr, nullptr,
        INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConn) {
        InternetCloseHandle(hNet);
        return { false, 0, "InternetConnect failed: " + std::to_string(GetLastError()) };
    }

    DWORD flags = INTERNET_FLAG_RELOAD
                | INTERNET_FLAG_SECURE
                | INTERNET_FLAG_NO_CACHE_WRITE
                | INTERNET_FLAG_NO_COOKIES;

    HINTERNET hReq = HttpOpenRequestA(
        hConn, "POST", path,
        nullptr, nullptr, nullptr, flags, 0);
    if (!hReq) {
        InternetCloseHandle(hConn);
        InternetCloseHandle(hNet);
        return { false, 0, "HttpOpenRequest failed: " + std::to_string(GetLastError()) };
    }

    // Headers
    std::string headers =
        "Content-Type: application/json\r\n"
        "Origin: http://localhost\r\n";

    BOOL ok = HttpSendRequestA(
        hReq,
        headers.c_str(), static_cast<DWORD>(headers.size()),
        const_cast<char*>(jsonPayload.c_str()),
        static_cast<DWORD>(jsonPayload.size()));

    DWORD statusCode = 0;
    if (ok) {
        DWORD scLen = sizeof(DWORD);
        HttpQueryInfoA(hReq,
            HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
            &statusCode, &scLen, nullptr);
    }

    InternetCloseHandle(hReq);
    InternetCloseHandle(hConn);
    InternetCloseHandle(hNet);

    if (!ok)
        return { false, 0, "HttpSendRequest failed: " + std::to_string(GetLastError()) };

    bool success = (statusCode == 200);
    return {
        success,
        static_cast<int>(statusCode),
        success ? "Destek talebiniz gonderildi." : "EmailJS hatasi, kod: " + std::to_string(statusCode)
    };
}

// =============================================================================
// Public entry point
// =============================================================================

MailResult SupportClient::sendTicket(const SupportTicket& ticket) {
    if (ticket.senderEmail.empty() || ticket.body.empty())
        return { false, 0, "E-posta adresi ve mesaj alani bos birakilamaz." };

    std::string payload = buildJsonPayload(ticket);
    return postToEmailJS(payload);
}
