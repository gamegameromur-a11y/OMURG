// =============================================================================
// OMURG - Updater.cpp
// GitHub auto-updater / driver downloader  (WinINet + bcrypt SHA-256)
// =============================================================================

#include "Updater.h"

// Windows headers must come before WinINet
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <wininet.h>
#include <bcrypt.h>    // SHA-256 without OpenSSL

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "bcrypt.lib")

#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <stdexcept>
#include <cassert>
#include <iomanip>
#include <filesystem>

namespace fs = std::filesystem;

// =============================================================================
// Construction
// =============================================================================

Updater::Updater(std::string manifestUrl)
    : m_manifestUrl(std::move(manifestUrl))
    , m_driversDir (DRIVERS_DIR)
    , m_userAgent  ("OMURG-Updater/1.0")
{}

Updater::~Updater() {
    cancelAsync();
    if (m_asyncThread.joinable())
        m_asyncThread.join();
}

// =============================================================================
// Ensure drivers directory
// =============================================================================

void Updater::ensureDriversDir(const std::string& dir) {
    fs::create_directories(dir);
}

// =============================================================================
// WinINet HTTP GET → std::string
// =============================================================================

std::string Updater::httpGet(const std::string& url) {
    HINTERNET hNet = InternetOpenA(
        m_userAgent.c_str(),
        INTERNET_OPEN_TYPE_PRECONFIG,
        nullptr, nullptr, 0);
    if (!hNet) return {};

    HINTERNET hUrl = InternetOpenUrlA(
        hNet,
        url.c_str(),
        nullptr, 0,
        INTERNET_FLAG_RELOAD | INTERNET_FLAG_SECURE |
        INTERNET_FLAG_NO_CACHE_WRITE,
        0);

    std::string result;

    if (hUrl) {
        char buffer[4096];
        DWORD bytesRead = 0;
        while (InternetReadFile(hUrl, buffer, sizeof(buffer), &bytesRead)
               && bytesRead > 0) {
            result.append(buffer, bytesRead);
            if (m_cancel.load()) break;
        }
        InternetCloseHandle(hUrl);
    }

    InternetCloseHandle(hNet);
    return result;
}

// =============================================================================
// WinINet HTTP GET → file (with progress)
// =============================================================================

bool Updater::httpGetToFile(const std::string& url,
                             const std::string& localPath,
                             ProgressCb         progress) {
    HINTERNET hNet = InternetOpenA(
        m_userAgent.c_str(),
        INTERNET_OPEN_TYPE_PRECONFIG,
        nullptr, nullptr, 0);
    if (!hNet) return false;

    HINTERNET hUrl = InternetOpenUrlA(
        hNet, url.c_str(),
        nullptr, 0,
        INTERNET_FLAG_RELOAD | INTERNET_FLAG_SECURE |
        INTERNET_FLAG_NO_CACHE_WRITE,
        0);

    if (!hUrl) {
        InternetCloseHandle(hNet);
        return false;
    }

    // Get content length if available
    DWORD contentLen = 0;
    DWORD bufLen = sizeof(DWORD);
    HttpQueryInfoA(hUrl, HTTP_QUERY_CONTENT_LENGTH | HTTP_QUERY_FLAG_NUMBER,
                   &contentLen, &bufLen, nullptr);

    ensureDriversDir(fs::path(localPath).parent_path().string());

    std::ofstream ofs(localPath, std::ios::binary | std::ios::trunc);
    if (!ofs.is_open()) {
        InternetCloseHandle(hUrl);
        InternetCloseHandle(hNet);
        return false;
    }

    DownloadProgress dp;
    dp.filename    = fs::path(localPath).filename().string();
    dp.totalBytes  = contentLen;

    char buffer[65536];
    DWORD bytesRead = 0;
    bool  ok        = true;

    while (true) {
        if (m_cancel.load()) { ok = false; break; }

        if (!InternetReadFile(hUrl, buffer, sizeof(buffer), &bytesRead)) {
            ok = false; break;
        }
        if (bytesRead == 0) break;  // EOF

        ofs.write(buffer, bytesRead);
        dp.bytesReceived += bytesRead;

        if (progress) progress(dp);
    }

    ofs.close();
    InternetCloseHandle(hUrl);
    InternetCloseHandle(hNet);

    dp.finished = true;
    dp.success  = ok;
    if (progress) progress(dp);

    if (!ok) fs::remove(localPath);
    return ok;
}

// =============================================================================
// Minimal JSON parser (field extraction without nlohmann/rapidjson)
// =============================================================================

std::string Updater::jsonField(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\"";
    auto pos = json.find(search);
    if (pos == std::string::npos) return {};

    pos = json.find(':', pos + search.size());
    if (pos == std::string::npos) return {};
    ++pos;

    // Skip whitespace
    while (pos < json.size() && std::isspace(static_cast<unsigned char>(json[pos])))
        ++pos;

    if (pos >= json.size()) return {};

    if (json[pos] == '"') {
        ++pos;
        auto end = json.find('"', pos);
        if (end == std::string::npos) return {};
        return json.substr(pos, end - pos);
    }

    // number / bool
    auto end = json.find_first_of(",}\n", pos);
    if (end == std::string::npos) end = json.size();
    std::string v = json.substr(pos, end - pos);

    // trim
    v.erase(v.find_last_not_of(" \t\r\n") + 1);
    return v;
}

std::vector<std::string> Updater::jsonArray(const std::string& json,
                                             const std::string& key) {
    std::vector<std::string> result;

    std::string search = "\"" + key + "\"";
    auto pos = json.find(search);
    if (pos == std::string::npos) return result;

    pos = json.find('[', pos);
    if (pos == std::string::npos) return result;

    // Extract each {} object as a substring
    while (true) {
        auto objStart = json.find('{', pos);
        if (objStart == std::string::npos) break;

        // Match braces
        int depth = 0;
        size_t i = objStart;
        for (; i < json.size(); ++i) {
            if (json[i] == '{') ++depth;
            else if (json[i] == '}') { if (--depth == 0) { ++i; break; } }
        }
        result.push_back(json.substr(objStart, i - objStart));
        pos = i;

        auto next = json.find_first_of(",]", pos);
        if (next == std::string::npos || json[next] == ']') break;
        pos = next;
    }

    return result;
}

// =============================================================================
// Fetch & parse manifest
// =============================================================================

VersionManifest Updater::fetchManifest() {
    VersionManifest manifest;

    std::string body = httpGet(m_manifestUrl);
    if (body.empty()) return manifest;

    manifest.appVersion = jsonField(body, "appVersion");
    manifest.minVersion = jsonField(body, "minVersion");

    auto entries = jsonArray(body, "gpuEntries");
    for (const auto& entry : entries) {
        GPUManifestEntry e;
        e.modelId   = jsonField(entry, "modelId");
        e.version   = jsonField(entry, "version");
        e.configUrl = jsonField(entry, "configUrl");
        e.binaryUrl = jsonField(entry, "binaryUrl");
        e.sha256    = jsonField(entry, "sha256");
        e.changelog = jsonField(entry, "changelog");
        if (!e.modelId.empty())
            manifest.gpuEntries.push_back(std::move(e));
    }

    manifest.valid = !manifest.appVersion.empty();
    return manifest;
}

// =============================================================================
// Download file
// =============================================================================

bool Updater::downloadFile(const std::string& url,
                            const std::string& localPath,
                            ProgressCb         progress) {
    return httpGetToFile(url, localPath, progress);
}

// =============================================================================
// SHA-256 verification using Windows CNG (bcrypt)
// =============================================================================

bool Updater::verifySHA256(const std::string& filePath,
                            const std::string& expectedHex) {
    // Open algorithm provider
    BCRYPT_ALG_HANDLE hAlg = nullptr;
    if (!BCRYPT_SUCCESS(BCryptOpenAlgorithmProvider(
            &hAlg, BCRYPT_SHA256_ALGORITHM, nullptr, 0)))
        return false;

    BCRYPT_HASH_HANDLE hHash = nullptr;
    DWORD hashLen = 0, resultLen = 0;
    BCryptGetProperty(hAlg, BCRYPT_HASH_LENGTH,
                      reinterpret_cast<PUCHAR>(&hashLen), sizeof(DWORD),
                      &resultLen, 0);

    BCryptCreateHash(hAlg, &hHash, nullptr, 0, nullptr, 0, 0);

    std::ifstream ifs(filePath, std::ios::binary);
    char buf[65536];
    while (ifs.read(buf, sizeof(buf)) || ifs.gcount() > 0) {
        BCryptHashData(hHash,
                       reinterpret_cast<PUCHAR>(buf),
                       static_cast<ULONG>(ifs.gcount()), 0);
    }

    std::vector<BYTE> hashBytes(hashLen, 0);
    BCryptFinishHash(hHash, hashBytes.data(), hashLen, 0);

    BCryptDestroyHash(hHash);
    BCryptCloseAlgorithmProvider(hAlg, 0);

    // Convert to hex string
    std::ostringstream oss;
    for (auto b : hashBytes)
        oss << std::hex << std::setw(2) << std::setfill('0')
            << static_cast<int>(b);

    // Case-insensitive compare
    std::string computed = oss.str();
    std::string expected = expectedHex;
    std::transform(computed.begin(), computed.end(), computed.begin(), [](unsigned char c) -> char { return static_cast<char>(std::tolower(c)); });
    std::transform(expected.begin(), expected.end(), expected.begin(), [](unsigned char c) -> char { return static_cast<char>(std::tolower(c)); });

    return computed == expected;
}

// =============================================================================
// Semver comparison (major.minor.patch)
// =============================================================================

static std::tuple<int,int,int> parseSemver(const std::string& v) {
    int major = 0, minor = 0, patch = 0;
    std::sscanf(v.c_str(), "%d.%d.%d", &major, &minor, &patch);
    return {major, minor, patch};
}

bool Updater::isUpdateRequired(const std::string& installed,
                               const std::string& latest) {
    auto [iMaj, iMin, iPat] = parseSemver(installed);
    auto [lMaj, lMin, lPat] = parseSemver(latest);

    if (lMaj != iMaj) return lMaj > iMaj;
    if (lMin != iMin) return lMin > iMin;
    return lPat > iPat;
}

// =============================================================================
// Async update
// =============================================================================

void Updater::startAsyncUpdate(ProgressCb progress,
                               std::function<void(bool, const std::string&)> done) {
    if (m_running.load()) return;

    m_cancel.store(false);
    m_running.store(true);

    m_asyncThread = std::thread([this, progress, done]() {
        bool ok = false;
        std::string msg;

        try {
            VersionManifest manifest = fetchManifest();
            if (!manifest.valid) {
                msg = "Failed to fetch manifest.";
            } else {
                msg = "Manifest OK. App version: " + manifest.appVersion;

                for (const auto& entry : manifest.gpuEntries) {
                    if (m_cancel.load()) break;

                    std::string localCfg = m_driversDir + entry.modelId + ".json";
                    std::string localBin = m_driversDir + entry.modelId + ".dll";

                    // Download config
                    if (!entry.configUrl.empty()) {
                        httpGetToFile(entry.configUrl, localCfg, progress);
                        if (!entry.sha256.empty())
                            verifySHA256(localCfg, entry.sha256);
                    }

                    // Download binary (optional)
                    if (!entry.binaryUrl.empty()) {
                        httpGetToFile(entry.binaryUrl, localBin, progress);
                    }
                }

                ok = !m_cancel.load();
                if (ok) msg += " | Downloads complete.";
                else    msg += " | Cancelled.";
            }
        } catch (const std::exception& e) {
            msg = std::string("Exception: ") + e.what();
        }

        m_running.store(false);
        if (done) done(ok, msg);
    });
}

void Updater::cancelAsync() {
    m_cancel.store(true);
}

// =============================================================================
// Apply self-update (move new binary over current exe, restart)
// =============================================================================

bool Updater::applyAppUpdate(const std::string& newExePath) {
    char currentExe[MAX_PATH] = {};
    GetModuleFileNameA(nullptr, currentExe, MAX_PATH);

    std::string backupPath = std::string(currentExe) + ".bak";

    // Rename current → backup
    if (!MoveFileExA(currentExe, backupPath.c_str(),
                     MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
        return false;

    // Move new → current
    if (!MoveFileExA(newExePath.c_str(), currentExe,
                     MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        // Rollback
        MoveFileExA(backupPath.c_str(), currentExe, MOVEFILE_REPLACE_EXISTING);
        return false;
    }

    // Schedule backup deletion & restart via cmd.exe
    std::string cmd = "cmd.exe /C ping 127.0.0.1 -n 2 >nul & del \""
                    + backupPath + "\" & start \"\" \""
                    + currentExe + "\"";

    STARTUPINFOA si = { sizeof(si) };
    PROCESS_INFORMATION pi = {};
    CreateProcessA(nullptr,
                   const_cast<char*>(cmd.c_str()),
                   nullptr, nullptr, FALSE,
                   CREATE_NO_WINDOW | DETACHED_PROCESS,
                   nullptr, nullptr, &si, &pi);

    if (pi.hProcess) CloseHandle(pi.hProcess);
    if (pi.hThread)  CloseHandle(pi.hThread);

    // Exit current instance
    ExitProcess(0);
    return true; // unreachable
}
