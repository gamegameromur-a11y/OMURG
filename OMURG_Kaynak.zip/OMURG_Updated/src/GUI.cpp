// =============================================================================
// OMURG - GUI.cpp  [v2.0 — NVIDIA App Style, Device Manager, FX160]
// =============================================================================

#include "GUI.h"
#include "FX150.h"
#include "FX160.h"
#include "Updater.h"
#include "Support.h"

#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>

#include <d3d11.h>
#include <shellapi.h>
#include <setupapi.h>
#include <devguid.h>
#include <cfgmgr32.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "setupapi.lib")
#pragma comment(lib, "cfgmgr32.lib")

#include <string>
#include <vector>
#include <sstream>
#include <cstring>
#include <memory>
#include <format>
#include <algorithm>

// =============================================================================
// Language strings
// =============================================================================

struct Lang {
    const char* windowTitle;
    const char* menuGPU;
    const char* menuUpdater;
    const char* menuSupport;
    const char* menuSettings;
    const char* menuPerformance;
    const char* menuDevMgr;
    const char* gpuLabel;
    const char* vramLabel;
    const char* threadsLabel;
    const char* tempLabel;
    const char* powerLabel;
    const char* fpsLabel;
    const char* trisLabel;
    const char* updateCheck;
    const char* updateDownload;
    const char* updateStatus;
    const char* supportName;
    const char* supportEmail;
    const char* supportSubj;
    const char* supportMsg;
    const char* supportSend;
    const char* langLabel;
    const char* themeLabel;
    const char* initBtn;
    const char* shutBtn;
    const char* statsHeader;
    const char* memDump;
    const char* devMgrTitle;
    const char* devMgrRefresh;
    const char* devMgrEnable;
    const char* devMgrDisable;
    const char* devMgrStatus;
    const char* perfTitle;
    const char* cpuBoost;
    const char* asyncQueues;
};

static const Lang LANG_EN = {
    "OMURG Control Panel", "GPU", "Updater", "Support", "Settings",
    "Performance", "Device Manager",
    "Active GPU", "VRAM", "Compute Units", "Temperature", "Power Draw",
    "FPS", "Triangles/Frame", "Check for Updates", "Download", "Status",
    "Your Name", "Your Email", "Subject", "Message", "Send to Support",
    "Language", "Theme", "Initialize GPU", "Shutdown GPU",
    "Live Statistics", "Dump Memory Map",
    "Device Manager", "Refresh Devices", "Enable", "Disable", "Status",
    "Performance Metrics", "CPU Compatibility Boost", "Async Compute Queues",
};

static const Lang LANG_TR = {
    "OMURG Kontrol Paneli", "GPU", "Guncelleyici", "Destek", "Ayarlar",
    "Performans", "Aygit Yoneticisi",
    "Aktif GPU", "VRAM", "Islem Birimleri", "Sicaklik", "Guc Tuketimi",
    "FPS", "Ucgen/Kare", "Guncelleme Kontrol Et", "Indir", "Durum",
    "Adiniz", "E-postaniz", "Konu", "Mesaj", "Destege Gonder",
    "Dil", "Tema", "GPU Baslat", "GPU Kapat",
    "Canli Istatistikler", "Bellek Haritasini Dok",
    "Aygit Yoneticisi", "Aygitlari Yenile", "Etkinlestir", "Devre Disi",
    "Durum", "Performans Metrikleri", "CPU Uyumluluk Artisi",
    "Asenkron Islem Kuyrugu",
};

// =============================================================================
// NVIDIA Color Palette
// =============================================================================

static const ImVec4 NV_BG          = { 0.078f, 0.078f, 0.078f, 1.f };
static const ImVec4 NV_BG2         = { 0.110f, 0.110f, 0.110f, 1.f };
static const ImVec4 NV_BG3         = { 0.150f, 0.150f, 0.150f, 1.f };
static const ImVec4 NV_CARD        = { 0.125f, 0.125f, 0.125f, 1.f };
static const ImVec4 NV_GREEN       = { 0.463f, 0.725f, 0.000f, 1.f };
static const ImVec4 NV_GREEN_DIM   = { 0.300f, 0.470f, 0.000f, 1.f };
static const ImVec4 NV_GREEN_DARK  = { 0.160f, 0.260f, 0.000f, 1.f };
static const ImVec4 NV_TEXT        = { 0.960f, 0.960f, 0.960f, 1.f };
static const ImVec4 NV_TEXT_DIM    = { 0.500f, 0.500f, 0.500f, 1.f };
static const ImVec4 NV_TEXT_MID    = { 0.720f, 0.720f, 0.720f, 1.f };
static const ImVec4 NV_BORDER      = { 0.200f, 0.200f, 0.200f, 1.f };
static const ImVec4 NV_RED         = { 1.000f, 0.260f, 0.260f, 1.f };
static const ImVec4 NV_ORANGE      = { 1.000f, 0.650f, 0.000f, 1.f };
static const ImVec4 NV_BLUE        = { 0.200f, 0.600f, 1.000f, 1.f };
static const ImVec4 NV_SELECTED    = { 0.180f, 0.180f, 0.180f, 1.f };

static void applyNvidiaTheme() {
    ImGuiStyle& s = ImGui::GetStyle();
    ImGui::StyleColorsDark();

    s.WindowRounding    = 0.f;
    s.ChildRounding     = 6.f;
    s.FrameRounding     = 4.f;
    s.ScrollbarRounding = 4.f;
    s.GrabRounding      = 4.f;
    s.TabRounding       = 4.f;
    s.PopupRounding     = 4.f;
    s.WindowBorderSize  = 0.f;
    s.ChildBorderSize   = 1.f;
    s.FrameBorderSize   = 0.f;
    s.ItemSpacing       = { 10.f, 8.f };
    s.ItemInnerSpacing  = { 6.f, 4.f };
    s.FramePadding      = { 10.f, 6.f };
    s.WindowPadding     = { 0.f, 0.f };
    s.IndentSpacing     = 16.f;
    s.ScrollbarSize     = 8.f;
    s.GrabMinSize       = 8.f;

    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg]             = NV_BG;
    c[ImGuiCol_ChildBg]              = NV_CARD;
    c[ImGuiCol_PopupBg]              = NV_BG2;
    c[ImGuiCol_Border]               = NV_BORDER;
    c[ImGuiCol_BorderShadow]         = { 0,0,0,0 };
    c[ImGuiCol_FrameBg]              = NV_BG3;
    c[ImGuiCol_FrameBgHovered]       = { 0.20f,0.20f,0.20f,1.f };
    c[ImGuiCol_FrameBgActive]        = { 0.24f,0.24f,0.24f,1.f };
    c[ImGuiCol_TitleBg]              = NV_BG;
    c[ImGuiCol_TitleBgActive]        = NV_BG;
    c[ImGuiCol_TitleBgCollapsed]     = NV_BG;
    c[ImGuiCol_MenuBarBg]            = NV_BG2;
    c[ImGuiCol_ScrollbarBg]          = NV_BG;
    c[ImGuiCol_ScrollbarGrab]        = NV_BG3;
    c[ImGuiCol_ScrollbarGrabHovered] = NV_BORDER;
    c[ImGuiCol_ScrollbarGrabActive]  = NV_TEXT_DIM;
    c[ImGuiCol_CheckMark]            = NV_GREEN;
    c[ImGuiCol_SliderGrab]           = NV_GREEN;
    c[ImGuiCol_SliderGrabActive]     = { 0.55f,0.85f,0.0f,1.f };
    c[ImGuiCol_Button]               = NV_GREEN_DARK;
    c[ImGuiCol_ButtonHovered]        = NV_GREEN_DIM;
    c[ImGuiCol_ButtonActive]         = NV_GREEN;
    c[ImGuiCol_Header]               = NV_BG3;
    c[ImGuiCol_HeaderHovered]        = NV_SELECTED;
    c[ImGuiCol_HeaderActive]         = NV_GREEN_DARK;
    c[ImGuiCol_Separator]            = NV_BORDER;
    c[ImGuiCol_SeparatorHovered]     = NV_GREEN_DIM;
    c[ImGuiCol_SeparatorActive]      = NV_GREEN;
    c[ImGuiCol_ResizeGrip]           = { 0,0,0,0 };
    c[ImGuiCol_ResizeGripHovered]    = NV_GREEN_DIM;
    c[ImGuiCol_ResizeGripActive]     = NV_GREEN;
    c[ImGuiCol_Tab]                  = NV_BG2;
    c[ImGuiCol_TabHovered]           = NV_BG3;
    c[ImGuiCol_TabActive]            = NV_GREEN_DARK;
    c[ImGuiCol_TabUnfocused]         = NV_BG;
    c[ImGuiCol_TabUnfocusedActive]   = NV_BG2;
    c[ImGuiCol_PlotLines]            = NV_GREEN;
    c[ImGuiCol_PlotLinesHovered]     = { 0.55f,0.85f,0.0f,1.f };
    c[ImGuiCol_PlotHistogram]        = NV_GREEN;
    c[ImGuiCol_PlotHistogramHovered] = { 0.55f,0.85f,0.0f,1.f };
    c[ImGuiCol_TableHeaderBg]        = NV_BG2;
    c[ImGuiCol_TableBorderStrong]    = NV_BORDER;
    c[ImGuiCol_TableBorderLight]     = { 0.15f,0.15f,0.15f,1.f };
    c[ImGuiCol_TextSelectedBg]       = NV_GREEN_DARK;
    c[ImGuiCol_NavHighlight]         = NV_GREEN;
    c[ImGuiCol_Text]                 = NV_TEXT;
    c[ImGuiCol_TextDisabled]         = NV_TEXT_DIM;
}

// =============================================================================
// UI Helper widgets
// =============================================================================

static void SectionHeader(const char* label, const char* badge = nullptr) {
    ImGui::Spacing();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float  w   = ImGui::GetContentRegionAvail().x;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(pos, { pos.x + 3.f, pos.y + 20.f },
                      IM_COL32(118, 185, 0, 255));
    ImGui::SetCursorScreenPos({ pos.x + 10.f, pos.y + 2.f });
    ImGui::TextColored(NV_TEXT, "%s", label);
    if (badge) {
        ImGui::SameLine();
        ImVec2 bp = ImGui::GetCursorScreenPos();
        float bw = ImGui::CalcTextSize(badge).x + 10.f;
        dl->AddRectFilled(bp, { bp.x + bw, bp.y + 18.f },
                          IM_COL32(118, 185, 0, 40), 3.f);
        dl->AddRect(bp, { bp.x + bw, bp.y + 18.f },
                    IM_COL32(118, 185, 0, 120), 3.f);
        ImGui::TextColored(NV_GREEN, "%s", badge);
    }
    ImGui::SetCursorScreenPos({ pos.x, pos.y + 24.f });
    dl->AddLine({ pos.x + 3.f, pos.y + 24.f }, { pos.x + w, pos.y + 24.f },
                IM_COL32(45, 45, 45, 255));
    ImGui::Dummy({ w, 8.f });
}

static void StatRow(const char* label, const std::string& value,
                    ImVec4 valCol = { 0.96f,0.96f,0.96f,1.f },
                    float labelW = 220.f) {
    ImGui::TextColored(NV_TEXT_DIM, "%s", label);
    ImGui::SameLine(labelW);
    ImGui::TextColored(valCol, "%s", value.c_str());
}

static void NvProgressBar(float fraction, float height = 8.f,
                           ImVec4 color = { 0.463f,0.725f,0.0f,1.f }) {
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float  w   = ImGui::GetContentRegionAvail().x;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(pos, { pos.x + w, pos.y + height },
                      IM_COL32(38, 38, 38, 255), 3.f);
    float fill = std::max(0.f, std::min(fraction, 1.f)) * w;
    if (fill > 2.f) {
        dl->AddRectFilled(pos, { pos.x + fill, pos.y + height },
                          IM_COL32((int)(color.x*255),(int)(color.y*255),
                                   (int)(color.z*255),255), 3.f);
    }
    dl->AddRect(pos, { pos.x + w, pos.y + height },
                IM_COL32(60, 60, 60, 180), 3.f);
    ImGui::Dummy({ w, height + 4.f });
}

static bool BeginCard(const char* id, float width = 0.f, float height = 0.f) {
    if (width == 0.f) width = ImGui::GetContentRegionAvail().x;
    ImGui::PushStyleColor(ImGuiCol_ChildBg, NV_CARD);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 6.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14.f, 12.f));
    bool open = ImGui::BeginChild(id, { width, height }, true,
                                  ImGuiWindowFlags_NoScrollbar);
    ImGui::PopStyleVar(2);
    return open;
}

static void EndCard() {
    ImGui::EndChild();
    ImGui::PopStyleColor();
}

static bool BadgeButton(const char* label, ImVec4 color, float w = 0.f) {
    if (w == 0.f) w = ImGui::CalcTextSize(label).x + 20.f;
    ImGui::PushStyleColor(ImGuiCol_Button,
        ImVec4(color.x*.2f, color.y*.2f, color.z*.2f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,
        ImVec4(color.x*.35f, color.y*.35f, color.z*.35f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, color);
    ImGui::PushStyleColor(ImGuiCol_Text, color);
    bool clicked = ImGui::Button(label, { w, 28.f });
    ImGui::PopStyleColor(4);
    return clicked;
}

// =============================================================================
// Device enumeration (Windows SetupAPI)
// =============================================================================

struct DeviceInfo {
    std::string instanceId;
    std::string friendlyName;
    std::string description;
    bool        enabled = true;
    bool        isOmurg = false;
};

static std::vector<DeviceInfo> enumDisplayDevices() {
    std::vector<DeviceInfo> result;
    HDEVINFO devInfo = SetupDiGetClassDevsW(
        &GUID_DEVCLASS_DISPLAY, nullptr, nullptr,
        DIGCF_PRESENT | DIGCF_ALLCLASSES);
    if (devInfo == INVALID_HANDLE_VALUE) return result;

    SP_DEVINFO_DATA did = {};
    did.cbSize = sizeof(did);
    for (DWORD i = 0; SetupDiEnumDeviceInfo(devInfo, i, &did); ++i) {
        DeviceInfo di;
        wchar_t buf[512] = {};
        if (SetupDiGetDeviceRegistryPropertyW(devInfo, &did,
                SPDRP_FRIENDLYNAME, nullptr,
                reinterpret_cast<PBYTE>(buf), sizeof(buf), nullptr)) {
            char narrow[512] = {};
            WideCharToMultiByte(CP_UTF8, 0, buf, -1, narrow, sizeof(narrow),
                                nullptr, nullptr);
            di.friendlyName = narrow;
        }
        wchar_t desc[512] = {};
        if (SetupDiGetDeviceRegistryPropertyW(devInfo, &did,
                SPDRP_DEVICEDESC, nullptr,
                reinterpret_cast<PBYTE>(desc), sizeof(desc), nullptr)) {
            char narrow[512] = {};
            WideCharToMultiByte(CP_UTF8, 0, desc, -1, narrow, sizeof(narrow),
                                nullptr, nullptr);
            di.description = narrow;
        }
        if (di.friendlyName.empty() && di.description.empty()) continue;
        if (di.friendlyName.empty()) di.friendlyName = di.description;
        wchar_t instId[512] = {};
        if (SetupDiGetDeviceInstanceIdW(devInfo, &did, instId, 512, nullptr)) {
            char narrow[512] = {};
            WideCharToMultiByte(CP_UTF8, 0, instId, -1, narrow, sizeof(narrow),
                                nullptr, nullptr);
            di.instanceId = narrow;
        }
        ULONG status = 0, problem = 0;
        if (CM_Get_DevNode_Status(&status, &problem,
                                   did.DevInst, 0) == CR_SUCCESS)
            di.enabled = !(problem == CM_PROB_DISABLED);

        std::string upper = di.friendlyName;
        std::transform(upper.begin(), upper.end(), upper.begin(),
            [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
        di.isOmurg = (upper.find("OMURG") != std::string::npos
                   || upper.find("FX150") != std::string::npos
                   || upper.find("FX160") != std::string::npos);
        result.push_back(std::move(di));
    }
    SetupDiDestroyDeviceInfoList(devInfo);
    return result;
}

// =============================================================================
// OMURGGui::Impl
// =============================================================================

struct OMURGGui::Impl {
    HWND                     hwnd         = nullptr;
    ID3D11Device*            device       = nullptr;
    ID3D11DeviceContext*     context      = nullptr;
    IDXGISwapChain*          swapChain    = nullptr;
    ID3D11RenderTargetView*  mainRTV      = nullptr;

    int  currentLangIdx  = 0;
    int  gpuSelection    = 0;
    bool gpuInitialized  = false;
    int  activeSection   = 0;

    std::unique_ptr<VirtualGPU>    gpu;
    bool                           isFX160  = false;
    std::unique_ptr<Updater>       updater;
    std::unique_ptr<SupportClient> support;

    struct GPUModel {
        const char* name;
        uint64_t    vramBytes;
        bool        isFX160;
    };
    static const GPUModel GPU_MODELS[];
    static const int      GPU_MODEL_COUNT = 6;

    std::string updateStatus;
    bool        updateRunning = false;

    char supportName[128]  = {};
    char supportEmail[128] = {};
    char supportSubj[256]  = {};
    char supportMsg[2048]  = {};
    std::string supportResult;
    bool supportResultOk   = false;

    static constexpr int FPS_HISTORY  = 128;
    static constexpr int TEMP_HISTORY = 128;
    float fpsHistory[FPS_HISTORY]   = {};
    int   fpsIdx = 0;
    float tempHistory[TEMP_HISTORY] = {};
    int   tempIdx = 0;
    float perfHistory[FPS_HISTORY]  = {};
    int   perfIdx = 0;

    std::string memDumpText;

    std::vector<DeviceInfo> devices;
    bool devMgrRefreshed = false;
    int  devMgrFilter    = 0;
};

const OMURGGui::Impl::GPUModel OMURGGui::Impl::GPU_MODELS[] = {
    { "OMURG FX150  [512 MB VRAM]",               512ull  * 1024 * 1024, false },
    { "OMURG FX150  [1 GB VRAM]",                 1024ull * 1024 * 1024, false },
    { "OMURG FX150  [2 GB VRAM]",                 2048ull * 1024 * 1024, false },
    { "OMURG FX160  [3 GB VRAM]",                 3072ull * 1024 * 1024, true  },
    { "OMURG FX160  [3 GB | +50% Speed]",         3072ull * 1024 * 1024, true  },
    { "OMURG FX160  [3 GB | Max Performance]",    3072ull * 1024 * 1024, true  },
};

OMURGGui::OMURGGui()  : m(std::make_unique<Impl>()) {}
OMURGGui::~OMURGGui() { shutdown(); }

// =============================================================================
// Init / Shutdown
// =============================================================================

bool OMURGGui::init(HWND hwnd) {
    m->hwnd = hwnd;
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount        = 2;
    sd.BufferDesc.Format  = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow       = hwnd;
    sd.SampleDesc.Count   = 1;
    sd.Windowed           = TRUE;
    sd.SwapEffect         = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    D3D_FEATURE_LEVEL fl[] = { D3D_FEATURE_LEVEL_11_0 };
    if (FAILED(D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
            fl, 1, D3D11_SDK_VERSION, &sd,
            &m->swapChain, &m->device, nullptr, &m->context)))
        return false;
    createRTV();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    // Docking DISABLED to prevent phantom child window
    io.IniFilename = nullptr;
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(m->device, m->context);
    applyNvidiaTheme();
    m->updater = std::make_unique<Updater>();
    m->support = std::make_unique<SupportClient>();
    return true;
}

void OMURGGui::createRTV() {
    ID3D11Texture2D* bb = nullptr;
    m->swapChain->GetBuffer(0, IID_PPV_ARGS(&bb));
    if (bb) { m->device->CreateRenderTargetView(bb, nullptr, &m->mainRTV); bb->Release(); }
}

void OMURGGui::shutdown() {
    if (m->gpuInitialized && m->gpu) { m->gpu->shutdown(); m->gpuInitialized = false; }
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (m->mainRTV)  { m->mainRTV->Release();  m->mainRTV  = nullptr; }
    if (m->swapChain){ m->swapChain->Release(); m->swapChain= nullptr; }
    if (m->context)  { m->context->Release();  m->context  = nullptr; }
    if (m->device)   { m->device->Release();   m->device   = nullptr; }
}

void OMURGGui::resize(UINT w, UINT h) {
    if (m->mainRTV) { m->mainRTV->Release(); m->mainRTV = nullptr; }
    m->swapChain->ResizeBuffers(0, w, h, DXGI_FORMAT_UNKNOWN, 0);
    createRTV();
}

// =============================================================================
// Main render
// =============================================================================

void OMURGGui::render() {
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    const Lang& L = (m->currentLangIdx == 0) ? LANG_EN : LANG_TR;
    ImGuiIO& io   = ImGui::GetIO();

    // Single full-screen root window — NO docking, NO title bar
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f), ImGuiCond_Always);
    ImGui::SetNextWindowSize(io.DisplaySize, ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.f, 0.f));
    ImGui::Begin("##root", nullptr,
        ImGuiWindowFlags_NoTitleBar        |
        ImGuiWindowFlags_NoResize          |
        ImGuiWindowFlags_NoScrollbar       |
        ImGuiWindowFlags_NoScrollWithMouse |
        ImGuiWindowFlags_NoMove            |
        ImGuiWindowFlags_NoBringToFrontOnFocus |
        ImGuiWindowFlags_NoNav);
    ImGui::PopStyleVar();

    const float sideW  = 240.f;
    const float totalH = io.DisplaySize.y;
    const float totalW = io.DisplaySize.x;
    const float headerH = 52.f;

    // ── HEADER ────────────────────────────────────────────────────────────
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 hp = ImGui::GetCursorScreenPos();
        dl->AddRectFilled(hp, { hp.x + totalW, hp.y + headerH },
                          IM_COL32(16, 16, 16, 255));
        // Logo bar
        dl->AddRectFilled({ hp.x + 16.f, hp.y + 8.f },
                          { hp.x + 22.f, hp.y + 44.f },
                          IM_COL32(118, 185, 0, 255));
        ImGui::SetCursorScreenPos({ hp.x + 30.f, hp.y + 8.f });
        ImGui::TextColored(NV_GREEN, "OMURG");
        ImGui::SetCursorScreenPos({ hp.x + 30.f, hp.y + 28.f });
        ImGui::TextColored(NV_TEXT_DIM, "Virtual GPU Control Panel  v2.0");
        // Right pill
        float px = totalW - 210.f;
        ImVec4 pc = m->gpuInitialized ? NV_GREEN : NV_RED;
        dl->AddRectFilled({ hp.x + px, hp.y + 14.f },
                          { hp.x + px + 190.f, hp.y + 38.f },
                          IM_COL32((int)(pc.x*25),(int)(pc.y*25),(int)(pc.z*25),255), 18.f);
        dl->AddRect({ hp.x + px, hp.y + 14.f },
                    { hp.x + px + 190.f, hp.y + 38.f },
                    IM_COL32((int)(pc.x*170),(int)(pc.y*170),(int)(pc.z*170),200), 18.f);
        ImGui::SetCursorScreenPos({ hp.x + px + 14.f, hp.y + 18.f });
        if (m->gpuInitialized)
            ImGui::TextColored(pc, "GPU ONLINE  [%s]",
                m->isFX160 ? "FX160" : "FX150");
        else
            ImGui::TextColored(pc, "GPU OFFLINE");
        // Divider
        dl->AddLine({ hp.x, hp.y + headerH },
                    { hp.x + totalW, hp.y + headerH },
                    IM_COL32(36, 36, 36, 255));
        ImGui::SetCursorScreenPos({ hp.x, hp.y + headerH });
    }

    // ── BODY ──────────────────────────────────────────────────────────────
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.f, 0.f));
    float bodyH = totalH - headerH;

    // SIDEBAR
    ImGui::PushStyleColor(ImGuiCol_ChildBg, NV_BG2);
    ImGui::BeginChild("##sidebar", { sideW, bodyH }, false,
                      ImGuiWindowFlags_NoScrollbar);
    ImGui::Dummy({ 0.f, 14.f });

    struct NavEntry { const char* labelEN; const char* labelTR; ImVec4 dot; };
    static const NavEntry navItems[] = {
        { "GPU Control",     "GPU Kontrol",      { 0.46f,0.72f,0.0f,1.f } },
        { "Performance",     "Performans",       { 0.20f,0.60f,1.0f,1.f } },
        { "Device Manager",  "Aygit Yoneticisi", { 0.90f,0.55f,0.0f,1.f } },
        { "Updater",         "Guncelleyici",     { 0.46f,0.72f,0.0f,1.f } },
        { "Support",         "Destek",           { 0.65f,0.35f,1.0f,1.f } },
        { "Settings",        "Ayarlar",          { 0.50f,0.50f,0.5f,1.f } },
    };

    for (int i = 0; i < 6; ++i) {
        bool sel = (m->activeSection == i);
        const char* lbl = (m->currentLangIdx == 0)
            ? navItems[i].labelEN : navItems[i].labelTR;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        if (sel) {
            dl->AddRectFilled(p, { p.x + sideW, p.y + 42.f },
                              IM_COL32(26,26,26,255));
            dl->AddRectFilled(p, { p.x + 3.f, p.y + 42.f },
                              IM_COL32(118,185,0,255));
        }
        ImVec4 dc = navItems[i].dot;
        dl->AddCircleFilled({ p.x + 16.f, p.y + 21.f }, 4.f,
            IM_COL32((int)(dc.x*255),(int)(dc.y*255),(int)(dc.z*255),
                     sel ? 255 : 130));
        ImGui::PushStyleColor(ImGuiCol_Button,
            sel ? ImVec4{0.10f,0.10f,0.10f,1.f} : ImVec4{0,0,0,0});
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4{0.17f,0.17f,0.17f,1.f});
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4{0.13f,0.13f,0.13f,1.f});
        ImGui::PushStyleColor(ImGuiCol_Text, sel ? NV_TEXT : NV_TEXT_DIM);
        char bid[64]; std::snprintf(bid, sizeof(bid), "   %s##nav%d", lbl, i);
        if (ImGui::Button(bid, { sideW, 42.f })) m->activeSection = i;
        ImGui::PopStyleColor(4);
    }

    // Bottom info
    ImGui::SetCursorPosY(bodyH - 100.f);
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        dl->AddLine(p, { p.x + sideW, p.y }, IM_COL32(36,36,36,255));
    }
    ImGui::Dummy({ 0.f, 8.f });
    ImGui::TextColored(NV_TEXT_DIM, "  Model");
    ImGui::SameLine(80.f);
    if (m->gpuInitialized && m->gpu)
        ImGui::TextColored(NV_GREEN, m->gpu->descriptor().modelName.c_str());
    else
        ImGui::TextColored(NV_TEXT_DIM, "--");
    ImGui::TextColored(NV_TEXT_DIM, "  Driver"); ImGui::SameLine(80.f);
    ImGui::TextColored(NV_TEXT_MID, "v2.0.0");
    ImGui::TextColored(NV_TEXT_DIM, "  Build");  ImGui::SameLine(80.f);
    ImGui::TextColored(NV_TEXT_MID, __DATE__);

    ImGui::EndChild();
    ImGui::PopStyleColor();

    // Separator
    ImGui::SameLine();
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        dl->AddLine(p, { p.x, p.y + bodyH }, IM_COL32(36,36,36,255));
    }

    // CONTENT
    ImGui::PushStyleColor(ImGuiCol_ChildBg, NV_BG);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(20.f, 16.f));
    ImGui::BeginChild("##content", { totalW - sideW - 1.f, bodyH }, false,
                      ImGuiWindowFlags_HorizontalScrollbar);
    ImGui::PopStyleVar();

    switch (m->activeSection) {
    case 0: renderGPUTab(L);         break;
    case 1: renderPerformanceTab(L); break;
    case 2: renderDevMgrTab(L);      break;
    case 3: renderUpdaterTab(L);     break;
    case 4: renderSupportTab(L);     break;
    case 5: renderSettingsTab(L);    break;
    }

    ImGui::EndChild();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(); // ItemSpacing
    ImGui::End();

    ImGui::Render();
    const float cc[4] = { 0.078f, 0.078f, 0.078f, 1.f };
    m->context->OMSetRenderTargets(1, &m->mainRTV, nullptr);
    m->context->ClearRenderTargetView(m->mainRTV, cc);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    m->swapChain->Present(1, 0);
}

// =============================================================================
// GPU Tab
// =============================================================================

void OMURGGui::renderGPUTab(const Lang& L) {
    SectionHeader("GPU Selection");

    std::vector<const char*> items;
    for (int i = 0; i < Impl::GPU_MODEL_COUNT; ++i)
        items.push_back(Impl::GPU_MODELS[i].name);
    ImGui::SetNextItemWidth(380.f);
    ImGui::Combo("##gpu", &m->gpuSelection,
                 items.data(), static_cast<int>(items.size()));
    ImGui::SameLine(0.f, 12.f);

    const auto& sel = Impl::GPU_MODELS[m->gpuSelection];
    if (sel.isFX160) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 bp = ImGui::GetCursorScreenPos();
        dl->AddRectFilled(bp, { bp.x + 82.f, bp.y + 22.f },
                          IM_COL32(0,60,200,60), 4.f);
        dl->AddRect(bp, { bp.x + 82.f, bp.y + 22.f },
                    IM_COL32(0,140,255,180), 4.f);
        ImGui::TextColored(NV_BLUE, "FX160  NEW");
        ImGui::SameLine(0.f, 12.f);
    }

    if (!m->gpuInitialized) {
        if (BadgeButton(L.initBtn, NV_GREEN, 160.f)) {
            if (sel.isFX160) {
                auto g = std::make_unique<FX160>(sel.vramBytes);
                if (g->initialize()) { m->gpu = std::move(g); m->isFX160 = true; m->gpuInitialized = true; }
            } else {
                auto g = std::make_unique<FX150>(sel.vramBytes);
                if (g->initialize()) { m->gpu = std::move(g); m->isFX160 = false; m->gpuInitialized = true; }
            }
        }
    } else {
        if (BadgeButton(L.shutBtn, NV_RED, 160.f)) {
            m->gpu->shutdown(); m->gpuInitialized = false; m->isFX160 = false;
        }
    }

    if (!m->gpuInitialized || !m->gpu) {
        ImGui::Spacing();
        SectionHeader("Available Models");
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10.f, 10.f));
        float cw = (ImGui::GetContentRegionAvail().x - 10.f) / 2.f;
        for (int i = 0; i < Impl::GPU_MODEL_COUNT; ++i) {
            bool isNew = Impl::GPU_MODELS[i].isFX160;
            if (i % 2 != 0) ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_ChildBg,
                i == m->gpuSelection
                    ? ImVec4{0.14f,0.20f,0.08f,1.f} : NV_CARD);
            ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 6.f);
            ImGui::BeginChild(std::format("##gc{}", i).c_str(),
                              { cw, 70.f }, true);
            ImGui::TextColored(isNew ? NV_BLUE : NV_GREEN,
                "%s", Impl::GPU_MODELS[i].name);
            ImGui::TextColored(NV_TEXT_DIM, "%s",
                isNew ? "3 GB VRAM  |  +50% CPU Boost  |  Async Compute  |  12 CU"
                      : "512 MB - 2 GB VRAM  |  8 Compute Units  |  Standard");
            ImGui::EndChild();
            ImGui::PopStyleVar(); ImGui::PopStyleColor();
        }
        ImGui::PopStyleVar();
        return;
    }

    ImGui::Spacing();
    SectionHeader("Live Statistics", m->isFX160 ? "FX160" : "FX150");

    GPUStats stats = m->gpu->queryStats();
    const GPUDescriptor& desc = m->gpu->descriptor();
    float temp    = m->gpu->simulatedTemperature();
    float power   = m->gpu->simulatedPowerDraw();
    float vramRat = (float)stats.vramUsed / std::max((uint64_t)1, desc.vramBytes);
    float tempRat = std::max(0.f, (temp - 30.f) / 65.f);
    float powerRat= power / (m->isFX160 ? 110.f : 75.f);
    ImVec4 tempCol= (temp>80.f) ? NV_RED : (temp>60.f) ? NV_ORANGE : NV_GREEN;

    m->fpsHistory[m->fpsIdx] = (float)stats.fps;
    m->fpsIdx = (m->fpsIdx + 1) % Impl::FPS_HISTORY;
    char fpsLbl[32]; std::snprintf(fpsLbl, 32, "%.1f FPS", stats.fps);

    float cw = (ImGui::GetContentRegionAvail().x - 10.f) / 2.f;
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10.f, 10.f));

    if (BeginCard("##sl", cw)) {
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_FrameBg,   NV_BG2);
        ImGui::PushStyleColor(ImGuiCol_PlotLines,  NV_GREEN);
        ImGui::PlotLines("##fps", m->fpsHistory, Impl::FPS_HISTORY,
                         m->fpsIdx, fpsLbl, 0.f, 200.f,
                         { ImGui::GetContentRegionAvail().x, 60.f });
        ImGui::PopStyleColor(2);
        ImGui::Spacing();
        StatRow("GPU Model",     desc.modelName,    NV_GREEN, 160.f);
        StatRow("VRAM Total",    std::format("{:.0f} MB", desc.vramBytes/1048576.0), NV_TEXT, 160.f);
        StatRow("Compute Units", std::to_string(stats.activeThreads), NV_TEXT, 160.f);
        StatRow("Clock",         std::format("{} MHz", desc.clockSpeedMHz), NV_TEXT, 160.f);
        StatRow("Frames",        std::format("{}", stats.framesRendered), NV_TEXT, 160.f);
        StatRow("Triangles/F",   std::format("{}", stats.trianglesPerFrame), NV_TEXT, 160.f);
    }
    EndCard();
    ImGui::SameLine(0.f, 10.f);

    if (BeginCard("##sr", cw)) {
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "VRAM  %.1f / %.0f MB",
            stats.vramUsed/1048576.0, desc.vramBytes/1048576.0);
        NvProgressBar(vramRat, 8.f, NV_GREEN);
        ImGui::Spacing();
        ImGui::TextColored(tempCol, "Temperature  %.1f C", temp);
        NvProgressBar(tempRat, 8.f, tempCol);
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "Power  %.1f W", power);
        NvProgressBar(powerRat, 8.f, NV_ORANGE);
        if (m->isFX160) {
            ImGui::Spacing();
            ImGui::TextColored(NV_BLUE, "CPU Boost x1.5   Async Queues: 4");
            NvProgressBar(1.0f, 4.f, NV_BLUE);
        }
    }
    EndCard();
    ImGui::PopStyleVar();

    ImGui::Spacing();
    SectionHeader("Memory Diagnostics");
    if (BeginCard("##md")) {
        if (BadgeButton(L.memDump, NV_TEXT_DIM, 220.f))
            m->memDumpText = m->gpu->dumpMemoryMap();
        if (!m->memDumpText.empty()) {
            ImGui::SameLine(0.f, 10.f);
            if (BadgeButton("Clear", NV_RED, 80.f)) m->memDumpText.clear();
            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_FrameBg, NV_BG2);
            ImGui::InputTextMultiline("##memdump",
                m->memDumpText.data(), m->memDumpText.size(),
                { -1.f, 160.f }, ImGuiInputTextFlags_ReadOnly);
            ImGui::PopStyleColor();
        }
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Performance Tab
// =============================================================================

void OMURGGui::renderPerformanceTab(const Lang& L) {
    SectionHeader("Performance Metrics");
    if (!m->gpuInitialized || !m->gpu) {
        if (BeginCard("##pno", 0.f, 70.f)) {
            ImGui::Spacing();
            ImGui::TextColored(NV_TEXT_DIM, "  No GPU active. Initialize a GPU first.");
        }
        EndCard();
        return;
    }

    GPUStats stats = m->gpu->queryStats();
    const GPUDescriptor& desc = m->gpu->descriptor();
    float temp  = m->gpu->simulatedTemperature();
    [[maybe_unused]] float power = m->gpu->simulatedPowerDraw();

    m->perfHistory[m->perfIdx] = (float)stats.fps;
    m->perfIdx = (m->perfIdx + 1) % Impl::FPS_HISTORY;
    m->tempHistory[m->tempIdx] = temp;
    m->tempIdx = (m->tempIdx + 1) % Impl::TEMP_HISTORY;

    float cw = (ImGui::GetContentRegionAvail().x - 10.f) / 2.f;
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10.f, 10.f));

    if (BeginCard("##pfps", cw, 150.f)) {
        ImGui::TextColored(NV_TEXT_DIM, "Frame Rate");
        char l[32]; std::snprintf(l, 32, "%.1f FPS", stats.fps);
        ImGui::PushStyleColor(ImGuiCol_FrameBg,   NV_BG);
        ImGui::PushStyleColor(ImGuiCol_PlotLines, NV_GREEN);
        ImGui::PlotLines("##pf", m->perfHistory, Impl::FPS_HISTORY, m->perfIdx,
                         l, 0.f, 250.f, { ImGui::GetContentRegionAvail().x, 80.f });
        ImGui::PopStyleColor(2);
        ImGui::TextColored(NV_GREEN, "%.1f FPS", stats.fps);
    }
    EndCard();
    ImGui::SameLine(0.f, 10.f);

    if (BeginCard("##ptemp", cw, 150.f)) {
        ImVec4 tc = (temp>80.f) ? NV_RED : (temp>60.f) ? NV_ORANGE : NV_GREEN;
        ImGui::TextColored(NV_TEXT_DIM, "Temperature");
        char l[32]; std::snprintf(l, 32, "%.1f C", temp);
        ImGui::PushStyleColor(ImGuiCol_FrameBg,   NV_BG);
        ImGui::PushStyleColor(ImGuiCol_PlotLines, tc);
        ImGui::PlotLines("##pt", m->tempHistory, Impl::TEMP_HISTORY, m->tempIdx,
                         l, 30.f, 95.f, { ImGui::GetContentRegionAvail().x, 80.f });
        ImGui::PopStyleColor(2);
        ImGui::TextColored(tc, "%.1f C", temp);
    }
    EndCard();
    ImGui::PopStyleVar();

    ImGui::Spacing();
    SectionHeader("GPU Specifications");
    if (BeginCard("##spec")) {
        ImGui::Spacing();
        float lw = 260.f;
        StatRow("Model",           desc.modelName, NV_GREEN, lw);
        StatRow("Architecture",    m->isFX160 ? "FX160 Gen2" : "FX150 Gen1", NV_TEXT, lw);
        StatRow("VRAM",            std::format("{:.0f} MB", desc.vramBytes/1048576.0), NV_TEXT, lw);
        StatRow("Compute Units",   std::to_string(desc.computeUnits), NV_TEXT, lw);
        StatRow("Clock Speed",     std::format("{} MHz", desc.clockSpeedMHz), NV_TEXT, lw);
        StatRow("Max Texture",     std::format("{}x{}", desc.maxTextureSize, desc.maxTextureSize), NV_TEXT, lw);
        StatRow("Render Targets",  std::to_string(desc.maxRenderTargets), NV_TEXT, lw);
        if (m->isFX160) {
            ImGui::Spacing();
            StatRow("CPU Compat Boost",  "+50%  (x1.5)",   NV_BLUE, lw);
            StatRow("Proc Capacity",     "+50%  (x1.5)",   NV_BLUE, lw);
            StatRow("Async Queues",      "4",               NV_BLUE, lw);
            StatRow("MSAA",              "Supported",       NV_BLUE, lw);
            StatRow("Geometry Shader",   "Supported",       NV_BLUE, lw);
            StatRow("Tessellation",      "Supported",       NV_BLUE, lw);
            StatRow("Tile Size",         "32 px",           NV_BLUE, lw);
        } else {
            StatRow("Tile Size",         "64 px",           NV_TEXT, lw);
        }
        // Feature chips
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "Features:");
        ImGui::Spacing();
        auto chip = [](const char* n, bool on) {
            ImVec4 c = on ? ImVec4{0.46f,0.72f,0.0f,1.f}
                          : ImVec4{0.28f,0.28f,0.28f,1.f};
            ImGui::PushStyleColor(ImGuiCol_Button,
                ImVec4{c.x*.12f,c.y*.12f,c.z*.12f,1.f});
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered,
                ImVec4{c.x*.12f,c.y*.12f,c.z*.12f,1.f});
            ImGui::PushStyleColor(ImGuiCol_Text, c);
            ImGui::Button(n, { ImGui::CalcTextSize(n).x + 14.f, 22.f });
            ImGui::PopStyleColor(3);
            ImGui::SameLine(0.f, 5.f);
        };
        uint32_t f = (uint32_t)desc.features;
        chip("RAST",    f&1);    chip("DEPTH",   f&2);
        chip("STENCIL", f&4);    chip("TEX2D",   f&8);
        chip("TEXCUBE", f&16);   chip("MIP",     f&32);
        chip("MSAA",    f&64);   chip("COMPUTE", f&128);
        chip("GS",      f&256);  chip("TESS",    f&512);
        chip("RT",      f&1024); chip("SSE4",    f&2048);
        chip("AVX2",    f&4096); chip("ASYNC",   f&8192);
        ImGui::NewLine();
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Device Manager Tab
// =============================================================================

void OMURGGui::renderDevMgrTab(const Lang& L) {
    SectionHeader("Device Manager", "Windows PnP");

    if (BadgeButton(L.devMgrRefresh, NV_GREEN, 160.f) || !m->devMgrRefreshed) {
        m->devices = enumDisplayDevices();
        m->devMgrRefreshed = true;
    }
    ImGui::SameLine(0.f, 10.f);
    const char* filters[] = { "All Devices", "OMURG Only" };
    ImGui::SetNextItemWidth(150.f);
    ImGui::Combo("##df", &m->devMgrFilter, filters, 2);

    ImGui::Spacing();
    if (BeginCard("##devNote", 0.f, 58.f)) {
        ImGui::TextColored(NV_BLUE,
            "  When the GPU is ONLINE, it can be selected and used via");
        ImGui::TextColored(NV_BLUE,
            "  Device Manager. Initialize a GPU above to make it available.");
    }
    EndCard();
    ImGui::Spacing();

    int shown = 0;
    for (auto& dev : m->devices) {
        if (m->devMgrFilter == 1 && !dev.isOmurg) continue;
        shown++;
        bool active = m->gpuInitialized && dev.isOmurg;
        ImGui::PushStyleColor(ImGuiCol_ChildBg,
            active ? ImVec4{0.08f,0.16f,0.04f,1.f} : NV_CARD);
        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 6.f);
        ImGui::BeginChild(std::format("##dv{}", shown).c_str(),
                          { ImGui::GetContentRegionAvail().x, 76.f }, true);

        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImVec4 dc = active ? NV_GREEN : (dev.enabled ? NV_TEXT_DIM : NV_RED);
        dl->AddCircleFilled({ p.x + 12.f, p.y + 24.f }, 5.f,
            IM_COL32((int)(dc.x*255),(int)(dc.y*255),(int)(dc.z*255),255));

        ImGui::SetCursorScreenPos({ p.x + 26.f, p.y + 6.f });
        ImGui::TextColored(dev.isOmurg ? NV_GREEN : NV_TEXT,
            "%s", dev.friendlyName.c_str());
        ImGui::SetCursorScreenPos({ p.x + 26.f, p.y + 26.f });
        ImGui::TextColored(NV_TEXT_DIM, "%s", dev.description.c_str());
        ImGui::SetCursorScreenPos({ p.x + 26.f, p.y + 46.f });
        if (active)
            ImGui::TextColored(NV_GREEN, "ACTIVE — Online, available for selection");
        else if (!dev.enabled)
            ImGui::TextColored(NV_RED, "DISABLED");
        else
            ImGui::TextColored(NV_TEXT_DIM, "Present — Offline");

        float bw = 90.f;
        ImGui::SetCursorScreenPos({
            p.x + ImGui::GetWindowWidth() - bw - 10.f, p.y + 26.f });
        if (dev.isOmurg && m->gpuInitialized)
            ImGui::TextColored(NV_GREEN, "In Use");
        else if (!dev.enabled)
            BadgeButton(L.devMgrEnable, NV_GREEN, bw);
        else
            BadgeButton(L.devMgrDisable, NV_RED, bw);

        ImGui::EndChild();
        ImGui::PopStyleVar(); ImGui::PopStyleColor();
        ImGui::Spacing();
    }

    if (shown == 0) {
        if (BeginCard("##dvEmpty", 0.f, 60.f)) {
            ImGui::Spacing();
            ImGui::TextColored(NV_TEXT_DIM,
                "  No display devices found. Run as Administrator for full access.");
        }
        EndCard();
    }
}

// =============================================================================
// Updater Tab
// =============================================================================

void OMURGGui::renderUpdaterTab(const Lang& L) {
    SectionHeader("Automatic Updates");
    if (BeginCard("##uc")) {
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "Manifest URL:");
        ImGui::SameLine();
        ImGui::TextColored(NV_GREEN, "%s", Updater::DEFAULT_MANIFEST_URL);
        ImGui::Spacing();
        if (!m->updateRunning) {
            if (BadgeButton(L.updateCheck, NV_GREEN, 200.f)) {
                m->updateRunning = true;
                m->updateStatus  = "Fetching manifest...";
                m->updater->startAsyncUpdate(
                    [this](const DownloadProgress& p) {
                        char buf[256];
                        if (p.totalBytes > 0)
                            std::snprintf(buf, sizeof(buf), "Downloading %s: %.1f%%",
                                p.filename.c_str(),
                                100.0 * p.bytesReceived / p.totalBytes);
                        else
                            std::snprintf(buf, sizeof(buf), "Downloading %s: %llu bytes",
                                p.filename.c_str(), p.bytesReceived);
                        m->updateStatus = buf;
                    },
                    [this](bool ok, const std::string& msg) {
                        m->updateRunning = false;
                        m->updateStatus  = (ok ? "[OK] " : "[FAIL] ") + msg;
                    });
            }
        } else {
            if (BadgeButton("Cancel", NV_RED, 120.f))
                m->updater->cancelAsync();
            ImGui::SameLine(0.f, 12.f);
            static int fr = 0;
            const char* sp[] = { "|", "/", "-", "\\" };
            ImGui::TextColored(NV_GREEN, "%s Working...", sp[(fr++/8)%4]);
        }
        ImGui::Spacing();
        SectionHeader("Status");
        if (!m->updateStatus.empty()) {
            bool ok   = m->updateStatus.substr(0,4) == "[OK]";
            bool fail = m->updateStatus.size() >= 6
                     && m->updateStatus.substr(0,6) == "[FAIL]";
            ImGui::TextColored(fail ? NV_RED : (ok ? NV_GREEN : NV_TEXT_DIM),
                "%s", m->updateStatus.c_str());
        } else {
            ImGui::TextColored(NV_TEXT_DIM, "No update check performed yet.");
        }
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Support Tab
// =============================================================================

void OMURGGui::renderSupportTab(const Lang& L) {
    SectionHeader("Contact Support");
    if (BeginCard("##supc")) {
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM,
            "Fill in the form. Clicking Send opens your default email client.");
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_FrameBg, NV_BG2);
        ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportName);
        ImGui::SetNextItemWidth(-1.f); ImGui::InputText("##sn", m->supportName, sizeof(m->supportName));
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportEmail);
        ImGui::SetNextItemWidth(-1.f); ImGui::InputText("##se", m->supportEmail, sizeof(m->supportEmail));
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportSubj);
        ImGui::SetNextItemWidth(-1.f); ImGui::InputText("##ss", m->supportSubj, sizeof(m->supportSubj));
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportMsg);
        ImGui::InputTextMultiline("##sm", m->supportMsg,
            sizeof(m->supportMsg), { -1.f, 130.f });
        ImGui::PopStyleColor();
        ImGui::Spacing();
        if (BadgeButton(L.supportSend, NV_GREEN, 200.f)) {
            std::string subj = std::string("[OMURG] ") + m->supportSubj;
            std::string body = std::string("Name: ") + m->supportName + "\r\n"
                             + "Email: " + m->supportEmail + "\r\n\r\n"
                             + m->supportMsg;
            auto enc = [](const std::string& s) {
                std::string r;
                for (unsigned char c : s) {
                    if (c==' ') r+="%20"; else if (c=='\r') r+="%0D";
                    else if (c=='\n') r+="%0A"; else if (c=='&') r+="%26";
                    else if (c=='?') r+="%3F"; else if (c=='#') r+="%23";
                    else r+=(char)c;
                }
                return r;
            };
            std::string ml = std::string("mailto:") + SupportClient::SUPPORT_EMAIL
                           + "?subject=" + enc(subj) + "&body=" + enc(body);
            ShellExecuteA(nullptr, "open", ml.c_str(), nullptr, nullptr, SW_SHOW);
            m->supportResultOk = true;
            m->supportResult   = "Email client opened successfully.";
        }
        if (!m->supportResult.empty()) {
            ImGui::Spacing();
            ImGui::TextColored(m->supportResultOk ? NV_GREEN : NV_RED,
                "%s", m->supportResult.c_str());
        }
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Settings Tab
// =============================================================================

void OMURGGui::renderSettingsTab(const Lang& L) {
    SectionHeader("Interface");
    if (BeginCard("##setc")) {
        ImGui::Spacing();
        ImGui::TextColored(NV_TEXT_DIM, "%s", L.langLabel);
        ImGui::SameLine(180.f);
        const char* langs[] = { "English", "Turkce" };
        ImGui::SetNextItemWidth(160.f);
        ImGui::Combo("##lang", &m->currentLangIdx, langs, 2);
        ImGui::Spacing();
        SectionHeader("About");
        float lw = 240.f;
        StatRow("Application",  "OMURG Virtual GPU Control Panel v2.0", NV_TEXT, lw);
        StatRow("Version",      "2.0.0",                                 NV_TEXT, lw);
        StatRow("Architecture", "x64 (AVX2 / SSE4.2)",                  NV_TEXT, lw);
        StatRow("GPU APIs",     "FX150 + FX160  (VirtualGPU.h v2)",     NV_TEXT, lw);
        StatRow("Build Date",   __DATE__,                                 NV_TEXT, lw);
        ImGui::Spacing();
        SectionHeader("FX160 Highlights");
        StatRow("VRAM",             "3 GB (3072 MB) fixed",              NV_BLUE, lw);
        StatRow("CPU Compat Boost", "+50% (x1.5 multiplier)",            NV_BLUE, lw);
        StatRow("Processing Cap",   "+50% (x1.5 multiplier)",            NV_BLUE, lw);
        StatRow("Compute Units",    "12  (auto-scaled with CPU threads)", NV_BLUE, lw);
        StatRow("Clock Speed",      "1800 MHz  (FX150: 1200 MHz)",       NV_BLUE, lw);
        StatRow("Async Compute",    "4 independent queues",               NV_BLUE, lw);
        StatRow("Tile Size",        "32 px  (FX150: 64 px)",             NV_BLUE, lw);
        StatRow("Max Texture",      "8192 x 8192  (FX150: 4096)",        NV_BLUE, lw);
        ImGui::Spacing();
        SectionHeader("Links");
        if (BadgeButton("GitHub Repository", NV_TEXT_DIM, 200.f))
            ShellExecuteA(nullptr, "open",
                "https://github.com/gamegameromur-a11y/OMURG",
                nullptr, nullptr, SW_SHOW);
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// WinMain
// =============================================================================

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static OMURGGui* g_gui = nullptr;

static LRESULT CALLBACK WndProc(HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;
    switch (msg) {
    case WM_SIZE:
        if (g_gui && wParam != SIZE_MINIMIZED)
            g_gui->resize(LOWORD(lParam), HIWORD(lParam));
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    WNDCLASSEXW wc = { sizeof(wc) };
    wc.style         = CS_CLASSDC;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = L"OMURGWnd";
    wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_OMURG));
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowW(
        L"OMURGWnd", L"OMURG Virtual GPU Control Panel v2.0",
        WS_OVERLAPPEDWINDOW,
        100, 100, 1400, 860,
        nullptr, nullptr, hInstance, nullptr);

    OMURGGui gui;
    g_gui = &gui;

    if (!gui.init(hwnd)) {
        MessageBoxA(nullptr, "Failed to initialize OMURG.", "Error",
                    MB_OK | MB_ICONERROR);
        return 1;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg = {};
    while (msg.message != WM_QUIT) {
        if (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        } else {
            gui.render();
        }
    }

    gui.shutdown();
    g_gui = nullptr;
    DestroyWindow(hwnd);
    UnregisterClassW(L"OMURGWnd", hInstance);
    return 0;
}
