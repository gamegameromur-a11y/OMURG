// =============================================================================
// OMURG - GUI.cpp  [v3.0 — Sharp NVIDIA App UI + Real PnP Driver Install]
// =============================================================================
#include "GUI.h"
#include "FX150.h"
#include "FX160.h"
#include "FX1X0.h"
#include "VirtualGPUDriver.h"
#include "Updater.h"
#include "Support.h"

#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include <d3d11.h>
#include <shellapi.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "shell32.lib")

#include <string>
#include <vector>
#include <memory>
#include <format>
#include <algorithm>
#include <cstring>
#include <cmath>

// =============================================================================
// Renk paleti — kesin NVIDIA App değerleri
// =============================================================================
namespace C {
    // Arka planlar
    static constexpr ImU32 BG_BASE    = IM_COL32( 13,  13,  13, 255); // #0d0d0d
    static constexpr ImU32 BG_SIDE    = IM_COL32( 20,  20,  20, 255); // #141414
    static constexpr ImU32 BG_CARD    = IM_COL32( 28,  28,  28, 255); // #1c1c1c
    static constexpr ImU32 BG_CARD2   = IM_COL32( 34,  34,  34, 255); // #222222
    static constexpr ImU32 BG_INPUT   = IM_COL32( 22,  22,  22, 255); // #161616
    static constexpr ImU32 BG_HOVER   = IM_COL32( 40,  40,  40, 255); // hover state
    static constexpr ImU32 BG_HEADER  = IM_COL32( 16,  16,  16, 255); // #101010
    // Separator
    static constexpr ImU32 SEP        = IM_COL32( 45,  45,  45, 255);
    static constexpr ImU32 SEP_LIGHT  = IM_COL32( 55,  55,  55, 255);
    // Metin
    static constexpr ImU32 TEXT_WHITE = IM_COL32(242, 242, 242, 255);
    static constexpr ImU32 TEXT_MID   = IM_COL32(160, 160, 160, 255);
    static constexpr ImU32 TEXT_DIM   = IM_COL32( 90,  90,  90, 255);
    // NVIDIA yeşil
    static constexpr ImU32 GREEN      = IM_COL32(118, 185,   0, 255); // #76b900
    static constexpr ImU32 GREEN_DIM  = IM_COL32( 58,  92,   0, 255);
    static constexpr ImU32 GREEN_GLOW = IM_COL32( 80, 130,   0,  60);
    // Durum renkleri
    static constexpr ImU32 RED        = IM_COL32(220,  60,  60, 255);
    static constexpr ImU32 ORANGE     = IM_COL32(230, 140,   0, 255);
    static constexpr ImU32 BLUE       = IM_COL32( 60, 160, 255, 255);
    static constexpr ImU32 BLUE_DIM   = IM_COL32( 20,  70, 140, 255);
    // Nav seçili
    static constexpr ImU32 NAV_SEL    = IM_COL32( 32,  32,  32, 255);

    // ImVec4 versiyonları (ImGui API için)
    static ImVec4 v4(ImU32 col) {
        return ImVec4(
            ((col >>  0) & 0xFF) / 255.f,
            ((col >>  8) & 0xFF) / 255.f,
            ((col >> 16) & 0xFF) / 255.f,
            ((col >> 24) & 0xFF) / 255.f);
    }
    static ImVec4 GREEN4      = { 118/255.f, 185/255.f,   0/255.f, 1.f };
    static ImVec4 GREEN_DIM4  = {  58/255.f,  92/255.f,   0/255.f, 1.f };
    static ImVec4 GREEN_DARK4 = {  30/255.f,  50/255.f,   0/255.f, 1.f };
    static ImVec4 RED4        = { 220/255.f,  60/255.f,  60/255.f, 1.f };
    static ImVec4 ORANGE4     = { 230/255.f, 140/255.f,   0/255.f, 1.f };
    static ImVec4 BLUE4       = {  60/255.f, 160/255.f, 255/255.f, 1.f };
    static ImVec4 TEXT_WHITE4 = { 242/255.f, 242/255.f, 242/255.f, 1.f };
    static ImVec4 TEXT_MID4   = { 160/255.f, 160/255.f, 160/255.f, 1.f };
    static ImVec4 TEXT_DIM4   = {  90/255.f,  90/255.f,  90/255.f, 1.f };
    static ImVec4 TRANSP      = {  0, 0, 0, 0 };
}

// =============================================================================
// Tema uygula
// =============================================================================
static void applyTheme() {
    ImGuiStyle& s = ImGui::GetStyle();
    ImGui::StyleColorsDark();

    s.WindowRounding    = 0.f;
    s.ChildRounding     = 4.f;
    s.FrameRounding     = 3.f;
    s.PopupRounding     = 4.f;
    s.ScrollbarRounding = 3.f;
    s.GrabRounding      = 3.f;
    s.TabRounding       = 3.f;
    s.WindowBorderSize  = 0.f;
    s.ChildBorderSize   = 0.f;
    s.FrameBorderSize   = 0.f;
    s.ItemSpacing       = { 8.f, 6.f };
    s.ItemInnerSpacing  = { 6.f, 4.f };
    s.FramePadding      = { 10.f, 5.f };
    s.WindowPadding     = { 0.f, 0.f };
    s.IndentSpacing     = 14.f;
    s.ScrollbarSize     = 7.f;
    s.GrabMinSize       = 7.f;
    s.CellPadding       = { 6.f, 4.f };

    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg]              = { 13/255.f, 13/255.f, 13/255.f, 1.f };
    c[ImGuiCol_ChildBg]               = { 28/255.f, 28/255.f, 28/255.f, 1.f };
    c[ImGuiCol_PopupBg]               = { 22/255.f, 22/255.f, 22/255.f, 1.f };
    c[ImGuiCol_Border]                = { 45/255.f, 45/255.f, 45/255.f, 1.f };
    c[ImGuiCol_BorderShadow]          = C::TRANSP;
    c[ImGuiCol_FrameBg]               = { 22/255.f, 22/255.f, 22/255.f, 1.f };
    c[ImGuiCol_FrameBgHovered]        = { 38/255.f, 38/255.f, 38/255.f, 1.f };
    c[ImGuiCol_FrameBgActive]         = { 44/255.f, 44/255.f, 44/255.f, 1.f };
    c[ImGuiCol_TitleBg]               = { 13/255.f, 13/255.f, 13/255.f, 1.f };
    c[ImGuiCol_TitleBgActive]         = { 13/255.f, 13/255.f, 13/255.f, 1.f };
    c[ImGuiCol_ScrollbarBg]           = { 13/255.f, 13/255.f, 13/255.f, 1.f };
    c[ImGuiCol_ScrollbarGrab]         = { 50/255.f, 50/255.f, 50/255.f, 1.f };
    c[ImGuiCol_ScrollbarGrabHovered]  = { 65/255.f, 65/255.f, 65/255.f, 1.f };
    c[ImGuiCol_ScrollbarGrabActive]   = { 80/255.f, 80/255.f, 80/255.f, 1.f };
    c[ImGuiCol_CheckMark]             = C::GREEN4;
    c[ImGuiCol_SliderGrab]            = C::GREEN4;
    c[ImGuiCol_SliderGrabActive]      = { 140/255.f, 210/255.f, 0.f, 1.f };
    c[ImGuiCol_Button]                = C::GREEN_DARK4;
    c[ImGuiCol_ButtonHovered]         = C::GREEN_DIM4;
    c[ImGuiCol_ButtonActive]          = C::GREEN4;
    c[ImGuiCol_Header]                = { 35/255.f, 35/255.f, 35/255.f, 1.f };
    c[ImGuiCol_HeaderHovered]         = { 45/255.f, 45/255.f, 45/255.f, 1.f };
    c[ImGuiCol_HeaderActive]          = C::GREEN_DARK4;
    c[ImGuiCol_Separator]             = { 45/255.f, 45/255.f, 45/255.f, 1.f };
    c[ImGuiCol_SeparatorHovered]      = C::GREEN_DIM4;
    c[ImGuiCol_SeparatorActive]       = C::GREEN4;
    c[ImGuiCol_Tab]                   = { 20/255.f, 20/255.f, 20/255.f, 1.f };
    c[ImGuiCol_TabHovered]            = { 35/255.f, 35/255.f, 35/255.f, 1.f };
    c[ImGuiCol_TabActive]             = C::GREEN_DARK4;
    c[ImGuiCol_PlotLines]             = C::GREEN4;
    c[ImGuiCol_PlotLinesHovered]      = { 140/255.f, 210/255.f, 0.f, 1.f };
    c[ImGuiCol_PlotHistogram]         = C::GREEN4;
    c[ImGuiCol_PlotHistogramHovered]  = { 140/255.f, 210/255.f, 0.f, 1.f };
    c[ImGuiCol_TableHeaderBg]         = { 20/255.f, 20/255.f, 20/255.f, 1.f };
    c[ImGuiCol_TableBorderStrong]     = { 50/255.f, 50/255.f, 50/255.f, 1.f };
    c[ImGuiCol_TableBorderLight]      = { 38/255.f, 38/255.f, 38/255.f, 1.f };
    c[ImGuiCol_TextSelectedBg]        = C::GREEN_DARK4;
    c[ImGuiCol_NavHighlight]          = C::GREEN4;
    c[ImGuiCol_Text]                  = C::TEXT_WHITE4;
    c[ImGuiCol_TextDisabled]          = C::TEXT_DIM4;
    c[ImGuiCol_ResizeGrip]            = C::TRANSP;
    c[ImGuiCol_ResizeGripHovered]     = C::GREEN_DIM4;
    c[ImGuiCol_ResizeGripActive]      = C::GREEN4;
    c[ImGuiCol_DragDropTarget]        = C::GREEN4;
}

// =============================================================================
// Çizim yardımcıları
// =============================================================================

// Düz renk dikdörtgen
static void FillRect(ImDrawList* dl, ImVec2 p0, ImVec2 p1, ImU32 col, float r = 0.f) {
    dl->AddRectFilled(p0, p1, col, r);
}
// Kenarlıklı dikdörtgen
static void StrokeRect(ImDrawList* dl, ImVec2 p0, ImVec2 p1, ImU32 col, float r = 0.f, float t = 1.f) {
    dl->AddRect(p0, p1, col, r, 0, t);
}

// Keskin progress bar — NVIDIA App tarzı
static void ProgressBar(ImDrawList* dl, ImVec2 pos, float width, float height,
                         float fraction, ImU32 fillCol, ImU32 trackCol = C::BG_INPUT) {
    fraction = std::max(0.f, std::min(fraction, 1.f));
    // Track
    dl->AddRectFilled(pos, { pos.x + width, pos.y + height }, trackCol, 1.f);
    // Fill
    float fw = fraction * width;
    if (fw > 1.f)
        dl->AddRectFilled(pos, { pos.x + fw, pos.y + height }, fillCol, 1.f);
    // Top highlight on fill
    if (fw > 2.f)
        dl->AddLine({ pos.x, pos.y + 1.f }, { pos.x + fw, pos.y + 1.f },
                    IM_COL32(255,255,255, 20));
}

// Bölüm başlığı — sol yeşil çizgi + kalın label
static void DrawSectionLabel(const char* label, float extraSpacingTop = 8.f) {
    ImGui::Dummy({ 0.f, extraSpacingTop });
    ImDrawList* dl  = ImGui::GetWindowDrawList();
    ImVec2 p        = ImGui::GetCursorScreenPos();
    float  w        = ImGui::GetContentRegionAvail().x;
    // Sol bar
    dl->AddRectFilled(p, { p.x + 2.f, p.y + 16.f }, C::GREEN);
    ImGui::SetCursorScreenPos({ p.x + 9.f, p.y });
    ImGui::TextColored(C::TEXT_WHITE4, "%s", label);
    ImGui::SetCursorScreenPos({ p.x, p.y + 20.f });
    // Alt çizgi
    dl->AddLine({ p.x, p.y + 20.f }, { p.x + w, p.y + 20.f }, C::SEP);
    ImGui::Dummy({ w, 8.f });
}

// İki satırlı stat widget — büyük değer, küçük etiket
static void BigStat(const char* label, const char* value,
                    ImVec4 valCol = { 242/255.f,242/255.f,242/255.f,1.f }) {
    ImGui::TextColored(C::TEXT_DIM4, "%s", label);
    ImGui::TextColored(valCol, "%s", value);
    ImGui::Spacing();
}

// Yatay etiket-değer satırı
static void StatLine(const char* label, const char* value,
                     ImVec4 valCol = { 160/255.f,160/255.f,160/255.f,1.f },
                     float  labelW = 200.f) {
    ImGui::TextColored(C::TEXT_DIM4, "%s", label);
    ImGui::SameLine(labelW);
    ImGui::TextColored(valCol, "%s", value);
}

// Pill badge (küçük etiket chip'i)
static void Pill(ImDrawList* dl, ImVec2 pos, const char* text,
                 ImU32 bgCol, ImU32 textCol) {
    ImVec2 ts = ImGui::CalcTextSize(text);
    float pw = ts.x + 10.f, ph = ts.y + 4.f;
    dl->AddRectFilled(pos, { pos.x + pw, pos.y + ph }, bgCol, ph * 0.5f);
    dl->AddText({ pos.x + 5.f, pos.y + 2.f }, textCol, text);
}

// Büyük aksiyon düğmesi — NVIDIA tarzı
static bool ActionButton(const char* label, float w = 0.f, float h = 32.f,
                          bool danger = false) {
    ImVec4 base = danger
        ? ImVec4{ 80/255.f, 20/255.f, 20/255.f, 1.f }
        : C::GREEN_DARK4;
    ImVec4 hov  = danger
        ? ImVec4{ 120/255.f, 35/255.f, 35/255.f, 1.f }
        : C::GREEN_DIM4;
    ImVec4 act  = danger ? C::RED4 : C::GREEN4;
    ImVec4 txt  = danger ? C::RED4 : C::GREEN4;

    ImGui::PushStyleColor(ImGuiCol_Button,        base);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, hov);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  act);
    ImGui::PushStyleColor(ImGuiCol_Text,          txt);
    if (w == 0.f) w = ImGui::GetContentRegionAvail().x;
    bool clicked = ImGui::Button(label, { w, h });
    ImGui::PopStyleColor(4);
    return clicked;
}

// Kart çerçevesi — rounded dark panel
static bool BeginCard(const char* id, float w = 0.f, float h = 0.f,
                       bool scrollable = false) {
    if (w == 0.f) w = ImGui::GetContentRegionAvail().x;
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4{ 28/255.f,28/255.f,28/255.f,1.f });
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 4.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(16.f, 14.f));
    ImGuiWindowFlags fl = scrollable ? 0 : ImGuiWindowFlags_NoScrollbar;
    return ImGui::BeginChild(id, { w, h }, true, fl);
}
static void EndCard() {
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
}

// İki sütunlu kart satırı
static void TwoCol(std::function<void()> left, std::function<void()> right,
                   float gap = 10.f) {
    float tw = ImGui::GetContentRegionAvail().x;
    float cw = (tw - gap) * 0.5f;
    if (BeginCard("##lcol", cw)) { left(); }  EndCard();
    ImGui::SameLine(0.f, gap);
    if (BeginCard("##rcol", cw)) { right(); } EndCard();
}

// Üç sütunlu mini stat kart
static void ThreeStatCards(const char* l1, const char* v1, ImU32 c1,
                            const char* l2, const char* v2, ImU32 c2,
                            const char* l3, const char* v3, ImU32 c3) {
    float tw  = ImGui::GetContentRegionAvail().x;
    float gap = 8.f;
    float cw  = (tw - gap * 2.f) / 3.f;

    auto card = [&](const char* id, const char* label, const char* val, ImU32 col) {
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4{ 28/255.f,28/255.f,28/255.f,1.f });
        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 4.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14.f, 12.f));
        if (ImGui::BeginChild(id, { cw, 64.f }, true, ImGuiWindowFlags_NoScrollbar)) {
            ImGui::TextColored(C::TEXT_DIM4, "%s", label);
            ImGui::TextColored(ImVec4(
                ((col>> 0)&0xFF)/255.f,
                ((col>> 8)&0xFF)/255.f,
                ((col>>16)&0xFF)/255.f, 1.f), "%s", val);
        }
        ImGui::EndChild();
        ImGui::PopStyleVar(2); ImGui::PopStyleColor();
    };

    card("##sc1", l1, v1, c1); ImGui::SameLine(0.f, gap);
    card("##sc2", l2, v2, c2); ImGui::SameLine(0.f, gap);
    card("##sc3", l3, v3, c3);
}

// =============================================================================
// Impl
// =============================================================================
struct OMURGGui::Impl {
    HWND                    hwnd      = nullptr;
    ID3D11Device*           device    = nullptr;
    ID3D11DeviceContext*    context   = nullptr;
    IDXGISwapChain*         swapChain = nullptr;
    ID3D11RenderTargetView* mainRTV   = nullptr;

    int  langIdx    = 0; // 0=EN 1=TR
    int  navSection = 0; // 0=GPU 1=Perf 2=Driver 3=Update 4=Support 5=Settings

    // GPU
    struct GPUModel { const char* name; uint64_t vramBytes; int gpuGen; }; // 0=FX150 1=FX160 2=FX170 3=FX180 4=FX190
    static const GPUModel MODELS[];
    static const int      MODEL_COUNT = 9;
    int  gpuSel      = 3; // varsayılan FX160
    bool gpuReady    = false;
    int  gpuGen      = 0;  // 0=FX150 1=FX160 2=FX170 3=FX180 4=FX190
    std::unique_ptr<VirtualGPU> gpu;

    // Sürücü yöneticisi
    VirtualGPUDriver          drvMgr;
    std::vector<VGPUDeviceInfo> installedDevs;
    bool devsRefreshed = false;
    std::wstring drvStatus;
    bool drvStatusOk = true;
    bool drvInstalling = false;

    // Updater / Support
    std::unique_ptr<Updater>       updater;
    std::unique_ptr<SupportClient> support;
    std::string updateStatus;
    bool        updateRunning = false;
    char sName[128]={}, sEmail[128]={}, sSubj[256]={}, sMsg[2048]={};
    std::string sResult; bool sResultOk = false;

    // Grafikler
    static constexpr int HIST = 120;
    float fpsHist[HIST]={};  int fpsIdx=0;
    float tempHist[HIST]={}; int tmpIdx=0;
    float pwrHist[HIST]={};  int pwrIdx=0;
    float vramHist[HIST]={}; int vrmIdx=0;

    // Mem dump
    std::string memDump;
};

const OMURGGui::Impl::GPUModel OMURGGui::Impl::MODELS[] = {
    // FX150 series
    { "FX150  [512 MB VRAM]",           512ull  << 20, 0 },
    { "FX150  [1 GB VRAM]",            1024ull  << 20, 0 },
    { "FX150  [2 GB VRAM]",            2048ull  << 20, 0 },
    // FX160 series — +50% boost, 3 GB
    { "FX160  [3 GB VRAM]",            3072ull  << 20, 1 },
    { "FX160  [3 GB | +50% Boost]",    3072ull  << 20, 1 },
    // FX170 series — +60% boost, 1 GB
    { "FX170  [1 GB VRAM | +60% Boost]",1024ull << 20, 2 },
    // FX180 series — +70% boost, 2 GB
    { "FX180  [2 GB VRAM | +70% Boost]",2048ull << 20, 3 },
    // FX190 flagship — +80% boost, 4 GB
    { "FX190  [4 GB VRAM | +80% Boost]",4096ull << 20, 4 },
    { "FX190  [4 GB | Max Performance]", 4096ull << 20, 4 },
};

OMURGGui::OMURGGui()  : m(std::make_unique<Impl>()) {}
OMURGGui::~OMURGGui() { shutdown(); }

// =============================================================================
// Init / Shutdown / Resize
// =============================================================================
bool OMURGGui::init(HWND hwnd) {
    m->hwnd = hwnd;
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount       = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage       = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow      = hwnd;
    sd.SampleDesc.Count  = 1;
    sd.Windowed          = TRUE;
    sd.SwapEffect        = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    D3D_FEATURE_LEVEL fl = D3D_FEATURE_LEVEL_11_0;
    if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE,
            nullptr, 0, &fl, 1, D3D11_SDK_VERSION, &sd,
            &m->swapChain, &m->device, nullptr, &m->context)))
        return false;
    createRTV();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io     = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename  = nullptr;
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(m->device, m->context);
    applyTheme();
    m->updater = std::make_unique<Updater>();
    m->support = std::make_unique<SupportClient>();
    return true;
}

void OMURGGui::createRTV() {
    ID3D11Texture2D* bb = nullptr;
    m->swapChain->GetBuffer(0, IID_PPV_ARGS(&bb));
    if (bb) { m->device->CreateRenderTargetView(bb,nullptr,&m->mainRTV); bb->Release(); }
}

void OMURGGui::shutdown() {
    if (m->gpuReady && m->gpu) { m->gpu->shutdown(); m->gpuReady = false; }
    ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
    if (m->mainRTV)  { m->mainRTV->Release();  m->mainRTV  = nullptr; }
    if (m->swapChain){ m->swapChain->Release(); m->swapChain= nullptr; }
    if (m->context)  { m->context->Release();  m->context  = nullptr; }
    if (m->device)   { m->device->Release();   m->device   = nullptr; }
}

void OMURGGui::resize(UINT w, UINT h) {
    if (m->mainRTV) { m->mainRTV->Release(); m->mainRTV = nullptr; }
    m->swapChain->ResizeBuffers(0, w, h, DXGI_FORMAT_UNKNOWN, 0);
    createRTV();
}

// =============================================================================
// Ana render döngüsü
// =============================================================================
void OMURGGui::render() {
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    ImGuiIO& io   = ImGui::GetIO();
    const float W = io.DisplaySize.x;
    const float H = io.DisplaySize.y;
    const float HEADER_H = 54.f;
    const float SIDE_W   = 220.f;
    const float BODY_H   = H - HEADER_H;

    // Root window
    ImGui::SetNextWindowPos({0,0}, ImGuiCond_Always);
    ImGui::SetNextWindowSize({W,H}, ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {0.f,0.f});
    ImGui::Begin("##root", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus |
        ImGuiWindowFlags_NoNav);
    ImGui::PopStyleVar();

    ImDrawList* DL = ImGui::GetWindowDrawList();

    // =========================================================================
    // HEADER
    // =========================================================================
    FillRect(DL, {0,0}, {W, HEADER_H}, C::BG_HEADER);
    DL->AddLine({0, HEADER_H-1}, {W, HEADER_H-1}, C::SEP);

    // Logo — yeşil dikdörtgen + metin
    DL->AddRectFilled({18.f, 14.f}, {22.f, 40.f}, C::GREEN);
    DL->AddText(ImGui::GetFont(), 15.f, {28.f, 14.f}, C::GREEN,      "OMURG");
    DL->AddText(ImGui::GetFont(), 12.f, {28.f, 32.f}, C::TEXT_DIM,   "Virtual GPU Control Panel");

    // Sağ durum pill
    {
        bool on   = m->gpuReady;
        ImU32 pc  = on ? C::GREEN : C::RED;
        std::string gpuLabel = on
            ? std::format("  GPU ONLINE  [{}]  ", m->gpuGen==4?"FX190":m->gpuGen==3?"FX180":m->gpuGen==2?"FX170":m->gpuGen==1?"FX160":"FX150")
            : "  GPU OFFLINE  ";
        ImVec2 ts = ImGui::CalcTextSize(gpuLabel.c_str());
        float px  = W - ts.x - 28.f;
        float py  = (HEADER_H - 24.f) * 0.5f;
        DL->AddRectFilled({px-2.f, py}, {px+ts.x+14.f, py+24.f},
                          IM_COL32(((pc>>0)&0xFF)/5, ((pc>>8)&0xFF)/5,
                                   ((pc>>16)&0xFF)/5, 255), 12.f);
        DL->AddRect({px-2.f, py}, {px+ts.x+14.f, py+24.f},
                    IM_COL32(((pc>>0)&0xFF), ((pc>>8)&0xFF),
                             ((pc>>16)&0xFF), 120), 12.f, 0, 1.f);
        DL->AddText(ImGui::GetFont(), 12.f, {px+6.f, py+6.f}, pc,
                    gpuLabel.c_str());
    }

    // Yönetici uyarısı
    if (!VirtualGPUDriver::isElevated()) {
        float tw = ImGui::CalcTextSize("! Admin required for driver install").x;
        DL->AddText(ImGui::GetFont(), 11.f,
                    {W - tw - 34.f - 260.f, HEADER_H*0.5f - 6.f},
                    C::ORANGE, "! Admin required for driver install");
    }

    // =========================================================================
    // BODY
    // =========================================================================
    ImGui::SetCursorPos({0.f, HEADER_H});
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, {0.f, 0.f});

    // SIDEBAR
    FillRect(DL, {0.f, HEADER_H}, {SIDE_W, H}, C::BG_SIDE);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4{20/255.f,20/255.f,20/255.f,1.f});
    ImGui::BeginChild("##side", {SIDE_W, BODY_H}, false, ImGuiWindowFlags_NoScrollbar);

    ImGui::Dummy({0.f, 12.f});

    struct NavItem { const char* labelEN; const char* labelTR; ImU32 dot; };
    static const NavItem NAV[] = {
        { "GPU Control",    "GPU Kontrol",       C::GREEN  },
        { "Performance",    "Performans",         C::BLUE   },
        { "Driver Install", "Surucu Kurulumu",    C::ORANGE },
        { "Updater",        "Guncelleyici",        C::GREEN  },
        { "Support",        "Destek",              IM_COL32(160,80,220,255) },
        { "Settings",       "Ayarlar",             C::TEXT_DIM },
    };

    ImDrawList* sdl = ImGui::GetWindowDrawList();
    for (int i = 0; i < 6; ++i) {
        bool sel = (m->navSection == i);
        const char* lbl = (m->langIdx == 0) ? NAV[i].labelEN : NAV[i].labelTR;
        ImVec2 p = ImGui::GetCursorScreenPos();

        if (sel) {
            sdl->AddRectFilled(p, {p.x + SIDE_W, p.y + 40.f}, C::NAV_SEL);
            sdl->AddRectFilled(p, {p.x + 2.f,    p.y + 40.f}, C::GREEN);
        }

        // Renkli dot
        sdl->AddCircleFilled({p.x + 18.f, p.y + 20.f}, 3.5f,
                             sel ? NAV[i].dot
                                 : IM_COL32(70,70,70,255));

        ImGui::PushStyleColor(ImGuiCol_Button,
            sel ? ImVec4{32/255.f,32/255.f,32/255.f,1.f} : ImVec4{0,0,0,0});
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4{38/255.f,38/255.f,38/255.f,1.f});
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4{28/255.f,28/255.f,28/255.f,1.f});
        ImGui::PushStyleColor(ImGuiCol_Text,
            sel ? C::TEXT_WHITE4 : C::TEXT_DIM4);

        char bid[64]; std::snprintf(bid,64,"   %s##n%d", lbl, i);
        if (ImGui::Button(bid, {SIDE_W, 40.f})) m->navSection = i;
        ImGui::PopStyleColor(4);
    }

    // Alt bilgi
    ImGui::SetCursorPosY(BODY_H - 88.f);
    sdl->AddLine(ImGui::GetCursorScreenPos(),
                 {ImGui::GetCursorScreenPos().x + SIDE_W,
                  ImGui::GetCursorScreenPos().y}, C::SEP);
    ImGui::Dummy({0.f, 8.f});

    auto sideInfo = [&](const char* lbl, const char* val, ImU32 vcol = C::TEXT_MID) {
        ImGui::SetCursorPosX(14.f);
        sdl->AddText(ImGui::GetFont(), 11.f, ImGui::GetCursorScreenPos(),
                     C::TEXT_DIM, lbl);
        ImGui::SameLine(80.f);
        sdl->AddText(ImGui::GetFont(), 11.f, ImGui::GetCursorScreenPos(),
                     vcol, val);
        ImGui::Dummy({0.f, 14.f});
    };

    if (m->gpuReady && m->gpu)
        sideInfo("Model", m->gpu->descriptor().modelName.c_str(), C::GREEN);
    else
        sideInfo("Model", "--");
    sideInfo("Version", "3.0.0");
    sideInfo("Build", __DATE__);

    ImGui::EndChild();
    ImGui::PopStyleColor();

    // Sidebar sağ kenarlığı
    DL->AddLine({SIDE_W, HEADER_H}, {SIDE_W, H}, C::SEP);

    // CONTENT AREA
    ImGui::SameLine(0.f, 0.f);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4{13/255.f,13/255.f,13/255.f,1.f});
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {22.f, 18.f});
    ImGui::BeginChild("##content", {W - SIDE_W - 1.f, BODY_H}, false,
                      ImGuiWindowFlags_HorizontalScrollbar);
    ImGui::PopStyleVar();

    switch (m->navSection) {
        case 0: renderGPU();    break;
        case 1: renderPerf();   break;
        case 2: renderDriver(); break;
        case 3: renderUpdate(); break;
        case 4: renderSupport();break;
        case 5: renderSettings();break;
    }

    ImGui::EndChild();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(); // ItemSpacing

    ImGui::End();

    // Present
    ImGui::Render();
    const float cc[4] = {13/255.f,13/255.f,13/255.f,1.f};
    m->context->OMSetRenderTargets(1, &m->mainRTV, nullptr);
    m->context->ClearRenderTargetView(m->mainRTV, cc);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    m->swapChain->Present(1, 0);
}

// =============================================================================
// GPU sekmesi
// =============================================================================
void OMURGGui::renderGPU() {
    DrawSectionLabel("GPU Selection", 2.f);

    // Model seçici
    const char* items[Impl::MODEL_COUNT];
    for (int i = 0; i < Impl::MODEL_COUNT; ++i) items[i] = Impl::MODELS[i].name;
    ImGui::SetNextItemWidth(380.f);
    ImGui::Combo("##gpusel", &m->gpuSel, items, Impl::MODEL_COUNT);

    ImGui::SameLine(0.f, 12.f);
    if (Impl::MODELS[m->gpuSel].gpuGen > 0) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        Pill(dl, p, " FX160 ", IM_COL32(10,40,100,200), C::BLUE);
        ImGui::Dummy({70.f, 20.f}); ImGui::SameLine(0.f, 8.f);
    }

    if (!m->gpuReady) {
        if (ActionButton("Initialize GPU", 150.f)) {
            const auto& sel = Impl::MODELS[m->gpuSel];
            switch (sel.gpuGen) {
            case 1: { auto g=std::make_unique<FX160>(sel.vramBytes); if(g->initialize()){m->gpu=std::move(g);m->gpuGen=1;m->gpuReady=true;} break; }
            case 2: { auto g=std::make_unique<FX170>(sel.vramBytes); if(g->initialize()){m->gpu=std::move(g);m->gpuGen=2;m->gpuReady=true;} break; }
            case 3: { auto g=std::make_unique<FX180>(sel.vramBytes); if(g->initialize()){m->gpu=std::move(g);m->gpuGen=3;m->gpuReady=true;} break; }
            case 4: { auto g=std::make_unique<FX190>(sel.vramBytes); if(g->initialize()){m->gpu=std::move(g);m->gpuGen=4;m->gpuReady=true;} break; }
            default:{ auto g=std::make_unique<FX150>(sel.vramBytes); if(g->initialize()){m->gpu=std::move(g);m->gpuGen=0;m->gpuReady=true;} break; }
            }
        }
    } else {
        if (ActionButton("Shutdown GPU", 150.f, 32.f, true)) {
            m->gpu->shutdown(); m->gpuReady=false; m->gpuGen=0;
        }
    }

    ImGui::Dummy({0.f, 6.f});

    // Model önizleme kartları
    if (!m->gpuReady) {
        DrawSectionLabel("Available Models");
        float tw = ImGui::GetContentRegionAvail().x;
        float cw = (tw - 10.f) * 0.5f;
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, {10.f, 10.f});
        for (int i = 0; i < Impl::MODEL_COUNT; ++i) {
            if (i % 2 != 0) ImGui::SameLine();
            bool isSel  = (i == m->gpuSel);
            int  gen    = Impl::MODELS[i].gpuGen;
            ImGui::PushStyleColor(ImGuiCol_ChildBg,
                isSel ? ImVec4{22/255.f, 38/255.f, 10/255.f, 1.f}
                       : ImVec4{28/255.f, 28/255.f, 28/255.f, 1.f});
            ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 4.f);
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {14.f, 10.f});
            ImGui::BeginChild(std::format("##mc{}", i).c_str(),
                              {cw, 60.f}, true, ImGuiWindowFlags_NoScrollbar);

            ImDrawList* cl = ImGui::GetWindowDrawList();
            if (isSel) {
                ImVec2 cp = ImGui::GetWindowPos();
                cl->AddRect(cp, {cp.x+cw, cp.y+60.f}, C::GREEN, 4.f, 0, 1.5f);
            }
            ImGui::TextColored(gen>1?C::ORANGE4:gen==1?C::BLUE4:C::GREEN4,
                               "%s", Impl::MODELS[i].name);
            ImGui::TextColored(C::TEXT_DIM4,
                is160 ? "3 GB VRAM  |  12 CU  |  1800 MHz  |  +50% Boost"
                       : "up to 2 GB VRAM  |  8 CU  |  1200 MHz");

            ImGui::EndChild();
            ImGui::PopStyleVar(2); ImGui::PopStyleColor();
        }
        ImGui::PopStyleVar();
        return;
    }

    // GPU aktif — live stats
    GPUStats stats = m->gpu->queryStats();
    const GPUDescriptor& desc = m->gpu->descriptor();
    float temp  = m->gpu->simulatedTemperature();
    float power = m->gpu->simulatedPowerDraw();
    float vramU = (float)stats.vramUsed / std::max((uint64_t)1, desc.vramBytes);
    float tempN = std::max(0.f, (temp - 30.f) / 65.f);
    float powerN= power / (m->gpuGen==4?180.f:m->gpuGen==3?130.f:m->gpuGen==2?85.f:m->gpuGen==1?110.f:75.f);

    // Grafikler güncelle
    m->fpsHist[m->fpsIdx]  = (float)stats.fps;     m->fpsIdx  = (m->fpsIdx +1)%Impl::HIST;
    m->tempHist[m->tmpIdx] = temp;                  m->tmpIdx  = (m->tmpIdx +1)%Impl::HIST;
    m->pwrHist[m->pwrIdx]  = power;                 m->pwrIdx  = (m->pwrIdx +1)%Impl::HIST;
    m->vramHist[m->vrmIdx] = vramU * 100.f;         m->vrmIdx  = (m->vrmIdx +1)%Impl::HIST;

    ImVec4 tempCol = (temp > 80.f) ? C::RED4 : (temp > 60.f) ? C::ORANGE4 : C::GREEN4;

    DrawSectionLabel("Live Statistics");

    // Üst 3 stat kart
    ThreeStatCards(
        "FPS",         std::format("{:.0f}", stats.fps).c_str(),       C::GREEN,
        "Temperature", std::format("{:.1f} C", temp).c_str(),
                       (temp>80.f)?C::RED:(temp>60.f)?C::ORANGE:C::GREEN,
        "Power",       std::format("{:.1f} W", power).c_str(),         C::ORANGE
    );

    ImGui::Dummy({0.f, 8.f});

    // İki sütun: FPS grafiği | VRAM + Thermal barlar
    float tw = ImGui::GetContentRegionAvail().x;
    float lw = tw * 0.60f - 5.f;
    float rw = tw * 0.40f - 5.f;

    if (BeginCard("##fps_card", lw, 180.f)) {
        ImGui::TextColored(C::TEXT_DIM4, "Frame Rate");
        ImGui::SameLine(); ImGui::SetCursorPosX(ImGui::GetContentRegionAvail().x - 60.f);
        ImGui::TextColored(C::GREEN4, "%.0f FPS", stats.fps);
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_FrameBg,   ImVec4{20/255.f,20/255.f,20/255.f,1.f});
        ImGui::PushStyleColor(ImGuiCol_PlotLines, C::GREEN4);
        char lbl[32]; std::snprintf(lbl,32,"%.0f", stats.fps);
        ImGui::PlotLines("##fps", m->fpsHist, Impl::HIST, m->fpsIdx,
                         lbl, 0.f, 200.f,
                         {ImGui::GetContentRegionAvail().x, 100.f});
        ImGui::PopStyleColor(2);
    }
    EndCard();

    ImGui::SameLine(0.f, 10.f);

    if (BeginCard("##bars_card", rw, 180.f)) {
        ImDrawList* dl2 = ImGui::GetWindowDrawList();

        auto bar = [&](const char* label, float frac, ImU32 col, const char* valStr) {
            ImGui::TextColored(C::TEXT_DIM4, "%s", label);
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 60.f);
            ImGui::TextColored(ImVec4(((col>>0)&0xFF)/255.f,
                                       ((col>>8)&0xFF)/255.f,
                                       ((col>>16)&0xFF)/255.f,1.f), "%s", valStr);
            ImVec2 bp = ImGui::GetCursorScreenPos();
            float bw  = ImGui::GetContentRegionAvail().x;
            ProgressBar(dl2, bp, bw, 6.f, frac, col, C::BG_INPUT);
            ImGui::Dummy({bw, 10.f});
            ImGui::Spacing();
        };

        bar("VRAM",
            vramU,
            C::GREEN,
            std::format("{:.0f}/{:.0f} MB",
                stats.vramUsed/1048576.0,
                desc.vramBytes/1048576.0).c_str());
        bar("Temperature",
            tempN,
            (temp>80.f)?C::RED:(temp>60.f)?C::ORANGE:C::GREEN,
            std::format("{:.1f} C", temp).c_str());
        bar("Power",
            powerN,
            C::ORANGE,
            std::format("{:.1f} W", power).c_str());

        if (m->gpuGen >= 1) {
            ImGui::Spacing();
            ImGui::TextColored(C::BLUE4, "CPU Boost x1.5  |  Async x4  |  32px Tile");
        }
    }
    EndCard();

    ImGui::Dummy({0.f, 6.f});
    DrawSectionLabel("Memory Diagnostics");

    if (BeginCard("##memd", 0.f, 0.f, true)) {
        if (ActionButton("Dump Memory Map", 180.f, 28.f))
            m->memDump = m->gpu->dumpMemoryMap();
        if (!m->memDump.empty()) {
            ImGui::SameLine(0.f, 10.f);
            if (ActionButton("Clear", 70.f, 28.f, true)) m->memDump.clear();
            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4{20/255.f,20/255.f,20/255.f,1.f});
            ImGui::InputTextMultiline("##md", m->memDump.data(), m->memDump.size(),
                {-1.f, 150.f}, ImGuiInputTextFlags_ReadOnly);
            ImGui::PopStyleColor();
        }
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Performance sekmesi
// =============================================================================
void OMURGGui::renderPerf() {
    DrawSectionLabel("Performance Monitor", 2.f);

    if (!m->gpuReady || !m->gpu) {
        if (BeginCard("##pna", 0.f, 60.f)) {
            ImGui::Spacing();
            ImGui::TextColored(C::TEXT_DIM4, "  No GPU active — go to GPU Control and initialize first.");
        }
        EndCard();
        return;
    }

    GPUStats stats  = m->gpu->queryStats();
    const GPUDescriptor& desc = m->gpu->descriptor();
    float temp  = m->gpu->simulatedTemperature();
    float power = m->gpu->simulatedPowerDraw();

    // Grafikleri güncelle
    m->fpsHist[m->fpsIdx]  = (float)stats.fps; m->fpsIdx  = (m->fpsIdx +1)%Impl::HIST;
    m->tempHist[m->tmpIdx] = temp;              m->tmpIdx  = (m->tmpIdx +1)%Impl::HIST;
    m->pwrHist[m->pwrIdx]  = power;             m->pwrIdx  = (m->pwrIdx +1)%Impl::HIST;
    m->vramHist[m->vrmIdx] = (float)stats.vramUsed / std::max((uint64_t)1, desc.vramBytes) * 100.f;
    m->vrmIdx = (m->vrmIdx + 1) % Impl::HIST;

    float tw  = ImGui::GetContentRegionAvail().x;
    float cw  = (tw - 10.f) * 0.5f;

    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, {10.f, 10.f});

    // Satır 1: FPS + Sıcaklık
    auto plotCard = [&](const char* id, const char* title, float* hist,
                        float vmin, float vmax, ImU32 col, const char* suffix) {
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4{28/255.f,28/255.f,28/255.f,1.f});
        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 4.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {14.f, 12.f});
        if (ImGui::BeginChild(id, {cw, 130.f}, true, ImGuiWindowFlags_NoScrollbar)) {
            float cur = hist[(m->fpsIdx + Impl::HIST - 1) % Impl::HIST];
            ImGui::TextColored(C::TEXT_DIM4, "%s", title);
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 80.f);
            char lbl[32]; std::snprintf(lbl,32,"%.1f%s", cur, suffix);
            ImGui::TextColored(ImVec4(((col>>0)&0xFF)/255.f,
                                       ((col>>8)&0xFF)/255.f,
                                       ((col>>16)&0xFF)/255.f,1.f), "%s", lbl);
            ImGui::PushStyleColor(ImGuiCol_FrameBg,   ImVec4{20/255.f,20/255.f,20/255.f,1.f});
            ImGui::PushStyleColor(ImGuiCol_PlotLines,
                ImVec4(((col>>0)&0xFF)/255.f,((col>>8)&0xFF)/255.f,
                       ((col>>16)&0xFF)/255.f,1.f));
            ImGui::PlotLines("##pl", hist, Impl::HIST,
                             (m->fpsIdx), lbl, vmin, vmax,
                             {ImGui::GetContentRegionAvail().x, 70.f});
            ImGui::PopStyleColor(2);
        }
        ImGui::EndChild();
        ImGui::PopStyleVar(2); ImGui::PopStyleColor();
    };

    plotCard("##fps2",  "Frame Rate",   m->fpsHist,  0.f,  200.f, C::GREEN,  " FPS");
    ImGui::SameLine(0.f, 10.f);
    plotCard("##tmp2",  "Temperature",  m->tempHist, 30.f, 95.f,
             (temp>80.f)?C::RED:(temp>60.f)?C::ORANGE:C::GREEN, " C");

    plotCard("##pwr2",  "Power Draw",   m->pwrHist,  0.f,
             (m->gpuGen==4?180.f:m->gpuGen==3?130.f:m->gpuGen==2?85.f:m->gpuGen==1?110.f:75.f), C::ORANGE, " W");
    ImGui::SameLine(0.f, 10.f);
    plotCard("##vrm2",  "VRAM Usage",   m->vramHist, 0.f,  100.f, C::BLUE,   "%");

    ImGui::PopStyleVar();

    ImGui::Dummy({0.f, 4.f});
    DrawSectionLabel("GPU Specifications");

    if (BeginCard("##specs", 0.f, 0.f, true)) {
        ImGui::Spacing();
        float lw = 240.f;
        StatLine("Model",           desc.modelName.c_str(),    C::GREEN4, lw);
        StatLine("Architecture",    m->gpuGen==4?"FX190 Gen3 Flagship":m->gpuGen==3?"FX180 Gen3 Mid":m->gpuGen==2?"FX170 Gen3 Entry":m->gpuGen==1?"FX160 Gen2":"FX150 Gen1", C::TEXT_MID4, lw);
        StatLine("VRAM",            std::format("{:.0f} MB", desc.vramBytes/1048576.0).c_str(), C::TEXT_MID4, lw);
        StatLine("Compute Units",   std::to_string(desc.computeUnits).c_str(), C::TEXT_MID4, lw);
        StatLine("Clock Speed",     std::format("{} MHz", desc.clockSpeedMHz).c_str(), C::TEXT_MID4, lw);
        StatLine("Max Texture",     std::format("{}x{}", desc.maxTextureSize, desc.maxTextureSize).c_str(), C::TEXT_MID4, lw);
        StatLine("Render Targets",  std::to_string(desc.maxRenderTargets).c_str(), C::TEXT_MID4, lw);
        if (m->gpuGen >= 1) {
            ImGui::Spacing();
            StatLine("CPU Compat Boost",  "+50%  (x1.5)",          C::BLUE4, lw);
            StatLine("Proc Capacity",     "+50%  (x1.5)",          C::BLUE4, lw);
            StatLine("Async Queues",      "4 independent queues",  C::BLUE4, lw);
            StatLine("Tile Size",         "32 px",                 C::BLUE4, lw);
        }
        ImGui::Spacing();

        // Feature chips
        ImGui::TextColored(C::TEXT_DIM4, "Feature Set:");
        ImGui::Spacing();
        uint32_t feat = (uint32_t)desc.features;
        auto chip = [&](const char* n, bool on) {
            ImU32 bg  = on ? IM_COL32(30,50,0,200) : IM_COL32(30,30,30,200);
            ImU32 txt = on ? C::GREEN : C::TEXT_DIM;
            ImU32 brd = on ? C::GREEN_DIM : IM_COL32(50,50,50,255);
            ImDrawList* cdl = ImGui::GetWindowDrawList();
            ImVec2 p = ImGui::GetCursorScreenPos();
            float fw = ImGui::CalcTextSize(n).x + 12.f;
            cdl->AddRectFilled(p, {p.x+fw, p.y+20.f}, bg, 3.f);
            cdl->AddRect(p, {p.x+fw, p.y+20.f}, brd, 3.f);
            cdl->AddText(ImGui::GetFont(), 11.f, {p.x+6.f, p.y+4.f}, txt, n);
            ImGui::Dummy({fw+4.f, 20.f}); ImGui::SameLine(0.f, 4.f);
        };
        chip("RAST",    feat&1);  chip("DEPTH",  feat&2);
        chip("STENCIL", feat&4);  chip("TEX2D",  feat&8);
        chip("TEXCUBE", feat&16); chip("MIP",    feat&32);
        chip("MSAA",    feat&64); chip("COMPUTE",feat&128);
        chip("GS",      feat&256);chip("TESS",   feat&512);
        chip("RT",      feat&1024);chip("SSE4",  feat&2048);
        chip("AVX2",    feat&4096);chip("ASYNC", feat&8192);
        ImGui::NewLine();
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Driver sekmesi — gerçek PnP kurulum
// =============================================================================
void OMURGGui::renderDriver() {
    DrawSectionLabel("Driver Installation", 2.f);

    bool elevated = VirtualGPUDriver::isElevated();

    // Yönetici uyarı kartı
    if (!elevated) {
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4{40/255.f,25/255.f,0/255.f,1.f});
        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 4.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {14.f, 12.f});
        if (ImGui::BeginChild("##admwarn", {ImGui::GetContentRegionAvail().x, 60.f},
                               true, ImGuiWindowFlags_NoScrollbar)) {
            ImGui::TextColored(C::ORANGE4, "  Administrator privileges required for driver installation.");
            ImGui::TextColored(C::TEXT_MID4, "  Click below to relaunch OMURG as Administrator.");
            if (ActionButton("Relaunch as Administrator", 260.f, 28.f)) {
                VirtualGPUDriver::relaunchAsAdmin(L"--install");
            }
        }
        ImGui::EndChild();
        ImGui::PopStyleVar(2); ImGui::PopStyleColor();
        ImGui::Spacing();
    }

    // Açıklama
    if (BeginCard("##drvinfo", 0.f, 76.f)) {
        ImGui::TextColored(C::TEXT_MID4,
            "OMURG creates a real Windows PnP Display Adapter device using SetupAPI.");
        ImGui::TextColored(C::TEXT_MID4,
            "Once installed, the GPU appears in Device Manager under 'Display Adapters'");
        ImGui::TextColored(C::TEXT_MID4,
            "and DirectX/DXGI applications can enumerate and select it.");
    }
    EndCard();

    ImGui::Dummy({0.f, 6.f});
    DrawSectionLabel("Install Virtual GPU");

    // Kurulum kartları
    float tw  = ImGui::GetContentRegionAvail().x;
    float cw  = (tw - 10.f) * 0.5f;
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, {10.f, 10.f});

    VGPUDeviceInfo fx150Info, fx160Info;
    fx150Info.modelName    = L"OMURG FX150";
    fx150Info.hardwareId   = L"ROOT\\OMURG_FX150";
    fx150Info.description  = L"OMURG FX150 Virtual Display Adapter";
    fx150Info.manufacturer = L"OMURG Virtual Hardware";
    fx150Info.driverVersion= L"1.1.0.0";
    fx150Info.vramStr      = "2048 MB";

    fx160Info.modelName    = L"OMURG FX160";
    fx160Info.hardwareId   = L"ROOT\\OMURG_FX160";
    fx160Info.description  = L"OMURG FX160 Virtual Display Adapter";
    fx160Info.manufacturer = L"OMURG Virtual Hardware";
    fx160Info.driverVersion= L"2.0.0.0";
    fx160Info.vramStr      = "3072 MB";

    auto installCard = [&](const char* id, VGPUDeviceInfo& info,
                           bool is160, float cardW) {
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4{28/255.f,28/255.f,28/255.f,1.f});
        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 4.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {16.f, 14.f});
        if (ImGui::BeginChild(id, {cardW, 160.f}, true, ImGuiWindowFlags_NoScrollbar)) {
            ImDrawList* cdl = ImGui::GetWindowDrawList();

            ImGui::TextColored(gen>1?C::ORANGE4:gen==1?C::BLUE4:C::GREEN4,
                               is160 ? "OMURG FX160" : "OMURG FX150");
            ImGui::TextColored(C::TEXT_DIM4,
                               is160 ? "3 GB VRAM  |  12 CU  |  +50% Boost"
                                     : "2 GB VRAM  |  8 CU  |  Standard");
            ImGui::Separator();
            ImGui::Spacing();

            ImGui::TextColored(C::TEXT_DIM4, "Hardware ID:");
            ImGui::SameLine();
            ImGui::TextColored(C::TEXT_MID4, is160 ? "ROOT\\OMURG_FX160" : "ROOT\\OMURG_FX150");
            ImGui::Spacing();

            // INF dizini — temp
            wchar_t tempPath[MAX_PATH] = {};
            GetTempPathW(MAX_PATH, tempPath);
            std::wstring infDir = tempPath;

            if (elevated) {
                char btnId[64]; std::snprintf(btnId,64,"Install##%s",id);
                if (ActionButton(btnId, (cardW-32.f)*0.5f, 28.f)) {
                    m->drvInstalling = true;
                    auto res = m->drvMgr.installDevice(info, infDir);
                    m->drvStatus   = res.message;
                    m->drvStatusOk = res.success;
                    m->drvInstalling = false;
                    m->devsRefreshed = false; // yenile
                }
                ImGui::SameLine(0.f, 8.f);
                char rmId[64]; std::snprintf(rmId,64,"Remove##%s",id);
                if (ActionButton(rmId, (cardW-32.f)*0.5f, 28.f, true)) {
                    auto res = m->drvMgr.removeDevice(info);
                    m->drvStatus   = res.message;
                    m->drvStatusOk = res.success;
                    m->devsRefreshed = false;
                }
            } else {
                ImGui::TextColored(C::TEXT_DIM4, "(Requires Administrator)");
            }
        }
        ImGui::EndChild();
        ImGui::PopStyleVar(2); ImGui::PopStyleColor();
    };

    installCard("##fx150c", fx150Info, false, cw);
    ImGui::SameLine(0.f, 10.f);
    installCard("##fx160c", fx160Info, true,  cw);
    ImGui::PopStyleVar();

    // Durum mesajı
    if (!m->drvStatus.empty()) {
        ImGui::Spacing();
        // wstring → string
        std::string msg(m->drvStatus.begin(), m->drvStatus.end());
        ImGui::TextColored(m->drvStatusOk ? C::GREEN4 : C::RED4, "%s", msg.c_str());
    }

    ImGui::Dummy({0.f, 6.f});
    DrawSectionLabel("Installed OMURG Devices");

    // Yenile
    if (!m->devsRefreshed || ActionButton("Refresh", 120.f, 26.f)) {
        m->installedDevs = m->drvMgr.enumInstalledDevices();
        m->devsRefreshed = true;
    }
    ImGui::Spacing();

    if (m->installedDevs.empty()) {
        if (BeginCard("##nodv", 0.f, 52.f)) {
            ImGui::Spacing();
            ImGui::TextColored(C::TEXT_DIM4, "  No OMURG devices found in Device Manager.");
        }
        EndCard();
    }

    for (auto& dev : m->installedDevs) {
        std::string fn(dev.friendlyName.begin(), dev.friendlyName.end());
        std::string ds(dev.description.begin(), dev.description.end());

        ImGui::PushStyleColor(ImGuiCol_ChildBg,
            dev.enabled ? ImVec4{22/255.f,35/255.f,10/255.f,1.f}
                        : ImVec4{28/255.f,28/255.f,28/255.f,1.f});
        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 4.f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {14.f, 10.f});

        if (ImGui::BeginChild(std::format("##dv{}", fn).c_str(),
                              {ImGui::GetContentRegionAvail().x, 64.f},
                              true, ImGuiWindowFlags_NoScrollbar)) {
            ImDrawList* dvl = ImGui::GetWindowDrawList();
            ImVec2 wp = ImGui::GetWindowPos();
            // Durum noktası
            dvl->AddCircleFilled({wp.x + 12.f, wp.y + 24.f}, 5.f,
                                  dev.enabled ? C::GREEN : C::RED);
            ImGui::SetCursorPosX(26.f);
            ImGui::TextColored(C::TEXT_WHITE4, "%s", fn.c_str());
            ImGui::SetCursorPosX(26.f);
            ImGui::TextColored(C::TEXT_DIM4, "%s  |  %s",
                ds.c_str(), dev.enabled ? "ACTIVE" : "DISABLED");

            // Sağda butonlar
            float bx = ImGui::GetWindowWidth() - 200.f;
            ImGui::SetCursorPos({bx, 18.f});
            if (dev.enabled) {
                if (ActionButton(std::format("Disable##{}", fn).c_str(),
                                 90.f, 24.f, true))
                    m->drvMgr.disableDevice(dev);
            } else {
                if (ActionButton(std::format("Enable##{}", fn).c_str(),
                                 90.f, 24.f))
                    m->drvMgr.enableDevice(dev);
            }
            ImGui::SameLine(0.f, 6.f);
            if (ActionButton(std::format("Remove##{}", fn).c_str(),
                             80.f, 24.f, true)) {
                m->drvMgr.removeDevice(dev);
                m->devsRefreshed = false;
            }
        }
        ImGui::EndChild();
        ImGui::PopStyleVar(2); ImGui::PopStyleColor();
        ImGui::Spacing();
    }
}

// =============================================================================
// Updater sekmesi
// =============================================================================
void OMURGGui::renderUpdate() {
    DrawSectionLabel("Software Updates", 2.f);
    if (BeginCard("##updc", 0.f, 0.f, true)) {
        ImGui::Spacing();
        ImGui::TextColored(C::TEXT_DIM4, "Manifest URL:");
        ImGui::SameLine();
        ImGui::TextColored(C::GREEN4, "%s", Updater::DEFAULT_MANIFEST_URL);
        ImGui::Spacing();
        if (!m->updateRunning) {
            if (ActionButton("Check for Updates", 200.f))
                m->updater->startAsyncUpdate(
                    [this](const DownloadProgress& p) {
                        char buf[256];
                        if (p.totalBytes > 0)
                            std::snprintf(buf,sizeof(buf),"Downloading %s: %.1f%%",
                                p.filename.c_str(),100.0*p.bytesReceived/p.totalBytes);
                        else
                            std::snprintf(buf,sizeof(buf),"Downloading %s: %llu bytes",
                                p.filename.c_str(), p.bytesReceived);
                        m->updateStatus = buf; m->updateRunning = true;
                    },
                    [this](bool ok, const std::string& msg) {
                        m->updateRunning = false;
                        m->updateStatus  = (ok ? "[OK] " : "[FAIL] ") + msg;
                    });
        } else {
            if (ActionButton("Cancel", 120.f, 32.f, true)) m->updater->cancelAsync();
            ImGui::SameLine(0.f, 12.f);
            static int fr = 0;
            const char* sp[] = {"|","/","-","\\"};
            ImGui::TextColored(C::GREEN4, "%s Working...", sp[(fr++/8)%4]);
        }
        ImGui::Spacing();
        DrawSectionLabel("Status");
        if (!m->updateStatus.empty()) {
            bool ok   = m->updateStatus.substr(0,4) == "[OK]";
            bool fail = m->updateStatus.size()>=6 && m->updateStatus.substr(0,6)=="[FAIL]";
            ImGui::TextColored(fail?C::RED4:(ok?C::GREEN4:C::TEXT_MID4),
                "%s", m->updateStatus.c_str());
        } else {
            ImGui::TextColored(C::TEXT_DIM4, "No update check performed yet.");
        }
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Support sekmesi
// =============================================================================
void OMURGGui::renderSupport() {
    DrawSectionLabel("Contact Support", 2.f);
    if (BeginCard("##supc", 0.f, 0.f, true)) {
        ImGui::Spacing();
        ImGui::TextColored(C::TEXT_DIM4,
            "Fill in the form. Send opens your email client with the message pre-filled.");
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4{20/255.f,20/255.f,20/255.f,1.f});

        auto field = [&](const char* lbl, const char* id, char* buf, size_t bufsz) {
            ImGui::TextColored(C::TEXT_DIM4, "%s", lbl);
            ImGui::SetNextItemWidth(-1.f);
            ImGui::InputText(id, buf, bufsz);
            ImGui::Spacing();
        };
        field(m->langIdx==0?"Your Name":"Adiniz",    "##sn", m->sName,  sizeof(m->sName));
        field(m->langIdx==0?"Email":"E-posta",       "##se", m->sEmail, sizeof(m->sEmail));
        field(m->langIdx==0?"Subject":"Konu",        "##ss", m->sSubj,  sizeof(m->sSubj));
        ImGui::TextColored(C::TEXT_DIM4, m->langIdx==0?"Message":"Mesaj");
        ImGui::InputTextMultiline("##sm", m->sMsg, sizeof(m->sMsg), {-1.f, 110.f});
        ImGui::PopStyleColor();

        ImGui::Spacing();
        if (ActionButton(m->langIdx==0?"Send Message":"Gondir", 180.f)) {
            std::string subj = std::string("[OMURG] ") + m->sSubj;
            std::string body = std::string("Name: ")  + m->sName + "\r\n"
                             + "Email: " + m->sEmail + "\r\n\r\n" + m->sMsg;
            auto enc = [](const std::string& s) {
                std::string r;
                for (unsigned char c : s) {
                    if (c==' ') r+="%20"; else if (c=='\r') r+="%0D";
                    else if (c=='\n') r+="%0A"; else if (c=='&') r+="%26";
                    else if (c=='?') r+="%3F"; else if (c=='#') r+="%23";
                    else r+=(char)c;
                }
                return r;
            };
            std::string ml = std::string("mailto:") + SupportClient::SUPPORT_EMAIL
                           + "?subject=" + enc(subj) + "&body=" + enc(body);
            ShellExecuteA(nullptr,"open",ml.c_str(),nullptr,nullptr,SW_SHOW);
            m->sResultOk = true; m->sResult = "Email client opened.";
        }
        if (!m->sResult.empty()) {
            ImGui::SameLine(0.f, 10.f);
            ImGui::TextColored(m->sResultOk ? C::GREEN4 : C::RED4,
                "%s", m->sResult.c_str());
        }
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// Settings sekmesi
// =============================================================================
void OMURGGui::renderSettings() {
    DrawSectionLabel("Interface", 2.f);
    if (BeginCard("##setc", 0.f, 0.f, true)) {
        ImGui::Spacing();
        ImGui::TextColored(C::TEXT_DIM4, "Language");
        ImGui::SameLine(160.f);
        const char* langs[] = {"English","Turkce","Deutsch","Francais","Espanol","Japanese","Chinese","Arabic"};
        ImGui::SetNextItemWidth(180.f);
        ImGui::Combo("##lang", &m->langIdx, langs, 8);

        ImGui::Spacing();
        DrawSectionLabel("About");
        float lw = 230.f;
        StatLine("Application",   "OMURG Virtual GPU Control Panel v3.0", C::TEXT_MID4, lw);
        StatLine("Version",       "3.0.0",                                  C::TEXT_MID4, lw);
        StatLine("Architecture",  "x64  (AVX2 / SSE4.2)",                  C::TEXT_MID4, lw);
        StatLine("GPU Backends",  "FX150 v1.1  +  FX160 v1.2",            C::TEXT_MID4, lw);
        StatLine("Driver API",    "Windows SetupAPI  +  PnP Root Enum",    C::TEXT_MID4, lw);
        StatLine("Build",         __DATE__,                                  C::TEXT_MID4, lw);

        ImGui::Spacing();
        DrawSectionLabel("FX160 vs FX150");
        StatLine("VRAM",          "3 GB  vs  up to 2 GB",   C::BLUE4, lw);
        StatLine("Clock",         "1800 MHz  vs  1200 MHz", C::BLUE4, lw);
        StatLine("Compute Units", "12  vs  8",               C::BLUE4, lw);
        StatLine("CPU Boost",     "+50% (x1.5)  vs  1x",   C::BLUE4, lw);
        StatLine("Async Queues",  "4  vs  0",                C::BLUE4, lw);
        StatLine("Tile Size",     "32 px  vs  64 px",        C::BLUE4, lw);
        StatLine("MSAA / GS / Tess", "Yes  vs  No",          C::BLUE4, lw);

        ImGui::Spacing();
        DrawSectionLabel("Links");
        if (ActionButton("GitHub Repository", 200.f, 28.f))
            ShellExecuteA(nullptr,"open",
                "https://github.com/gamegameromur-a11y/OMURG",
                nullptr,nullptr,SW_SHOW);
        ImGui::Spacing();
    }
    EndCard();
}

// =============================================================================
// WinMain
// =============================================================================
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static OMURGGui* g_gui = nullptr;

static LRESULT CALLBACK WndProc(HWND hWnd, UINT msg,
                                  WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) return true;
    switch (msg) {
    case WM_SIZE:
        if (g_gui && wParam != SIZE_MINIMIZED)
            g_gui->resize(LOWORD(lParam), HIWORD(lParam));
        return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    WNDCLASSEXW wc = { sizeof(wc) };
    wc.style         = CS_CLASSDC;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = L"OMURGWnd";
    wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_OMURG));
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowW(L"OMURGWnd",
        L"OMURG Virtual GPU Control Panel v3.0",
        WS_OVERLAPPEDWINDOW, 100, 100, 1440, 900,
        nullptr, nullptr, hInstance, nullptr);

    OMURGGui gui;
    g_gui = &gui;

    if (!gui.init(hwnd)) {
        MessageBoxA(nullptr, "Failed to initialize OMURG.", "Error",
                    MB_OK | MB_ICONERROR);
        return 1;
    }
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg = {};
    while (msg.message != WM_QUIT) {
        if (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg); DispatchMessageW(&msg);
        } else {
            gui.render();
        }
    }
    gui.shutdown();
    g_gui = nullptr;
    DestroyWindow(hwnd);
    UnregisterClassW(L"OMURGWnd", hInstance);
    return 0;
}
