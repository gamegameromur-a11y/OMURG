# OMURG v3.0 — Virtual GPU (Oyun Uyumlu)

Windows x64 sanal GPU. ImGui + DirectX 11 arayüzü.  
**Artık oyunlar çalışıyor!** → DXVK + SwiftShader + VKD3D-Proton entegrasyonu.

---

## GPU Modelleri

| Model  | VRAM        | Çekirdek | CPU Yükü | Performans         |
|--------|-------------|----------|----------|--------------------|
| FX150  | 512 MB–2 GB | 8 sanal  | ~%20     | Giriş seviyesi     |
| FX160  | 3 GB        | 12 sanal | ~%15     | Gen2 Orta          |
| FX1X0  | 1–4 GB      | Değişken | ~%12     | Gen3 Giriş         |
| FX202  | 8 GB        | 4000     | %5       | Ultra / FX-SS 8K   |
| **FX210** | **1–10 GB** | **5900 (Tam Paralel)** | **%3** | **RTX 3060 Gücü** |

### FX210 — Amiral Gemisi

- **5900 sanal çekirdek** — tamamı aynı anda paralel çalışır
- **%3 CPU yükü** — CPU'ya neredeyse hiç yük binmez
- **Gerçek RTX 3060 gücü** — her AAA oyunda stabil
- **1 GB – 10 GB dinamik VRAM** — sisteme göre otomatik ayarlanır (vGPU Adapt)
- **OpenGL 4.6 tam desteği** — ARB_direct_state_access, ARB_gl_spirv + tüm ext.
- **FX-AI Upscale** — Lanczos-2 + TAA tabanlı 4K → 8K görüntü yükseltme
- **10 async compute kuyruğu** — eş zamanlı iş yönetimi
- **8px tile** — ultra ince granularite ile en yüksek paralel verim

---

## Nasıl Çalışır?

```
Oyun (D3D11)  →  DXVK  →  Vulkan  →  SwiftShader  →  CPU Rasterizer
Oyun (D3D12)  →  VKD3D-Proton  →  Vulkan  →  SwiftShader  →  CPU
Oyun (Vulkan) →  SwiftShader  →  CPU Rasterizer
Oyun (OpenGL) →  Mesa llvmpipe / FX210 OpenGL 4.6 Kat  →  CPU
```

- **SwiftShader**: Google Chrome'un da kullandığı CPU tabanlı Vulkan 1.3 ICD.
- **DXVK**: Steam Deck/Proton'un kullandığı D3D→Vulkan çevirici.
- **VKD3D-Proton**: D3D12 oyunları için (opsiyonel).

---

## Hızlı Başlangıç

### 1. Bağımlılıkları İndir (PowerShell — Yönetici)
```powershell
Set-ExecutionPolicy Bypass -Scope Process
.\scripts\Get-Dependencies.ps1
```
Script otomatik olarak SwiftShader, DXVK ve VKD3D'yi `deps\` klasörüne indirir.

### 2. OMURG'u Yönetici Olarak Çalıştır
### 3. GPU Seç → **FX210 [10 GB | Tam Güç vGPU]** → Initialize GPU
### 4. "Oyun Uyumluluğu" sekmesi → SwiftShader ICD Kaydet → Oyun Seç → Başlat

---

## Oyun Uyumluluğu

| API        | Destek | Nasıl?                            |
|------------|--------|-----------------------------------|
| DirectX 9  | ✅     | DXVK → Vulkan → SwiftShader      |
| DirectX 10 | ✅     | DXVK → Vulkan → SwiftShader      |
| DirectX 11 | ✅     | DXVK → Vulkan → SwiftShader      |
| DirectX 12 | ✅     | VKD3D-Proton → Vulkan → SS        |
| Vulkan     | ✅     | Doğrudan SwiftShader ICD          |
| OpenGL 4.6 | ✅     | FX210 OpenGL kat + ARB ext.       |

---

## Build

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

Gereksinimler: Visual Studio 2022, CMake 3.20+, Windows 10/11 x64

---

## Teknik Notlar

- **DXVK Enjeksiyonu**: Oyun klasörüne DLL kopyalanır, oyun bitince geri alınır
- **SwiftShader ICD**: `HKLM\SOFTWARE\Khronos\Vulkan\Drivers` registry kaydı
- **D3D Registry**: Aygıt Yöneticisi'nde DirectX 12.1 olarak görünür
- **Yönetici yetkisi**: Sürücü kurulumu ve ICD kaydı için gerekli
- **FX210 vGPU Adapt**: Sistem RAM'e göre VRAM otomatik belirlenir (1–10 GB)
- **OpenGL Compat**: FX210 ARB extension'ları ile OpenGL 4.6 uyumluluğu sağlar

## Lisans
MIT (OMURG) · Apache 2.0 (SwiftShader) · zlib (DXVK) · LGPL 2.1 (VKD3D-Proton)


---

## Hızlı Başlangıç

### 1. Bağımlılıkları İndir (PowerShell — Yönetici)
```powershell
Set-ExecutionPolicy Bypass -Scope Process
.\scripts\Get-Dependencies.ps1
```
Script otomatik olarak SwiftShader, DXVK ve VKD3D'yi `deps\` klasörüne indirir.

### 2. OMURG'u Yönetici Olarak Çalıştır
### 3. "Oyun Uyumluluğu" sekmesi → SwiftShader ICD Kaydet → Oyun Seç → Başlat

---

## Oyun Uyumluluğu

| API | Destek | Nasıl? |
|-----|--------|--------|
| DirectX 9  | ✅ | DXVK → Vulkan → SwiftShader |
| DirectX 10 | ✅ | DXVK → Vulkan → SwiftShader |
| DirectX 11 | ✅ | DXVK → Vulkan → SwiftShader |
| DirectX 12 | ✅ | VKD3D-Proton → Vulkan → SwiftShader |
| Vulkan     | ✅ | Doğrudan SwiftShader ICD |

---

## Build

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

Gereksinimler: Visual Studio 2022, CMake 3.20+, Windows 10/11 x64

---

## Teknik Notlar

- **DXVK Enjeksiyonu**: Oyun klasörüne DLL kopyalanır, oyun bitince geri alınır
- **SwiftShader ICD**: `HKLM\SOFTWARE\Khronos\Vulkan\Drivers` registry kaydı
- **D3D Registry**: Aygıt Yöneticisi'nde DirectX 12.1 olarak görünür
- **Yönetici yetkisi**: Sürücü kurulumu ve ICD kaydı için gerekli

## Lisans
MIT (OMURG) · Apache 2.0 (SwiftShader) · zlib (DXVK) · LGPL 2.1 (VKD3D-Proton)
