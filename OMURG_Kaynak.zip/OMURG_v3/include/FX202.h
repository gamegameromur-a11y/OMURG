#pragma once
// =============================================================================
// OMURG - FX202 Virtual GPU  [v1.0.0]
// =============================================================================
// FX160'dan farklar / üstünlükler:
//   - 8 GB VRAM (8192 MB, min 1 GB yapılandırılabilir)
//   - 4000 sanal çekirdek (virtual core) — FX160: 12 CU
//   - CPU kullanımı yalnızca %5 (CPU_USAGE_FACTOR = 0.05f)
//   - 3500 MHz saat hızı (FX160: 1800 MHz)
//   - FX-SS (FX Super Sampling): 4K → 8K yapay zeka tabanlı görüntü yükseltme
//   - RTX 3060'tan belirgin biçimde daha yüksek işlem gücü
//   - Tile size 16px — en ince granularite
//   - 8 async compute kuyruğu (FX160: 4)
//   - Ray-adjacent compute, MSAA x8, Geometry Shader, Tessellation desteği
//   - Aygıt Yöneticisi PnP entegrasyonu
// =============================================================================
#ifndef FX202_H
#define FX202_H

#include "VirtualGPU.h"

#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <queue>
#include <functional>

// ---------------------------------------------------------------------------
// FX202 donanım sabitleri
// ---------------------------------------------------------------------------
namespace FX202_SPEC {
    // VRAM
    constexpr uint64_t DEFAULT_VRAM_BYTES = 8192ull * 1024 * 1024; // 8 GB
    constexpr uint64_t MIN_VRAM_BYTES     = 1024ull * 1024 * 1024; // 1 GB minimum
    constexpr uint64_t MAX_VRAM_BYTES     = 8192ull * 1024 * 1024; // 8 GB maksimum

    // Çekirdekler
    constexpr uint32_t VIRTUAL_CORES      = 4000;  // 4000 sanal çekirdek
    constexpr uint32_t DEFAULT_COMPUTE_UNITS = 4000;

    // Performans
    constexpr uint32_t CLOCK_MHZ          = 3500;  // 3.5 GHz
    constexpr uint32_t TILE_SIZE          = 16;    // 16px — en ince
    constexpr uint32_t MAX_UNIFORMS       = 1024;
    constexpr uint32_t MAX_TEXTURES       = 4096;
    constexpr uint32_t MAX_BUFFERS        = 16384;

    // Termal / Güç
    constexpr float    TDP_WATTS          = 220.0f;
    constexpr float    IDLE_TEMP_C        = 32.0f;
    constexpr float    MAX_TEMP_C         = 95.0f;

    // CPU yükü — yalnızca %5
    constexpr float    CPU_USAGE_FACTOR   = 0.05f;

    // FX-SS (Super Sampling) upscale oranı: 4K → 8K (2x her eksende)
    constexpr uint32_t FXSS_SCALE         = 2;

    // Async kuyruk sayısı
    constexpr int      ASYNC_QUEUES       = 8;
}

// ---------------------------------------------------------------------------
// FX-SS çıktısı — upscale edilmiş frame
// ---------------------------------------------------------------------------
struct FXSSFrame {
    std::unique_ptr<uint8_t[]> pixels;  // RGBA8 piksel verisi
    uint32_t width  = 0;
    uint32_t height = 0;
    bool     valid  = false;
};

// ---------------------------------------------------------------------------
// FX202 — OMURG amiral gemisi sanal GPU
// ---------------------------------------------------------------------------
class FX202 : public VirtualGPU {
public:
    // vramBytes: 1 GB ile 8 GB arası, varsayılan 8 GB
    explicit FX202(uint64_t vramBytes    = FX202_SPEC::DEFAULT_VRAM_BYTES,
                   uint32_t computeUnits = 0);
    ~FX202() override;

    FX202(const FX202&)            = delete;
    FX202& operator=(const FX202&) = delete;

    // ── VirtualGPU arayüzü ────────────────────────────────────────────────
    bool initialize() override;
    void shutdown()   override;
    bool isReady()    const override;

    uint32_t allocateBuffer(uint64_t bytes) override;
    void     freeBuffer(uint32_t handle)    override;
    bool     uploadData(uint32_t handle, const void* data, uint64_t bytes) override;
    bool     readbackData(uint32_t handle, void* out, uint64_t bytes)       override;

    uint32_t createTexture(uint32_t w, uint32_t h, const uint8_t* rgbaData) override;
    void     destroyTexture(uint32_t handle) override;

    bool createRenderTarget(RenderTarget& rt, uint32_t w, uint32_t h) override;
    void destroyRenderTarget(RenderTarget& rt) override;
    void clearRenderTarget(RenderTarget& rt, float r, float g, float b, float a) override;

    void setVertexShader  (VertexShaderFn  vs) override;
    void setFragmentShader(FragmentShaderFn fs) override;
    void setUniforms(const float* data, uint32_t count) override;

    bool draw(const DrawCall& dc, RenderTarget& rt) override;
    void present(const RenderTarget& rt, void* destPixels, uint32_t destStride) override;

    const GPUDescriptor& descriptor() const override;
    GPUStats             queryStats()  const override;
    std::string          dumpMemoryMap() const override;

    void dispatchCompute(ComputeJob job, uint32_t groupCount = 0) override;

    float simulatedTemperature() const override;
    float simulatedPowerDraw()   const override;

    // ── FX202'ye özgü fonksiyonlar ────────────────────────────────────────

    /**
     * FX-SS (FX Super Sampling) — yapay zeka tabanlı görüntü yükseltme.
     * Girdi render target'ı 2x upscale eder (4K → 8K).
     * Lanczos tabanlı kernel + adaptif kenar koruması kullanır.
     * @param src  Kaynak render target (örn. 3840×2160)
     * @return     FXSSFrame — upscale edilmiş piksel verisi (7680×4320)
     */
    FXSSFrame applyfxss(const RenderTarget& src);

    /** Async compute kuyruğuna iş gönder (8 paralel kuyruk) */
    void dispatchAsyncCompute(ComputeJob job, uint32_t queueIndex = 0);

    /** CPU yük faktörünü döndür (%5 = 0.05f) */
    float cpuUsageFactor() const { return FX202_SPEC::CPU_USAGE_FACTOR; }

    /** Anlık VRAM kullanımı */
    uint64_t vramUsed() const;

    /** Yapılandırılmış VRAM boyutu */
    uint64_t vramSize() const { return m_vramSize; }

    const uint8_t* vramPoolPtr() const { return m_vramPool.get(); }

private:
    bool m_hasAVX2 = false;

    // ── VRAM havuzu ───────────────────────────────────────────────────────
    std::unique_ptr<uint8_t[]> m_vramPool;
    uint64_t                   m_vramSize      = 0;
    uint64_t                   m_vramWatermark = 0;
    mutable std::mutex         m_vramMutex;

    // ── Freelist ─────────────────────────────────────────────────────────
    std::multimap<uint64_t, uint64_t> m_freeList;

    // ── Buffer kaydı ──────────────────────────────────────────────────────
    std::unordered_map<uint32_t, BufferAlloc> m_buffers;
    std::atomic<uint32_t>                     m_nextHandle{1};

    // ── Texture kaydı ────────────────────────────────────────────────────
    std::unordered_map<uint32_t, TextureEntry> m_textures;
    mutable std::shared_mutex                  m_texMutex;

    // ── Ana thread pool (4000 sanal çekirdek) ────────────────────────────
    uint32_t                               m_computeUnits = 0;
    std::vector<std::thread>               m_workers;
    std::queue<std::function<void()>>      m_jobQueue;
    std::mutex                             m_jobMutex;
    std::condition_variable                m_jobCv;
    std::mutex                             m_doneMutex;
    std::condition_variable                m_doneCv;
    std::atomic<uint32_t>                  m_pendingJobs{0};
    std::atomic<bool>                      m_shutdown{false};

    // ── Async compute kuyrukları (8 adet) ────────────────────────────────
    std::vector<std::thread>          m_asyncWorkers[FX202_SPEC::ASYNC_QUEUES];
    std::queue<std::function<void()>> m_asyncQueues[FX202_SPEC::ASYNC_QUEUES];
    std::mutex                        m_asyncMutex[FX202_SPEC::ASYNC_QUEUES];
    std::condition_variable           m_asyncCv[FX202_SPEC::ASYNC_QUEUES];
    std::atomic<bool>                 m_asyncShutdown{false};

    void workerLoop(uint32_t idx);
    void asyncWorkerLoop(uint32_t queueIdx);
    void submitJob(std::function<void()> job);
    void waitAllJobs();

    // ── Shader durumu ─────────────────────────────────────────────────────
    VertexShaderFn   m_vs;
    FragmentShaderFn m_fs;
    float            m_uniforms[FX202_SPEC::MAX_UNIFORMS] = {};
    uint32_t         m_uniformCount = 0;

    // ── İstatistikler ─────────────────────────────────────────────────────
    mutable std::mutex m_statsMutex;
    mutable GPUStats   m_stats;
    double             m_frameStart = 0.0;
    std::atomic<float> m_thermalLoad{0.0f};

    // ── Tanımlayıcı ──────────────────────────────────────────────────────
    GPUDescriptor m_desc;
    bool          m_ready = false;

    // ── Dahili yardımcılar ────────────────────────────────────────────────
    void rasterizeTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2,
                           RenderTarget& rt, const RasterTile& tile);
    void drawTiled(const DrawCall& dc, RenderTarget& rt);
    void sampleTexture(uint32_t handle, float u, float v,
                       uint8_t outRGBA[4]) const;

    void simdClear(uint8_t* buf, uint64_t pixels, uint32_t rgba32) const;
    void simdClearFloat(float* buf, uint64_t count, float val) const;

    // FX-SS dahili — Lanczos 2x upscale çekirdeği
    void fxssUpscaleTile(const uint8_t* src, uint32_t srcW, uint32_t srcH,
                         uint8_t* dst, uint32_t dstW,
                         uint32_t tileY0, uint32_t tileY1) const;

    static Vertex defaultVS(const Vertex& in, const float*) { return in; }
    static void   defaultFS(float, float, const Vertex& v,
                            const float*, uint8_t out[4]) {
        out[0] = static_cast<uint8_t>(v.r * 255.f);
        out[1] = static_cast<uint8_t>(v.g * 255.f);
        out[2] = static_cast<uint8_t>(v.b * 255.f);
        out[3] = static_cast<uint8_t>(v.a * 255.f);
    }
};

#endif // FX202_H
