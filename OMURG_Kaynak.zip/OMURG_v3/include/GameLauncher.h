#pragma once
// =============================================================================
// OMURG - GameLauncher.h
// Oyunları OMURG grafik katmanıyla başlatan modül.
// DXVK + SwiftShader otomatik enjeksiyonu + süreç izleme.
// =============================================================================
#ifndef GAME_LAUNCHER_H
#define GAME_LAUNCHER_H

#include "GraphicsAPI.h"
#include <windows.h>
#include <string>
#include <vector>
#include <functional>
#include <thread>
#include <atomic>
#include <mutex>

// ---------------------------------------------------------------------------
// Oyun durumu
// ---------------------------------------------------------------------------
enum class GameState {
    Idle,
    Injecting,
    Running,
    Exited,
    Error
};

// ---------------------------------------------------------------------------
// Başlatma oturumu
// ---------------------------------------------------------------------------
struct LaunchSession {
    GameProfile  profile;
    HANDLE       hProcess    = nullptr;
    GameState    state       = GameState::Idle;
    std::wstring statusMsg;
    DWORD        exitCode    = 0;
    double       runTimeSec  = 0.0;
    ULONGLONG    startTickMs = 0;
};

// ---------------------------------------------------------------------------
// GameLauncher
// ---------------------------------------------------------------------------
class GameLauncher {
public:
    explicit GameLauncher(GraphicsAPIManager& api);
    ~GameLauncher();

    // ── Oyun başlat ────────────────────────────────────────────────────────
    /** Oyunu arka planda başlat. Durum callback ile izlenir. */
    bool launch(const GameProfile& profile);

    /** Çalışan oyunu zorla kapat. */
    void forceStop();

    // ── Durum sorgulama ───────────────────────────────────────────────────
    GameState         state()      const;
    const LaunchSession& session() const { return m_session; }
    std::wstring      statusMsg()  const;
    bool              isRunning()  const { return m_state == GameState::Running; }

    // ── Durum güncelleme (ImGui frame'inde çağrılır) ──────────────────────
    void update();

    // ── Oyun profili yönetimi ─────────────────────────────────────────────
    void addProfile(const GameProfile& p);
    void removeProfile(size_t idx);
    const std::vector<GameProfile>& profiles() const { return m_profiles; }
    std::vector<GameProfile>&       profiles()       { return m_profiles; }
    void saveProfiles();
    void loadProfiles();

    // ── Oyun bul (dosya dialogu) ──────────────────────────────────────────
    static std::wstring browseForExe(HWND hwndOwner = nullptr);

    // ── Sistem kontrolleri ────────────────────────────────────────────────
    /** DirectX Debug Layer uyarısını kontrol et. */
    static bool checkD3DDebugLayer();
    /** GPU-Z / GPU bilgi sayfası için WDDM sürücü varlığını kontrol et. */
    static bool checkWDDMPresent();

private:
    GraphicsAPIManager&  m_api;
    std::vector<GameProfile> m_profiles;
    LaunchSession        m_session;
    std::atomic<GameState> m_state { GameState::Idle };
    mutable std::mutex   m_mtx;

    std::thread          m_watchThread;
    std::atomic<bool>    m_stopWatch { false };

    void watcherThread(HANDLE hProcess, GameProfile profile);
};

#endif // GAME_LAUNCHER_H
