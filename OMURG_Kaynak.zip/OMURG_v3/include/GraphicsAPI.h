#pragma once
// =============================================================================
// OMURG - GraphicsAPI.h
// Windows üzerinde gerçek grafik API desteği:
//   • SwiftShader  → Vulkan 1.3 ICD (CPU üzerinde tam Vulkan)
//   • DXVK         → D3D9/10/11 → Vulkan (oyunların %90'ı)
//   • VKD3D-Proton → D3D12 → Vulkan
//   • Mesa llvmpipe → OpenGL ICD
// =============================================================================
#ifndef GRAPHICS_API_H
#define GRAPHICS_API_H

#include <windows.h>
#include <string>
#include <vector>
#include <functional>
#include <atomic>

// ---------------------------------------------------------------------------
// İndir/kur ilerleme geri çağrısı
// ---------------------------------------------------------------------------
using ProgressCallback = std::function<void(const std::wstring& msg, float pct)>;

// ---------------------------------------------------------------------------
// Vulkan ICD kaydı
// ---------------------------------------------------------------------------
struct VulkanICDEntry {
    std::wstring jsonPath;   // Tam ICD JSON yolu
    std::wstring dllPath;    // Yanındaki .dll
    std::wstring apiVersion; // Örn. "1.3.0"
    bool         active = false;
};

// ---------------------------------------------------------------------------
// DXVK kurulum bilgisi
// ---------------------------------------------------------------------------
struct DXVKInstall {
    std::wstring d3d9_dll;
    std::wstring d3d10core_dll;
    std::wstring d3d11_dll;
    std::wstring dxgi_dll;
    bool         available = false;
};

// ---------------------------------------------------------------------------
// VKD3D-Proton kurulum bilgisi
// ---------------------------------------------------------------------------
struct VKD3DInstall {
    std::wstring d3d12_dll;
    std::wstring d3d12_sdklayers_dll;
    bool         available = false;
};

// ---------------------------------------------------------------------------
// Oyun profili
// ---------------------------------------------------------------------------
struct GameProfile {
    std::wstring name;
    std::wstring exePath;
    std::wstring workDir;
    bool         useDXVK    = true;   // D3D9/10/11 → Vulkan
    bool         useVKD3D   = false;  // D3D12 → Vulkan
    bool         forceDX11  = false;  // -dx11 argümanı ekle
    bool         installed  = false;  // DLL'ler enjekte edildi mi
};

// ---------------------------------------------------------------------------
// GraphicsAPIManager
// ---------------------------------------------------------------------------
class GraphicsAPIManager {
public:
    GraphicsAPIManager();
    ~GraphicsAPIManager();

    // ── Başlatma ──────────────────────────────────────────────────────────
    /** Deps klasörünü ayarla ve mevcut durumu tara. */
    bool initialize(const std::wstring& baseDir);

    // ── SwiftShader ───────────────────────────────────────────────────────
    /** SwiftShader Vulkan ICD'yi sisteme kaydet. */
    bool  registerSwiftShader();
    /** Kaydı kaldır. */
    bool  unregisterSwiftShader();
    /** Kayıtlı mı? */
    bool  isSwiftShaderRegistered() const;
    /** SwiftShader DLL mevcut mu? */
    bool  isSwiftShaderAvailable() const;

    // ── Vulkan ICD sorguları ─────────────────────────────────────────────
    /** Sistemdeki tüm Vulkan ICD'leri listele. */
    std::vector<VulkanICDEntry> enumerateVulkanICDs() const;
    /** Sisteme herhangi bir Vulkan var mı? */
    bool  isAnyVulkanPresent() const;

    // ── DXVK ─────────────────────────────────────────────────────────────
    bool  isDXVKAvailable()  const;
    const DXVKInstall& getDXVK() const { return m_dxvk; }

    /** Belirtilen oyun dizinine DXVK DLL'lerini kopyala. */
    bool  injectDXVK(const std::wstring& gameDir);
    /** DXVK DLL'lerini oyun dizininden kaldır. */
    bool  removeDXVK(const std::wstring& gameDir);
    /** Oyun dizininde DXVK var mı? */
    bool  isDXVKInjected(const std::wstring& gameDir) const;

    // ── VKD3D-Proton ──────────────────────────────────────────────────────
    bool  isVKD3DAvailable()  const;
    const VKD3DInstall& getVKD3D() const { return m_vkd3d; }

    bool  injectVKD3D(const std::wstring& gameDir);
    bool  removeVKD3D(const std::wstring& gameDir);
    bool  isVKD3DInjected(const std::wstring& gameDir) const;

    // ── D3D Yazmaç Girişleri (Aygıt Yöneticisi görünürlüğü) ──────────────
    /**
     * Belirtilen GPU cihaz örneğine D3D özellik düzeyi kayıt girdileri yazar.
     * deviceInstanceId: ör. "ROOT\\OMURG_FX160\\0000"
     */
    static bool writeD3DRegistryEntries(const std::wstring& deviceInstanceId,
                                         const std::wstring& modelName,
                                         uint32_t            vramMB,
                                         const std::string&  featureLevel = "12_1");
    static bool removeD3DRegistryEntries(const std::wstring& deviceInstanceId);

    // ── DXGI Yazılım Bağdaştırıcısı ──────────────────────────────────────
    /**
     * Sisteme OMURG'u bir DXGI yazılım bağdaştırıcısı olarak kaydeder.
     * Bu sayede IDXGIFactory::EnumAdapters() OMURG'u listeler.
     */
    bool  registerDXGISoftwareAdapter(const std::wstring& adapterDllPath);
    bool  unregisterDXGISoftwareAdapter();

    // ── Oyun Başlatma ─────────────────────────────────────────────────────
    /** Oyunu OMURG grafik katmanıyla başlat. */
    HANDLE launchGame(const GameProfile& profile,
                      std::wstring&      outError);
    /** Başlatılan oyun işlemini temizle (DLL'leri geri al). */
    void   cleanupAfterGame(const GameProfile& profile, HANDLE hProcess);

    // ── İndirme ───────────────────────────────────────────────────────────
    /**
     * SwiftShader'ı GitHub Releases'den indir.
     * progress: (mesaj, 0.0–1.0)
     */
    bool downloadSwiftShader(ProgressCallback progress = nullptr);

    /**
     * DXVK'yı GitHub Releases'den indir.
     */
    bool downloadDXVK(ProgressCallback progress = nullptr);

    /**
     * VKD3D-Proton'u GitHub Releases'den indir.
     */
    bool downloadVKD3D(ProgressCallback progress = nullptr);

    // ── Durum mesajları ───────────────────────────────────────────────────
    std::wstring lastError() const { return m_lastError; }

    // ── Klasör yolları ────────────────────────────────────────────────────
    std::wstring swiftShaderDir() const { return m_swDir; }
    std::wstring dxvkDir()        const { return m_dxvkDir; }
    std::wstring vkd3dDir()       const { return m_vkd3dDir; }

    // ── Oyun profilleri (kaydet / yükle) ─────────────────────────────────
    bool saveProfiles(const std::vector<GameProfile>& profiles) const;
    bool loadProfiles(std::vector<GameProfile>& profiles) const;

private:
    std::wstring m_baseDir;    // OMURG.exe dizini
    std::wstring m_swDir;      // deps/swiftshader/
    std::wstring m_dxvkDir;    // deps/dxvk/x64/
    std::wstring m_vkd3dDir;   // deps/vkd3d/x64/
    std::wstring m_lastError;

    DXVKInstall  m_dxvk;
    VKD3DInstall m_vkd3d;

    bool m_swRegistered = false;

    // Yardımcı: iki dosyayı karşılaştır (imza kontrolü)
    static bool  filesEqual(const std::wstring& a, const std::wstring& b);
    // Yardımcı: kayıt defteri DWORD yaz
    static bool  regSetDword(HKEY root, const wchar_t* key,
                              const wchar_t* name, DWORD value);
    // Yardımcı: kayıt defteri SZ yaz
    static bool  regSetString(HKEY root, const wchar_t* key,
                               const wchar_t* name, const std::wstring& val);
    // Yardımcı: URL'den dosya indir (WinINet)
    bool downloadFile(const std::wstring& url,
                      const std::wstring& dest,
                      ProgressCallback    cb);
    // Yardımcı: ZIP aç
    bool extractZip(const std::wstring& zipPath,
                    const std::wstring& destDir,
                    ProgressCallback    cb);
    // Tarama
    void scanAvailableDeps();

    // Vulkan ICD JSON yolu
    std::wstring icdJsonPath() const;
    // ICD JSON dosyasını yaz
    bool writeICDJson(const std::wstring& dllPath) const;
};

#endif // GRAPHICS_API_H
