# =============================================================================
# OMURG - Get-Dependencies.ps1
# SwiftShader, DXVK ve VKD3D-Proton'u otomatik indir ve hazırla.
# Kullanım: .\Get-Dependencies.ps1 [-SkipSwiftShader] [-SkipDXVK] [-SkipVKD3D]
# =============================================================================

param(
    [switch]$SkipSwiftShader,
    [switch]$SkipDXVK,
    [switch]$SkipVKD3D,
    [string]$OutDir = "$PSScriptRoot\..\deps"
)

$ErrorActionPreference = "Stop"
$ProgressPreference    = "Continue"

function Write-Status($msg, $color = "Cyan") {
    Write-Host "[OMURG] $msg" -ForegroundColor $color
}

function Download-File($url, $dest) {
    Write-Status "İndiriliyor: $url"
    $client = New-Object System.Net.WebClient
    $client.Headers.Add("User-Agent", "OMURG-Installer/3.0")
    $client.DownloadFile($url, $dest)
    Write-Status "Tamamlandı: $dest" "Green"
}

function Get-LatestGitHubRelease($repo, $assetPattern) {
    $api = "https://api.github.com/repos/$repo/releases/latest"
    $headers = @{ "User-Agent" = "OMURG-Installer/3.0" }
    $release = Invoke-RestMethod -Uri $api -Headers $headers
    $asset = $release.assets | Where-Object { $_.name -like $assetPattern } | Select-Object -First 1
    if (-not $asset) {
        throw "Asset bulunamadı: $assetPattern ($repo)"
    }
    return @{
        url     = $asset.browser_download_url
        name    = $asset.name
        version = $release.tag_name
    }
}

# ── Çıkış klasörleri ─────────────────────────────────────────────────────────
New-Item -ItemType Directory -Force -Path "$OutDir\swiftshader" | Out-Null
New-Item -ItemType Directory -Force -Path "$OutDir\dxvk\x64"    | Out-Null
New-Item -ItemType Directory -Force -Path "$OutDir\vkd3d\x64"   | Out-Null

Write-Status "=== OMURG Bağımlılık Yükleyici ===" "Yellow"
Write-Status "Çıkış dizini: $OutDir"
Write-Host ""

# =============================================================================
# SwiftShader
# =============================================================================
if (-not $SkipSwiftShader) {
    Write-Status "--- SwiftShader (Vulkan ICD) ---" "Magenta"
    
    # SwiftShader pre-built binary (nicowillis/swiftshader-builds veya resmi)
    # Resmi Google SwiftShader build artifact
    $swUrl = "https://github.com/nicowillis/swiftshader-builds/releases/latest/download/swiftshader-windows-x64.zip"
    
    try {
        $swZip = "$env:TEMP\swiftshader-windows-x64.zip"
        Download-File $swUrl $swZip
        
        Write-Status "SwiftShader ZIP açılıyor..."
        Expand-Archive -Path $swZip -DestinationPath "$env:TEMP\sw_extract" -Force
        
        # DLL'i bul ve kopyala
        $swDll = Get-ChildItem -Path "$env:TEMP\sw_extract" -Recurse -Filter "vk_swiftshader.dll" | Select-Object -First 1
        if ($swDll) {
            Copy-Item $swDll.FullName "$OutDir\swiftshader\vk_swiftshader.dll" -Force
            Write-Status "vk_swiftshader.dll kopyalandı." "Green"
        } else {
            Write-Status "DLL bulunamadı — alternatif kaynak deneniyor..." "Yellow"
            # Chrome'dan swiftshader DLL al (yedek yöntem)
            $chromePath = "$env:ProgramFiles\Google\Chrome\Application"
            if (Test-Path $chromePath) {
                $chromeSW = Get-ChildItem $chromePath -Recurse -Filter "vk_swiftshader.dll" | Select-Object -First 1
                if ($chromeSW) {
                    Copy-Item $chromeSW.FullName "$OutDir\swiftshader\vk_swiftshader.dll" -Force
                    Write-Status "Chrome'dan vk_swiftshader.dll alındı." "Green"
                }
            }
        }
        
        # ICD JSON yaz
        $icdJson = @"
{
    "file_format_version": "1.0.0",
    "ICD": {
        "library_path": "$(Resolve-Path "$OutDir\swiftshader\vk_swiftshader.dll")",
        "api_version": "1.3.0"
    }
}
"@
        $icdJson | Out-File -FilePath "$OutDir\swiftshader\vk_swiftshader_icd.json" -Encoding UTF8
        Write-Status "ICD JSON oluşturuldu." "Green"
        
        # Temizlik
        Remove-Item $swZip -Force -ErrorAction SilentlyContinue
        Remove-Item "$env:TEMP\sw_extract" -Recurse -Force -ErrorAction SilentlyContinue
        
    } catch {
        Write-Status "SwiftShader indirilemedi: $_" "Red"
        Write-Status "Chrome kuruluysa, vk_swiftshader.dll otomatik alınmaya çalışılacak." "Yellow"
        
        # Chrome yedek
        $chromePaths = @(
            "$env:ProgramFiles\Google\Chrome\Application",
            "$env:LOCALAPPDATA\Google\Chrome\Application"
        )
        foreach ($cp in $chromePaths) {
            if (Test-Path $cp) {
                $dll = Get-ChildItem $cp -Recurse -Filter "vk_swiftshader.dll" -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($dll) {
                    Copy-Item $dll.FullName "$OutDir\swiftshader\vk_swiftshader.dll" -Force
                    Write-Status "Chrome'dan alındı: $($dll.FullName)" "Green"
                    break
                }
            }
        }
    }
    Write-Host ""
}

# =============================================================================
# DXVK
# =============================================================================
if (-not $SkipDXVK) {
    Write-Status "--- DXVK (DirectX → Vulkan) ---" "Magenta"
    
    try {
        $dxvkInfo = Get-LatestGitHubRelease "doitsujin/dxvk" "dxvk-*.tar.gz"
        Write-Status "DXVK $($dxvkInfo.version) bulundu."
        
        $dxvkTar = "$env:TEMP\$($dxvkInfo.name)"
        Download-File $dxvkInfo.url $dxvkTar
        
        # Windows 10 1803+ built-in tar
        Write-Status "DXVK arşivi açılıyor (tar)..."
        $dxvkExtract = "$env:TEMP\dxvk_extract"
        New-Item -ItemType Directory -Force -Path $dxvkExtract | Out-Null
        & tar.exe -xzf $dxvkTar -C $dxvkExtract
        
        # x64 DLL'leri kopyala
        $x64dir = Get-ChildItem $dxvkExtract -Recurse -Directory -Filter "x64" | Select-Object -First 1
        if ($x64dir) {
            $dlls = @("d3d9.dll", "d3d10core.dll", "d3d11.dll", "dxgi.dll")
            foreach ($dll in $dlls) {
                $src = Join-Path $x64dir.FullName $dll
                if (Test-Path $src) {
                    Copy-Item $src "$OutDir\dxvk\x64\$dll" -Force
                    Write-Status "  ✓ $dll" "Green"
                }
            }
        }
        
        # DXVK conf şablonu
        @"
# OMURG DXVK Konfigürasyonu
# Asenkron shader derleme (takılmaları azaltır)
dxvk.enableAsync = True
dxvk.numCompilerThreads = 0
dxvk.maxFrameLatency = 1
# HUD: fps,devinfo,memory,pipelines
dxvk.hud = fps,devinfo
"@ | Out-File "$OutDir\dxvk\dxvk.conf" -Encoding UTF8
        
        Remove-Item $dxvkTar -Force -ErrorAction SilentlyContinue
        Remove-Item $dxvkExtract -Recurse -Force -ErrorAction SilentlyContinue
        Write-Status "DXVK hazır." "Green"
        
    } catch {
        Write-Status "DXVK indirilemedi: $_" "Red"
    }
    Write-Host ""
}

# =============================================================================
# VKD3D-Proton (D3D12 → Vulkan)
# =============================================================================
if (-not $SkipVKD3D) {
    Write-Status "--- VKD3D-Proton (D3D12 → Vulkan) ---" "Magenta"
    
    try {
        $vkd3dInfo = Get-LatestGitHubRelease "HansKristian-Work/vkd3d-proton" "vkd3d-proton-*.tar.zst"
        Write-Status "VKD3D-Proton $($vkd3dInfo.version) bulundu."
        Write-Status "Not: .tar.zst formatı için 7-zip veya zstd gereklidir." "Yellow"
        
        # 7-zip varlığını kontrol et
        $7zip = Get-Command "7z.exe" -ErrorAction SilentlyContinue
        if (-not $7zip) {
            $7zip = Get-Item "C:\Program Files\7-Zip\7z.exe" -ErrorAction SilentlyContinue
        }
        
        if ($7zip) {
            $vkd3dZst = "$env:TEMP\$($vkd3dInfo.name)"
            Download-File $vkd3dInfo.url $vkd3dZst
            
            $vkd3dExtract = "$env:TEMP\vkd3d_extract"
            New-Item -ItemType Directory -Force -Path $vkd3dExtract | Out-Null
            & $7zip.Source x $vkd3dZst -o"$vkd3dExtract" -y
            & $7zip.Source x "$vkd3dExtract\$($vkd3dInfo.name -replace '\.zst$','')" -o"$vkd3dExtract" -y
            
            $x64dir = Get-ChildItem $vkd3dExtract -Recurse -Directory -Filter "x64" | Select-Object -First 1
            if ($x64dir) {
                $d3d12 = Join-Path $x64dir.FullName "d3d12.dll"
                if (Test-Path $d3d12) {
                    Copy-Item $d3d12 "$OutDir\vkd3d\x64\d3d12.dll" -Force
                    Write-Status "  ✓ d3d12.dll" "Green"
                }
            }
            
            Remove-Item $vkd3dZst -Force -ErrorAction SilentlyContinue
            Remove-Item $vkd3dExtract -Recurse -Force -ErrorAction SilentlyContinue
        } else {
            Write-Status "7-zip bulunamadı. VKD3D-Proton atlanıyor." "Yellow"
            Write-Status "Manuel kurulum: $($vkd3dInfo.url)" "Gray"
        }
        
    } catch {
        Write-Status "VKD3D-Proton indirilemedi: $_" "Yellow"
        Write-Status "D3D12 oyunları için opsiyonel." "Gray"
    }
    Write-Host ""
}

# =============================================================================
# Özet
# =============================================================================
Write-Host ""
Write-Status "=== Kurulum Özeti ===" "Yellow"

$swDll   = Test-Path "$OutDir\swiftshader\vk_swiftshader.dll"
$dxvkD11 = Test-Path "$OutDir\dxvk\x64\d3d11.dll"
$vkd3dD  = Test-Path "$OutDir\vkd3d\x64\d3d12.dll"

if ($swDll)   { Write-Status "✓ SwiftShader (Vulkan 1.3 ICD)" "Green" }
else          { Write-Status "✗ SwiftShader eksik" "Red" }

if ($dxvkD11) { Write-Status "✓ DXVK (D3D9/10/11 → Vulkan)" "Green" }
else          { Write-Status "✗ DXVK eksik" "Red" }

if ($vkd3dD)  { Write-Status "✓ VKD3D-Proton (D3D12 → Vulkan)" "Green" }
else          { Write-Status "○ VKD3D-Proton (opsiyonel, eksik)" "Yellow" }

Write-Host ""
Write-Status "OMURG'u açın ve 'Oyun Uyumluluğu' sekmesinden ICD'yi kaydedin." "Cyan"
Write-Host ""
