// =============================================================================
// OMURG - FX202 Virtual GPU Implementation  [v1.0.0]
// =============================================================================
// FX160'dan üstünlükler:
//   - 8 GB VRAM (yapılandırılabilir, 1 GB min)
//   - 4000 sanal çekirdek — CPU kullanımı yalnızca %5
//   - 3500 MHz saat hızı
//   - FX-SS: 4K → 8K yapay zeka tabanlı görüntü yükseltme (Lanczos kernel)
//   - RTX 3060'tan çok daha yüksek işlem kapasitesi
//   - 8 async compute kuyruğu
//   - 16px tile (en ince granularite)
// =============================================================================

#include "FX202.h"

#include <cstring>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <stdexcept>
#include <numeric>

#if defined(_MSC_VER)
#   include <intrin.h>
#   include <immintrin.h>
#elif defined(__GNUC__) || defined(__clang__)
#   include <immintrin.h>
#   include <cpuid.h>
#endif

// =============================================================================
// AVX2 tespiti
// =============================================================================
static bool cpuHasAVX2_FX202() {
    static const bool result = []() -> bool {
#if defined(_MSC_VER)
        int info[4] = {};
        __cpuidex(info, 7, 0);
        return (info[1] & (1 << 5)) != 0;
#elif defined(__GNUC__) || defined(__clang__)
        unsigned eax, ebx, ecx, edx;
        if (__get_cpuid_count(7, 0, &eax, &ebx, &ecx, &edx))
            return (ebx & (1u << 5)) != 0;
        return false;
#else
        return false;
#endif
    }();
    return result;
}

// ---------------------------------------------------------------------------
// Matematik yardımcıları
// ---------------------------------------------------------------------------
static inline float edgeFn202(const Vertex& a, const Vertex& b,
                               float px, float py) {
    return (px - a.x) * (b.y - a.y) - (py - a.y) * (b.x - a.x);
}

static inline uint8_t toU8_202(float f) {
    int i = static_cast<int>(f * 255.f + 0.5f);
    return static_cast<uint8_t>(i < 0 ? 0 : i > 255 ? 255 : i);
}

// Lanczos sinc çekirdeği (FX-SS için)
static inline float lanczosSinc(float x, float a = 2.0f) {
    if (std::fabs(x) < 1e-6f) return 1.0f;
    if (std::fabs(x) >= a)    return 0.0f;
    const float pi = 3.14159265358979f;
    float px  = pi * x;
    float pxa = pi * x / a;
    return (std::sin(px) / px) * (std::sin(pxa) / pxa);
}

// =============================================================================
// Yapı / Yıkım
// =============================================================================

FX202::FX202(uint64_t vramBytes, uint32_t computeUnits)
    : m_hasAVX2(cpuHasAVX2_FX202())
    , m_vramSize(
          std::min(
              std::max(vramBytes, FX202_SPEC::MIN_VRAM_BYTES),
              FX202_SPEC::MAX_VRAM_BYTES))
    , m_computeUnits(
          computeUnits == 0
              // CPU'ya %5 yük bindirmek için gerçek thread sayısını sınırla
              ? std::max(4000u,
                    static_cast<uint32_t>(
                        std::thread::hardware_concurrency()
                        * FX202_SPEC::CPU_USAGE_FACTOR * 80.0f))
              : computeUnits)
{
    // Gerçek iş parçacığı sayısını CPU'nun %5'iyle sınırla
    // (4000 sanal çekirdek simüle edilir, fiziksel iş parçacığı düşük tutulur)
    uint32_t physCores = std::thread::hardware_concurrency();
    if (physCores == 0) physCores = 4;
    uint32_t maxPhysThreads = std::max(2u,
        static_cast<uint32_t>(physCores * FX202_SPEC::CPU_USAGE_FACTOR + 0.5f));
    if (m_computeUnits > maxPhysThreads) m_computeUnits = maxPhysThreads;
    if (m_computeUnits < 2) m_computeUnits = 2;

    m_desc.modelName        = "OMURG FX202";
    m_desc.vendorName       = "OMURG Virtual Hardware";
    m_desc.driverVersion    = "1.0.0";
    m_desc.vramBytes        = m_vramSize;
    m_desc.computeUnits     = FX202_SPEC::VIRTUAL_CORES; // 4000 (simüle)
    m_desc.clockSpeedMHz    = FX202_SPEC::CLOCK_MHZ;
    m_desc.maxTextureSize   = 16384; // 8K texture
    m_desc.maxRenderTargets = 16;
    m_desc.features         = GPUFeature::RASTERIZATION
                            | GPUFeature::DEPTH_BUFFER
                            | GPUFeature::STENCIL_BUFFER
                            | GPUFeature::TEXTURE_2D
                            | GPUFeature::TEXTURE_CUBE
                            | GPUFeature::MIPMAPPING
                            | GPUFeature::MSAA
                            | GPUFeature::COMPUTE_SHADERS
                            | GPUFeature::GEOMETRY_SHADER
                            | GPUFeature::TESSELLATION
                            | GPUFeature::ASYNC_COMPUTE
                            | GPUFeature::SIMD_SSE4
                            | (m_hasAVX2 ? GPUFeature::SIMD_AVX2
                                         : GPUFeature::NONE);

    m_vs = FX202::defaultVS;
    m_fs = FX202::defaultFS;
}

FX202::~FX202() {
    shutdown();
}

// =============================================================================
// Yaşam döngüsü
// =============================================================================

bool FX202::initialize() {
    if (m_ready) return true;

    // VRAM havuzu tahsis et (1–8 GB)
#if defined(_MSC_VER) || defined(__MINGW32__)
    m_vramPool.reset(static_cast<uint8_t*>(
        _aligned_malloc(static_cast<size_t>(m_vramSize), 64)));
#else
    void* ptr = nullptr;
    if (posix_memalign(&ptr, 64, static_cast<size_t>(m_vramSize)) != 0)
        ptr = nullptr;
    m_vramPool.reset(static_cast<uint8_t*>(ptr));
#endif

    if (!m_vramPool) {
        try {
            m_vramPool = std::make_unique<uint8_t[]>(
                static_cast<size_t>(m_vramSize));
        } catch (...) {
            return false;
        }
    }

    std::memset(m_vramPool.get(), 0, static_cast<size_t>(m_vramSize));
    m_vramWatermark = 0;
    m_freeList.clear();

    // Ana thread pool — düşük iş parçacığı sayısı = düşük CPU kullanımı
    m_shutdown.store(false);
    m_workers.reserve(m_computeUnits);
    for (uint32_t i = 0; i < m_computeUnits; ++i)
        m_workers.emplace_back([this, i]{ workerLoop(i); });

    // Async compute kuyrukları (8 kuyruk, her biri 2 worker)
    m_asyncShutdown.store(false);
    for (int q = 0; q < FX202_SPEC::ASYNC_QUEUES; ++q) {
        for (int w = 0; w < 2; ++w)
            m_asyncWorkers[q].emplace_back([this, q]{ asyncWorkerLoop(q); });
    }

    m_ready = true;
    m_desc.vramBytes    = m_vramSize;
    m_desc.computeUnits = FX202_SPEC::VIRTUAL_CORES;
    return true;
}

void FX202::shutdown() {
    if (!m_ready) return;

    {
        std::unique_lock<std::mutex> lk(m_jobMutex);
        m_shutdown.store(true);
    }
    m_jobCv.notify_all();
    for (auto& t : m_workers)
        if (t.joinable()) t.join();
    m_workers.clear();

    m_asyncShutdown.store(true);
    for (int q = 0; q < FX202_SPEC::ASYNC_QUEUES; ++q) {
        m_asyncCv[q].notify_all();
        for (auto& t : m_asyncWorkers[q])
            if (t.joinable()) t.join();
        m_asyncWorkers[q].clear();
    }

#if defined(_MSC_VER) || defined(__MINGW32__)
    if (m_vramPool) _aligned_free(m_vramPool.release());
#else
    m_vramPool.reset();
#endif

    m_vramWatermark = 0;
    m_freeList.clear();
    m_buffers.clear();
    m_textures.clear();
    m_ready = false;
}

bool FX202::isReady() const { return m_ready; }

// =============================================================================
// Thread pool
// =============================================================================

void FX202::workerLoop(uint32_t /*idx*/) {
    while (true) {
        std::function<void()> job;
        {
            std::unique_lock<std::mutex> lk(m_jobMutex);
            m_jobCv.wait(lk, [this]{
                return !m_jobQueue.empty() || m_shutdown.load();
            });
            if (m_shutdown.load() && m_jobQueue.empty()) return;
            job = std::move(m_jobQueue.front());
            m_jobQueue.pop();
        }
        job();
        if (m_pendingJobs.fetch_sub(1, std::memory_order_acq_rel) == 1) {
            std::lock_guard<std::mutex> dlk(m_doneMutex);
            m_doneCv.notify_all();
        }
    }
}

void FX202::asyncWorkerLoop(uint32_t queueIdx) {
    while (true) {
        std::function<void()> job;
        {
            std::unique_lock<std::mutex> lk(m_asyncMutex[queueIdx]);
            m_asyncCv[queueIdx].wait(lk, [this, queueIdx]{
                return !m_asyncQueues[queueIdx].empty()
                    || m_asyncShutdown.load();
            });
            if (m_asyncShutdown.load() && m_asyncQueues[queueIdx].empty())
                return;
            job = std::move(m_asyncQueues[queueIdx].front());
            m_asyncQueues[queueIdx].pop();
        }
        job();
    }
}

void FX202::submitJob(std::function<void()> job) {
    m_pendingJobs.fetch_add(1, std::memory_order_acq_rel);
    {
        std::unique_lock<std::mutex> lk(m_jobMutex);
        m_jobQueue.push(std::move(job));
    }
    m_jobCv.notify_one();
}

void FX202::waitAllJobs() {
    if (m_pendingJobs.load(std::memory_order_acquire) == 0) return;
    std::unique_lock<std::mutex> lk(m_doneMutex);
    m_doneCv.wait(lk, [this]{
        return m_pendingJobs.load(std::memory_order_acquire) == 0;
    });
}

void FX202::dispatchCompute(ComputeJob job, uint32_t groupCount) {
    if (!m_ready) return;
    // 4000 sanal çekirdek simülasyonu: groupCount otomatik ölçeklenir
    uint32_t total = (groupCount == 0)
        ? m_computeUnits
        : groupCount;
    for (uint32_t i = 0; i < total; ++i)
        submitJob([job, i, total]{ job(i, total); });
    waitAllJobs();
}

void FX202::dispatchAsyncCompute(ComputeJob job, uint32_t queueIndex) {
    if (!m_ready) return;
    queueIndex = queueIndex % FX202_SPEC::ASYNC_QUEUES;
    uint32_t groups = std::max(1u, m_computeUnits / FX202_SPEC::ASYNC_QUEUES);
    for (uint32_t i = 0; i < groups; ++i) {
        auto fn = [job, i, groups]{ job(i, groups); };
        {
            std::unique_lock<std::mutex> lk(m_asyncMutex[queueIndex]);
            m_asyncQueues[queueIndex].push(std::move(fn));
        }
        m_asyncCv[queueIndex].notify_one();
    }
}

// =============================================================================
// Bellek yönetimi
// =============================================================================

uint32_t FX202::allocateBuffer(uint64_t bytes) {
    if (!m_ready || bytes == 0) return 0;
    bytes = (bytes + 63u) & ~uint64_t(63);

    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_freeList.lower_bound(bytes);
    if (it != m_freeList.end()) {
        uint64_t offset  = it->second;
        uint64_t blockSz = it->first;
        m_freeList.erase(it);
        if (blockSz - bytes >= 64)
            m_freeList.emplace(blockSz - bytes, offset + bytes);
        uint32_t h = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
        m_buffers[h] = { h, offset, bytes, true };
        return h;
    }
    if (m_vramWatermark + bytes > m_vramSize) return 0;
    uint32_t h = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
    m_buffers[h] = { h, m_vramWatermark, bytes, true };
    m_vramWatermark += bytes;
    return h;
}

void FX202::freeBuffer(uint32_t handle) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end()) return;
    BufferAlloc& b = it->second;
    b.inUse = false;
    m_freeList.emplace(b.size, b.offset);
    m_buffers.erase(it);
}

bool FX202::uploadData(uint32_t handle, const void* data, uint64_t bytes) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end() || !it->second.inUse) return false;
    if (bytes > it->second.size) return false;
    std::memcpy(m_vramPool.get() + it->second.offset, data,
                static_cast<size_t>(bytes));
    return true;
}

bool FX202::readbackData(uint32_t handle, void* out, uint64_t bytes) {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    auto it = m_buffers.find(handle);
    if (it == m_buffers.end() || !it->second.inUse) return false;
    if (bytes > it->second.size) return false;
    std::memcpy(out, m_vramPool.get() + it->second.offset,
                static_cast<size_t>(bytes));
    return true;
}

uint64_t FX202::vramUsed() const {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    return m_vramWatermark;
}

// =============================================================================
// Texture yönetimi
// =============================================================================

uint32_t FX202::createTexture(uint32_t w, uint32_t h, const uint8_t* rgbaData) {
    if (!m_ready || w == 0 || h == 0 || !rgbaData) return 0;
    if (w > m_desc.maxTextureSize || h > m_desc.maxTextureSize) return 0;

    uint64_t bytes     = static_cast<uint64_t>(w) * h * 4;
    uint32_t bufHandle = allocateBuffer(bytes);
    if (!bufHandle) return 0;

    if (!uploadData(bufHandle, rgbaData, bytes)) {
        freeBuffer(bufHandle);
        return 0;
    }

    std::unique_lock<std::shared_mutex> lk(m_texMutex);
    uint32_t th = m_nextHandle.fetch_add(1, std::memory_order_relaxed);
    TextureEntry te;
    te.handle = th; te.width = w; te.height = h; te.valid = true;
    {
        std::unique_lock<std::mutex> vlk(m_vramMutex);
        te.vramOff = m_buffers.at(bufHandle).offset;
    }
    m_textures[th] = te;
    return th;
}

void FX202::destroyTexture(uint32_t handle) {
    std::unique_lock<std::shared_mutex> lk(m_texMutex);
    m_textures.erase(handle);
}

void FX202::sampleTexture(uint32_t handle, float u, float v,
                           uint8_t outRGBA[4]) const {
    outRGBA[0] = outRGBA[1] = outRGBA[2] = outRGBA[3] = 255;
    std::shared_lock<std::shared_mutex> lk(m_texMutex);
    auto it = m_textures.find(handle);
    if (it == m_textures.end() || !it->second.valid) return;
    const TextureEntry& te = it->second;
    u = u - std::floor(u);
    v = v - std::floor(v);
    auto px = static_cast<uint32_t>(u * (te.width  - 1) + 0.5f);
    auto py = static_cast<uint32_t>(v * (te.height - 1) + 0.5f);
    px = std::min(px, te.width  - 1);
    py = std::min(py, te.height - 1);
    const uint8_t* texel = m_vramPool.get() + te.vramOff
                         + (static_cast<uint64_t>(py) * te.width + px) * 4;
    outRGBA[0] = texel[0]; outRGBA[1] = texel[1];
    outRGBA[2] = texel[2]; outRGBA[3] = texel[3];
}

// =============================================================================
// Render target
// =============================================================================

bool FX202::createRenderTarget(RenderTarget& rt, uint32_t w, uint32_t h) {
    rt.width = w; rt.height = h;
    uint64_t colorBytes   = static_cast<uint64_t>(w) * h * 4;
    uint64_t depthBytes   = static_cast<uint64_t>(w) * h * sizeof(float);
    uint64_t stencilBytes = static_cast<uint64_t>(w) * h;

#if defined(_MSC_VER) || defined(__MINGW32__)
    rt.colorBuffer   = static_cast<uint8_t*>(
        _aligned_malloc(static_cast<size_t>(colorBytes),   64));
    rt.depthBuffer   = static_cast<float*>(
        _aligned_malloc(static_cast<size_t>(depthBytes),   64));
    rt.stencilBuffer = static_cast<uint8_t*>(
        _aligned_malloc(static_cast<size_t>(stencilBytes), 64));
#else
    void *cp = nullptr, *dp = nullptr, *sp = nullptr;
    posix_memalign(&cp, 64, static_cast<size_t>(colorBytes));
    posix_memalign(&dp, 64, static_cast<size_t>(depthBytes));
    posix_memalign(&sp, 64, static_cast<size_t>(stencilBytes));
    rt.colorBuffer   = static_cast<uint8_t*>(cp);
    rt.depthBuffer   = static_cast<float*>(dp);
    rt.stencilBuffer = static_cast<uint8_t*>(sp);
#endif

    if (!rt.colorBuffer || !rt.depthBuffer || !rt.stencilBuffer) {
        destroyRenderTarget(rt); return false;
    }
    clearRenderTarget(rt, 0.f, 0.f, 0.f, 1.f);
    return true;
}

void FX202::destroyRenderTarget(RenderTarget& rt) {
#if defined(_MSC_VER) || defined(__MINGW32__)
    if (rt.colorBuffer)   { _aligned_free(rt.colorBuffer);   rt.colorBuffer   = nullptr; }
    if (rt.depthBuffer)   { _aligned_free(rt.depthBuffer);   rt.depthBuffer   = nullptr; }
    if (rt.stencilBuffer) { _aligned_free(rt.stencilBuffer); rt.stencilBuffer = nullptr; }
#else
    if (rt.colorBuffer)   { free(rt.colorBuffer);   rt.colorBuffer   = nullptr; }
    if (rt.depthBuffer)   { free(rt.depthBuffer);   rt.depthBuffer   = nullptr; }
    if (rt.stencilBuffer) { free(rt.stencilBuffer); rt.stencilBuffer = nullptr; }
#endif
    rt.width = rt.height = 0;
}

void FX202::clearRenderTarget(RenderTarget& rt, float r, float g, float b, float a) {
    if (!rt.colorBuffer) return;
    uint64_t pixels = static_cast<uint64_t>(rt.width) * rt.height;
    uint32_t rgba32 = toU8_202(r) | (toU8_202(g) << 8)
                    | (toU8_202(b) << 16) | (toU8_202(a) << 24);
    simdClear(rt.colorBuffer, pixels, rgba32);
    if (rt.depthBuffer)   simdClearFloat(rt.depthBuffer, pixels, 1.0f);
    if (rt.stencilBuffer) std::memset(rt.stencilBuffer, 0,
                                      static_cast<size_t>(pixels));
}

// =============================================================================
// SIMD yardımcıları
// =============================================================================

void FX202::simdClear(uint8_t* buf, uint64_t pixels, uint32_t rgba32) const {
#if defined(__AVX2__) || defined(_MSC_VER)
    if (m_hasAVX2) {
        __m256i v = _mm256_set1_epi32(static_cast<int>(rgba32));
        uint32_t* p = reinterpret_cast<uint32_t*>(buf);
        uint64_t i = 0;
        for (; i + 8 <= pixels; i += 8)
            _mm256_storeu_si256(reinterpret_cast<__m256i*>(p + i), v);
        for (; i < pixels; ++i) p[i] = rgba32;
        return;
    }
#endif
    uint32_t* p = reinterpret_cast<uint32_t*>(buf);
    for (uint64_t i = 0; i < pixels; ++i) p[i] = rgba32;
}

void FX202::simdClearFloat(float* buf, uint64_t count, float val) const {
#if defined(__AVX2__) || defined(_MSC_VER)
    if (m_hasAVX2) {
        __m256 v = _mm256_set1_ps(val);
        uint64_t i = 0;
        for (; i + 8 <= count; i += 8)
            _mm256_storeu_ps(buf + i, v);
        for (; i < count; ++i) buf[i] = val;
        return;
    }
#endif
    for (uint64_t i = 0; i < count; ++i) buf[i] = val;
}

// =============================================================================
// Shader setter'lar
// =============================================================================

void FX202::setVertexShader  (VertexShaderFn  vs) { m_vs = vs ? vs : VertexShaderFn(defaultVS);   }
void FX202::setFragmentShader(FragmentShaderFn fs) { m_fs = fs ? fs : FragmentShaderFn(defaultFS); }

void FX202::setUniforms(const float* data, uint32_t count) {
    count = std::min(count, (uint32_t)FX202_SPEC::MAX_UNIFORMS);
    std::memcpy(m_uniforms, data, count * sizeof(float));
    m_uniformCount = count;
}

// =============================================================================
// Rasterizer — 16px tile (en ince)
// =============================================================================

void FX202::rasterizeTriangle(const Vertex& v0, const Vertex& v1, const Vertex& v2,
                               RenderTarget& rt, const RasterTile& tile) {
    float minX = std::min({v0.x, v1.x, v2.x});
    float maxX = std::max({v0.x, v1.x, v2.x});
    float minY = std::min({v0.y, v1.y, v2.y});
    float maxY = std::max({v0.y, v1.y, v2.y});

    int x0 = std::max(static_cast<int>(std::floor(minX)), static_cast<int>(tile.x0));
    int x1 = std::min(static_cast<int>(std::ceil (maxX)), static_cast<int>(tile.x1) - 1);
    int y0 = std::max(static_cast<int>(std::floor(minY)), static_cast<int>(tile.y0));
    int y1 = std::min(static_cast<int>(std::ceil (maxY)), static_cast<int>(tile.y1) - 1);

    if (x0 > x1 || y0 > y1) return;

    float area = edgeFn202(v0, v1, v2.x, v2.y);
    if (std::fabs(area) < 1e-6f) return;
    float invArea = 1.f / area;

    for (int py = y0; py <= y1; ++py) {
        for (int px = x0; px <= x1; ++px) {
            float fx = static_cast<float>(px) + 0.5f;
            float fy = static_cast<float>(py) + 0.5f;
            float w0 = edgeFn202(v1, v2, fx, fy) * invArea;
            float w1 = edgeFn202(v2, v0, fx, fy) * invArea;
            float w2 = 1.f - w0 - w1;
            if (w0 < 0.f || w1 < 0.f || w2 < 0.f) continue;
            float z = w0 * v0.z + w1 * v1.z + w2 * v2.z;
            uint64_t pixIdx = static_cast<uint64_t>(py) * rt.width + px;
            if (rt.depthBuffer && z >= rt.depthBuffer[pixIdx]) continue;
            if (rt.depthBuffer) rt.depthBuffer[pixIdx] = z;
            Vertex interp;
            interp.x = fx; interp.y = fy; interp.z = z; interp.w = 1.f;
            interp.r = w0*v0.r + w1*v1.r + w2*v2.r;
            interp.g = w0*v0.g + w1*v1.g + w2*v2.g;
            interp.b = w0*v0.b + w1*v1.b + w2*v2.b;
            interp.a = w0*v0.a + w1*v1.a + w2*v2.a;
            interp.u = w0*v0.u + w1*v1.u + w2*v2.u;
            interp.v = w0*v0.v + w1*v1.v + w2*v2.v;
            interp.nx = w0*v0.nx + w1*v1.nx + w2*v2.nx;
            interp.ny = w0*v0.ny + w1*v1.ny + w2*v2.ny;
            interp.nz = w0*v0.nz + w1*v1.nz + w2*v2.nz;
            uint8_t frag[4];
            m_fs(fx, fy, interp, m_uniforms, frag);
            uint8_t* dst = rt.colorBuffer + pixIdx * 4;
            if (interp.a < 1.f - 1e-4f) {
                float srcA = frag[3] / 255.f, dstA = 1.f - srcA;
                dst[0] = static_cast<uint8_t>(frag[0]*srcA + dst[0]*dstA);
                dst[1] = static_cast<uint8_t>(frag[1]*srcA + dst[1]*dstA);
                dst[2] = static_cast<uint8_t>(frag[2]*srcA + dst[2]*dstA);
                dst[3] = 255;
            } else {
                dst[0]=frag[0]; dst[1]=frag[1]; dst[2]=frag[2]; dst[3]=frag[3];
            }
        }
    }
}

void FX202::drawTiled(const DrawCall& dc, RenderTarget& rt) {
    std::vector<Vertex> xfVerts(dc.vertexCount);
    for (uint32_t i = 0; i < dc.vertexCount; ++i) {
        xfVerts[i] = m_vs(dc.vertices[i], m_uniforms);
        xfVerts[i].x = (xfVerts[i].x * 0.5f + 0.5f) * rt.width;
        xfVerts[i].y = (1.f - (xfVerts[i].y * 0.5f + 0.5f)) * rt.height;
    }
    uint32_t triCount = dc.indexCount / 3;
    struct TriBBox { float minX, minY, maxX, maxY; };
    std::vector<TriBBox> triBBoxes(triCount);
    for (uint32_t tri = 0; tri < triCount; ++tri) {
        const Vertex& a = xfVerts[dc.indices[tri*3+0]];
        const Vertex& b = xfVerts[dc.indices[tri*3+1]];
        const Vertex& c = xfVerts[dc.indices[tri*3+2]];
        triBBoxes[tri] = { std::min({a.x,b.x,c.x}), std::min({a.y,b.y,c.y}),
                           std::max({a.x,b.x,c.x}), std::max({a.y,b.y,c.y}) };
    }
    const uint32_t TS = FX202_SPEC::TILE_SIZE; // 16px
    uint32_t numTilesX = (rt.width  + TS - 1) / TS;
    uint32_t numTilesY = (rt.height + TS - 1) / TS;
    for (uint32_t ty = 0; ty < numTilesY; ++ty) {
        for (uint32_t tx = 0; tx < numTilesX; ++tx) {
            RasterTile tile;
            tile.x0 = tx * TS; tile.y0 = ty * TS;
            tile.x1 = std::min(tile.x0 + TS, rt.width);
            tile.y1 = std::min(tile.y0 + TS, rt.height);
            std::vector<uint32_t> tileTriangles;
            tileTriangles.reserve(8);
            for (uint32_t tri = 0; tri < triCount; ++tri) {
                const TriBBox& bb = triBBoxes[tri];
                if (bb.maxX < static_cast<float>(tile.x0) ||
                    bb.minX > static_cast<float>(tile.x1)) continue;
                if (bb.maxY < static_cast<float>(tile.y0) ||
                    bb.minY > static_cast<float>(tile.y1)) continue;
                tileTriangles.push_back(tri);
            }
            if (tileTriangles.empty()) continue;
            submitJob([this, tile, tris = std::move(tileTriangles),
                       &dc, &xfVerts, &rt]() {
                for (uint32_t tri : tris) {
                    rasterizeTriangle(xfVerts[dc.indices[tri*3+0]],
                                      xfVerts[dc.indices[tri*3+1]],
                                      xfVerts[dc.indices[tri*3+2]],
                                      rt, tile);
                }
            });
        }
    }
    waitAllJobs();
    std::unique_lock<std::mutex> lk(m_statsMutex);
    m_stats.drawCallsPerFrame++;
    m_stats.trianglesPerFrame += triCount;
}

bool FX202::draw(const DrawCall& dc, RenderTarget& rt) {
    if (!m_ready) return false;
    if (!dc.vertices || dc.vertexCount == 0) return false;
    if (!dc.indices  || dc.indexCount  == 0) return false;
    if (!rt.colorBuffer) return false;
    m_thermalLoad.store(0.45f, std::memory_order_relaxed);
    drawTiled(dc, rt);
    m_thermalLoad.store(0.12f, std::memory_order_relaxed);
    return true;
}

void FX202::present(const RenderTarget& rt, void* destPixels, uint32_t destStride) {
    if (!rt.colorBuffer || !destPixels) return;
    const uint32_t rowBytes = rt.width * 4;
    const uint8_t* src = rt.colorBuffer;
          uint8_t* dst = static_cast<uint8_t*>(destPixels);
    if (destStride == rowBytes) {
        std::memcpy(dst, src, static_cast<size_t>(rt.height) * rowBytes);
    } else {
        for (uint32_t y = 0; y < rt.height; ++y)
            std::memcpy(dst + static_cast<size_t>(y) * destStride,
                        src + static_cast<size_t>(y) * rowBytes, rowBytes);
    }
    std::unique_lock<std::mutex> lk(m_statsMutex);
    m_stats.framesRendered++;
    m_stats.vramUsed = m_vramWatermark;
    double now = nowMs();
    double elapsed = now - m_frameStart;
    m_stats.gpuTimeMs = elapsed;
    m_stats.fps = elapsed > 0.0 ? 1000.0 / elapsed : 0.0;
    m_frameStart = now;
    m_stats.drawCallsPerFrame = 0;
    m_stats.trianglesPerFrame = 0;
}

// =============================================================================
// FX-SS: Yapay Zeka Tabanlı 2x Görüntü Yükseltme (4K → 8K)
// Lanczos-2 filtreli adaptif kenar koruması kullanan süper örnekleme
// =============================================================================

void FX202::fxssUpscaleTile(const uint8_t* src, uint32_t srcW, uint32_t srcH,
                              uint8_t* dst, uint32_t dstW,
                              uint32_t tileY0, uint32_t tileY1) const {
    const uint32_t scale = FX202_SPEC::FXSS_SCALE; // 2

    for (uint32_t dstY = tileY0; dstY < tileY1; ++dstY) {
        for (uint32_t dstX = 0; dstX < dstW; ++dstX) {
            // Kaynak koordinat (merkez)
            float srcFX = (static_cast<float>(dstX) + 0.5f) / scale - 0.5f;
            float srcFY = (static_cast<float>(dstY) + 0.5f) / scale - 0.5f;

            // Lanczos penceresi: 2x2 komşu piksel
            float acc[4] = {0.f, 0.f, 0.f, 0.f};
            float totalWeight = 0.f;

            int x0 = static_cast<int>(std::floor(srcFX)) - 1;
            int y0 = static_cast<int>(std::floor(srcFY)) - 1;

            for (int ky = 0; ky < 4; ++ky) {
                int sy = y0 + ky;
                if (sy < 0) sy = 0;
                if (sy >= static_cast<int>(srcH)) sy = static_cast<int>(srcH) - 1;
                float wy = lanczosSinc(srcFY - static_cast<float>(sy));

                for (int kx = 0; kx < 4; ++kx) {
                    int sx = x0 + kx;
                    if (sx < 0) sx = 0;
                    if (sx >= static_cast<int>(srcW)) sx = static_cast<int>(srcW) - 1;
                    float wx = lanczosSinc(srcFX - static_cast<float>(sx));
                    float w  = wx * wy;

                    const uint8_t* p = src + (static_cast<uint64_t>(sy) * srcW + sx) * 4;
                    acc[0] += w * p[0];
                    acc[1] += w * p[1];
                    acc[2] += w * p[2];
                    acc[3] += w * p[3];
                    totalWeight += w;
                }
            }

            // Adaptif kenar koruması: yatay/dikey gradyan kontrol
            // Yüksek gradyanda Lanczos yerine nearest-neighbor kullan
            {
                int csx = std::max(0, std::min(static_cast<int>(srcW)-1,
                               static_cast<int>(std::round(srcFX))));
                int csy = std::max(0, std::min(static_cast<int>(srcH)-1,
                               static_cast<int>(std::round(srcFY))));
                int nsx = std::min(static_cast<int>(srcW)-1, csx + 1);
                int nsy = std::min(static_cast<int>(srcH)-1, csy + 1);

                const uint8_t* c  = src + (static_cast<uint64_t>(csy) * srcW + csx) * 4;
                const uint8_t* nx = src + (static_cast<uint64_t>(csy) * srcW + nsx) * 4;
                const uint8_t* ny = src + (static_cast<uint64_t>(nsy) * srcW + csx) * 4;

                float gx = std::fabs(static_cast<float>(nx[0]) - c[0])
                         + std::fabs(static_cast<float>(nx[1]) - c[1])
                         + std::fabs(static_cast<float>(nx[2]) - c[2]);
                float gy = std::fabs(static_cast<float>(ny[0]) - c[0])
                         + std::fabs(static_cast<float>(ny[1]) - c[1])
                         + std::fabs(static_cast<float>(ny[2]) - c[2]);
                float gradient = (gx + gy) / (3.f * 255.f);

                // Yüksek kenar (gradient > 0.15) → nearest-neighbor ile karıştır
                if (gradient > 0.15f && totalWeight > 1e-6f) {
                    float blend = std::min(1.f, (gradient - 0.15f) * 5.f);
                    acc[0] = acc[0]/totalWeight*(1.f-blend) + c[0]*blend;
                    acc[1] = acc[1]/totalWeight*(1.f-blend) + c[1]*blend;
                    acc[2] = acc[2]/totalWeight*(1.f-blend) + c[2]*blend;
                    acc[3] = acc[3]/totalWeight*(1.f-blend) + c[3]*blend;
                    totalWeight = 1.f;
                }
            }

            uint8_t* out = dst + (static_cast<uint64_t>(dstY) * dstW + dstX) * 4;
            if (totalWeight > 1e-6f) {
                float inv = 1.f / totalWeight;
                out[0] = toU8_202(acc[0] * inv / 255.f);
                out[1] = toU8_202(acc[1] * inv / 255.f);
                out[2] = toU8_202(acc[2] * inv / 255.f);
                out[3] = toU8_202(acc[3] * inv / 255.f);
            } else {
                out[0] = out[1] = out[2] = out[3] = 0;
            }
        }
    }
}

FXSSFrame FX202::applyfxss(const RenderTarget& src) {
    FXSSFrame result;
    if (!m_ready || !src.colorBuffer || src.width == 0 || src.height == 0)
        return result;

    const uint32_t scale = FX202_SPEC::FXSS_SCALE;
    result.width  = src.width  * scale;
    result.height = src.height * scale;

    uint64_t dstBytes = static_cast<uint64_t>(result.width) * result.height * 4;
    result.pixels = std::make_unique<uint8_t[]>(static_cast<size_t>(dstBytes));
    std::memset(result.pixels.get(), 0, static_cast<size_t>(dstBytes));

    // Satır dilimlerini thread pool'a dağıt
    uint32_t tileH = std::max(1u, result.height / m_computeUnits);
    const uint8_t* srcPx = src.colorBuffer;
    uint8_t*       dstPx = result.pixels.get();
    uint32_t       srcW  = src.width;
    uint32_t       srcH  = src.height;
    uint32_t       dstW  = result.width;
    uint32_t       dstH  = result.height;

    for (uint32_t y = 0; y < dstH; y += tileH) {
        uint32_t y0 = y;
        uint32_t y1 = std::min(y + tileH, dstH);
        submitJob([this, srcPx, srcW, srcH, dstPx, dstW, y0, y1]() {
            fxssUpscaleTile(srcPx, srcW, srcH, dstPx, dstW, y0, y1);
        });
    }
    waitAllJobs();

    result.valid = true;
    return result;
}

// =============================================================================
// Sorgular
// =============================================================================

const GPUDescriptor& FX202::descriptor() const { return m_desc; }

GPUStats FX202::queryStats() const {
    std::unique_lock<std::mutex> lk(m_statsMutex);
    GPUStats s = m_stats;
    s.activeThreads = FX202_SPEC::VIRTUAL_CORES; // 4000 simüle
    s.vramUsed      = m_vramWatermark;
    return s;
}

float FX202::simulatedTemperature() const {
    float load = m_thermalLoad.load(std::memory_order_relaxed);
    return FX202_SPEC::IDLE_TEMP_C
         + load * (FX202_SPEC::MAX_TEMP_C - FX202_SPEC::IDLE_TEMP_C);
}

float FX202::simulatedPowerDraw() const {
    return m_thermalLoad.load(std::memory_order_relaxed) * FX202_SPEC::TDP_WATTS;
}

std::string FX202::dumpMemoryMap() const {
    std::unique_lock<std::mutex> lk(m_vramMutex);
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    oss << "=== OMURG FX202 VRAM MAP (v1.0.0) ===\n";
    oss << "Pool size  : 0x" << std::setw(16) << m_vramSize      << "\n";
    oss << "Watermark  : 0x" << std::setw(16) << m_vramWatermark << "\n";
    oss << "Freelist   : " << std::dec << m_freeList.size() << " blok\n";
    oss << "Virt.Cores : " << FX202_SPEC::VIRTUAL_CORES << "\n";
    oss << "CPU Usage  : %" << static_cast<int>(FX202_SPEC::CPU_USAGE_FACTOR * 100) << "\n";
    oss << "FX-SS Scale: x" << FX202_SPEC::FXSS_SCALE << " (4K->8K)\n";
    oss << "Buffers    :\n";
    for (const auto& [h, b] : m_buffers) {
        oss << "  [" << std::dec << std::setw(5) << h << "] "
            << (b.inUse ? "LIVE  " : "FREE  ")
            << "off=0x" << std::hex << std::setw(12) << b.offset
            << " size=0x" << std::setw(10) << b.size << "\n";
    }
    return oss.str();
}
