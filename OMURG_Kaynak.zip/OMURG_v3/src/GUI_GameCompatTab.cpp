// =============================================================================
// OMURG - GUI_GameCompatTab.cpp
// Bu dosyayı GUI.cpp içindeki tab döngüsüne ekleyin.
// GraphicsAPIManager ve GameLauncher nesnelerini GUI.cpp'de oluşturmanız gerekir.
//
// GUI.cpp üstüne ekle:
//   #include "GraphicsAPI.h"
//   #include "GameLauncher.h"
//   static GraphicsAPIManager g_graphicsAPI;
//   static GameLauncher* g_launcher = nullptr;
//
// WinMain / initDevice'ten sonra ekle:
//   wchar_t exeDir[MAX_PATH] = {};
//   GetModuleFileNameW(nullptr, exeDir, MAX_PATH);
//   PathRemoveFileSpecW(exeDir);
//   g_graphicsAPI.initialize(exeDir);
//   g_launcher = new GameLauncher(g_graphicsAPI);
//   g_launcher->loadProfiles();
// =============================================================================

// ─── TAB: Oyun Uyumluluğu ───────────────────────────────────────────────────
if (ImGui::BeginTabItem(u8"🎮 Oyun Uyumluluğu")) {
    ImGui::Spacing();

    // ── Üst durum bandı ─────────────────────────────────────────────────
    bool swOk   = g_graphicsAPI.isSwiftShaderAvailable();
    bool swReg  = g_graphicsAPI.isSwiftShaderRegistered();
    bool dxvkOk = g_graphicsAPI.isDXVKAvailable();
    bool vkOk   = g_graphicsAPI.isAnyVulkanPresent();
    bool vkd3dOk= g_graphicsAPI.isVKD3DAvailable();

    // Renk durumu
    auto statusDot = [](bool ok) {
        if (ok) ImGui::TextColored({0.2f,1.f,0.3f,1.f}, u8"●");
        else    ImGui::TextColored({1.f,0.3f,0.2f,1.f}, u8"●");
    };

    ImGui::SeparatorText(u8"Grafik Katmanı Durumu");
    ImGui::Columns(3, "gfx_status", false);

    // Sütun 1: SwiftShader
    ImGui::Text(u8"SwiftShader (Vulkan ICD)");
    ImGui::SameLine(); statusDot(swOk && swReg);
    if (swOk && swReg)
        ImGui::TextColored({0.5f,1.f,0.5f,1.f}, u8"Aktif — Vulkan 1.3");
    else if (swOk)
        ImGui::TextColored({1.f,0.8f,0.2f,1.f}, u8"Kurulu, kayıtsız");
    else
        ImGui::TextColored({1.f,0.4f,0.4f,1.f}, u8"Eksik");

    ImGui::NextColumn();

    // Sütun 2: DXVK
    ImGui::Text(u8"DXVK (D3D9/10/11)");
    ImGui::SameLine(); statusDot(dxvkOk);
    if (dxvkOk) ImGui::TextColored({0.5f,1.f,0.5f,1.f}, u8"Hazır");
    else        ImGui::TextColored({1.f,0.4f,0.4f,1.f}, u8"Eksik");

    ImGui::NextColumn();

    // Sütun 3: VKD3D
    ImGui::Text(u8"VKD3D-Proton (D3D12)");
    ImGui::SameLine(); statusDot(vkd3dOk);
    if (vkd3dOk) ImGui::TextColored({0.5f,1.f,0.5f,1.f}, u8"Hazır");
    else         ImGui::TextColored({1.f,0.6f,0.2f,1.f}, u8"Opsiyonel");

    ImGui::Columns(1);
    ImGui::Spacing();

    // ── Kurulum Butonları ────────────────────────────────────────────────
    ImGui::SeparatorText(u8"Kurulum");

    // İndirme ilerleme çubuğu için statik değişkenler
    static bool  s_downloading    = false;
    static float s_dlProgress     = 0.0f;
    static std::wstring s_dlMsg;
    static std::string  s_dlMsgU8;

    ProgressCallback cb = [](const std::wstring& msg, float pct) {
        s_dlMsg  = msg;
        s_dlMsgU8 = std::string(msg.begin(), msg.end());
        s_dlProgress = pct;
    };

    // SwiftShader kurulum paneli
    ImGui::BeginGroup();
    ImGui::Text(u8"SwiftShader");

    if (!swOk) {
        if (!s_downloading) {
            if (ImGui::Button(u8"  ↓ İndir  ##sw")) {
                s_downloading = true;
                s_dlProgress  = 0.f;
                std::thread([cb]() {
                    g_graphicsAPI.downloadSwiftShader(cb);
                    s_downloading = false;
                }).detach();
            }
        }
    } else {
        if (!swReg) {
            if (ImGui::Button(u8"▶ Vulkan ICD Kaydet##sw")) {
                if (!g_graphicsAPI.registerSwiftShader()) {
                    // hata
                }
            }
        } else {
            ImGui::TextColored({0.3f,0.9f,0.3f,1.f}, u8"✓ ICD Kayıtlı");
            ImGui::SameLine();
            if (ImGui::SmallButton(u8"Kaldır##swreg")) {
                g_graphicsAPI.unregisterSwiftShader();
            }
        }
    }
    ImGui::EndGroup();

    ImGui::SameLine(0, 20);

    // DXVK kurulum paneli
    ImGui::BeginGroup();
    ImGui::Text(u8"DXVK (D3D → Vulkan)");
    if (!dxvkOk) {
        if (!s_downloading) {
            if (ImGui::Button(u8"  ↓ İndir  ##dxvk")) {
                s_downloading = true;
                s_dlProgress  = 0.f;
                std::thread([cb]() {
                    g_graphicsAPI.downloadDXVK(cb);
                    s_downloading = false;
                }).detach();
            }
        }
    } else {
        ImGui::TextColored({0.3f,0.9f,0.3f,1.f}, u8"✓ Hazır");
    }
    ImGui::EndGroup();

    // İndirme ilerleme çubuğu
    if (s_downloading) {
        ImGui::Spacing();
        ImGui::ProgressBar(s_dlProgress, ImVec2(-1, 0),
                           s_dlMsgU8.empty() ? "..." : s_dlMsgU8.c_str());
    }

    ImGui::Spacing();

    // Vulkan ICD listesi
    ImGui::SeparatorText(u8"Sisteme Kayıtlı Vulkan ICD'leri");
    {
        auto icds = g_graphicsAPI.enumerateVulkanICDs();
        if (icds.empty()) {
            ImGui::TextDisabled(u8"Hiç Vulkan ICD bulunamadı.");
        } else {
            for (auto& icd : icds) {
                std::string p(icd.jsonPath.begin(), icd.jsonPath.end());
                std::string v(icd.apiVersion.begin(), icd.apiVersion.end());
                ImGui::BulletText("%s  [v%s]", p.c_str(), v.c_str());
            }
        }
    }

    ImGui::Spacing();

    // ── Oyun Başlatıcı ───────────────────────────────────────────────────
    ImGui::SeparatorText(u8"🎯 Oyun Başlatıcı");

    static char s_gameName[128] = "";
    static char s_gameExe[MAX_PATH] = "";
    static bool s_useDXVK   = true;
    static bool s_useVKD3D  = false;
    static bool s_forceDX11 = false;

    // Profil listesi
    auto& profiles = g_launcher->profiles();

    static int s_selectedProfile = -1;
    ImGui::BeginChild("ProfileList", ImVec2(220, 180), true);
    ImGui::Text(u8"Oyun Profilleri");
    ImGui::Separator();
    for (int i = 0; i < (int)profiles.size(); ++i) {
        std::string nm(profiles[i].name.begin(), profiles[i].name.end());
        if (ImGui::Selectable(nm.c_str(), s_selectedProfile == i)) {
            s_selectedProfile = i;
            auto& p = profiles[i];
            strncpy_s(s_gameName, std::string(p.name.begin(),p.name.end()).c_str(), 128);
            strncpy_s(s_gameExe,  std::string(p.exePath.begin(),p.exePath.end()).c_str(), MAX_PATH);
            s_useDXVK  = p.useDXVK;
            s_useVKD3D = p.useVKD3D;
            s_forceDX11= p.forceDX11;
        }
    }
    ImGui::EndChild();

    ImGui::SameLine();

    // Sağ panel: profil düzenleme
    ImGui::BeginGroup();

    ImGui::Text(u8"Oyun Adı:");
    ImGui::InputText("##gamename", s_gameName, 128);

    ImGui::Text(u8"Oyun .exe:");
    ImGui::InputText("##gameexe", s_gameExe, MAX_PATH);
    ImGui::SameLine();
    if (ImGui::Button(u8"Gözat...")) {
        auto path = GameLauncher::browseForExe();
        if (!path.empty()) {
            strncpy_s(s_gameExe,
                      std::string(path.begin(), path.end()).c_str(), MAX_PATH);
            if (s_gameName[0] == '\0') {
                auto fn = path.substr(path.find_last_of(L"/\\")+1);
                fn = fn.substr(0, fn.rfind('.'));
                strncpy_s(s_gameName,
                          std::string(fn.begin(),fn.end()).c_str(), 128);
            }
        }
    }

    ImGui::Checkbox(u8"DXVK (D3D9/10/11 → Vulkan)", &s_useDXVK);
    ImGui::SameLine();
    ImGui::TextDisabled(u8"(?)");
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip(u8"DirectX 9/10/11 oyunlarını SwiftShader üzerinden çalıştırır.");

    ImGui::Checkbox(u8"VKD3D-Proton (D3D12 → Vulkan)", &s_useVKD3D);
    ImGui::Checkbox(u8"-dx11 argümanı ekle", &s_forceDX11);

    ImGui::Spacing();

    if (ImGui::Button(u8"+ Profil Ekle")) {
        if (s_gameExe[0]) {
            GameProfile gp;
            gp.name     = std::wstring(s_gameName, s_gameName + strlen(s_gameName));
            gp.exePath  = std::wstring(s_gameExe,  s_gameExe  + strlen(s_gameExe));
            gp.useDXVK  = s_useDXVK;
            gp.useVKD3D = s_useVKD3D;
            gp.forceDX11= s_forceDX11;
            g_launcher->addProfile(gp);
            s_selectedProfile = (int)profiles.size() - 1;
        }
    }
    ImGui::SameLine();
    if (s_selectedProfile >= 0 && s_selectedProfile < (int)profiles.size()) {
        if (ImGui::Button(u8"🗑 Sil")) {
            g_launcher->removeProfile(s_selectedProfile);
            s_selectedProfile = -1;
        }
    }

    ImGui::EndGroup();

    ImGui::Spacing();
    ImGui::Separator();

    // Başlatma butonu
    bool canLaunch = (s_gameExe[0] != '\0') &&
                     !g_launcher->isRunning()  &&
                     (swOk && swReg);

    if (!swReg && !g_launcher->isRunning()) {
        ImGui::TextColored({1.f,0.6f,0.2f,1.f},
            u8"⚠ Oyun başlatmak için önce SwiftShader ICD kaydedin!");
    }

    if (!canLaunch) ImGui::BeginDisabled();
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.1f, 0.6f, 0.1f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.2f, 0.8f, 0.2f, 1.f));
    if (ImGui::Button(u8"▶  OMURG ile Başlat", ImVec2(-1, 40))) {
        GameProfile gp;
        gp.name     = std::wstring(s_gameName, s_gameName + strlen(s_gameName));
        gp.exePath  = std::wstring(s_gameExe,  s_gameExe  + strlen(s_gameExe));
        gp.useDXVK  = s_useDXVK;
        gp.useVKD3D = s_useVKD3D;
        gp.forceDX11= s_forceDX11;
        g_launcher->launch(gp);
    }
    ImGui::PopStyleColor(2);
    if (!canLaunch) ImGui::EndDisabled();

    // Durdur butonu
    if (g_launcher->isRunning()) {
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.7f, 0.1f, 0.1f, 1.f));
        if (ImGui::Button(u8"⏹ Durdur", ImVec2(-1, 40))) {
            g_launcher->forceStop();
        }
        ImGui::PopStyleColor();
    }

    // Durum bilgisi
    ImGui::Spacing();
    g_launcher->update();
    GameState gs = g_launcher->state();

    if (gs == GameState::Running) {
        auto& sess = g_launcher->session();
        double secs = sess.runTimeSec;
        int m = (int)(secs / 60); int s = (int)secs % 60;
        ImGui::TextColored({0.3f,1.f,0.3f,1.f},
            u8"● OMURG grafik katmanı ile oyun çalışıyor  —  Süre: %02d:%02d", m, s);

        // Animasyonlu ilerleme çubuğu
        float t = (float)ImGui::GetTime();
        ImGui::ProgressBar(-1.0f * t, ImVec2(-1,0), u8"Oyun aktif");

    } else if (gs == GameState::Exited) {
        auto msg = g_launcher->statusMsg();
        std::string msgU8(msg.begin(), msg.end());
        ImGui::TextColored({0.7f,0.7f,0.7f,1.f}, u8"● %s", msgU8.c_str());

    } else if (gs == GameState::Error) {
        auto msg = g_launcher->statusMsg();
        std::string msgU8(msg.begin(), msg.end());
        ImGui::TextColored({1.f,0.3f,0.3f,1.f}, u8"✖ %s", msgU8.c_str());
    }

    ImGui::Spacing();

    // ── Teknik Bilgi Kutusu ──────────────────────────────────────────────
    if (ImGui::CollapsingHeader(u8"Nasıl Çalışır?")) {
        ImGui::TextWrapped(
            u8"OMURG, oyunların grafik çağrılarını şu şekilde yönlendirir:\n\n"
            u8"  D3D9/10/11 → DXVK → Vulkan → SwiftShader → CPU Rasterizer\n"
            u8"  D3D12      → VKD3D-Proton → Vulkan → SwiftShader → CPU\n"
            u8"  Vulkan     → SwiftShader → CPU Rasterizer\n"
            u8"  OpenGL     → Mesa llvmpipe (opsiyonel)\n\n"
            u8"DXVK, d3d9.dll / d3d11.dll gibi sistem DLL'lerini oyun\n"
            u8"klasöründe geçici olarak değiştirir. Oyun kapandığında\n"
            u8"orijinal dosyalar geri yüklenir.\n\n"
            u8"SwiftShader, Google Chrome'un da kullandığı endüstriyel\n"
            u8"güçte bir CPU-tabanlı Vulkan uygulamasıdır."
        );
    }

    ImGui::EndTabItem();
}
// ─── TAB SONU ────────────────────────────────────────────────────────────────
