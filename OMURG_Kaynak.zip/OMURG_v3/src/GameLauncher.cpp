// =============================================================================
// OMURG - GameLauncher.cpp
// =============================================================================
#include "GameLauncher.h"
#include <shlobj.h>
#include <commdlg.h>
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "ole32.lib")

#include <chrono>
#include <filesystem>
namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Constructor / Destructor
// ---------------------------------------------------------------------------
GameLauncher::GameLauncher(GraphicsAPIManager& api) : m_api(api) {}

GameLauncher::~GameLauncher() {
    m_stopWatch = true;
    if (m_watchThread.joinable()) m_watchThread.join();
    if (m_session.hProcess && m_session.hProcess != INVALID_HANDLE_VALUE)
        CloseHandle(m_session.hProcess);
}

// ---------------------------------------------------------------------------
// launch
// ---------------------------------------------------------------------------
bool GameLauncher::launch(const GameProfile& profile) {
    if (m_state == GameState::Running) return false;

    m_state = GameState::Injecting;
    {
        std::lock_guard<std::mutex> lk(m_mtx);
        m_session        = {};
        m_session.profile = profile;
        m_session.state   = GameState::Injecting;
        m_session.statusMsg = L"Grafik katmanları enjekte ediliyor...";
    }

    std::wstring err;
    HANDLE hProc = m_api.launchGame(profile, err);
    if (!hProc) {
        std::lock_guard<std::mutex> lk(m_mtx);
        m_session.state      = GameState::Error;
        m_session.statusMsg  = L"Başlatma hatası: " + err;
        m_state = GameState::Error;
        return false;
    }

    {
        std::lock_guard<std::mutex> lk(m_mtx);
        m_session.hProcess    = hProc;
        m_session.state       = GameState::Running;
        m_session.statusMsg   = L"Oyun çalışıyor — OMURG grafik katmanı aktif";
        m_session.startTickMs = GetTickCount64();
    }
    m_state = GameState::Running;

    // İzleme thread'i başlat
    m_stopWatch = false;
    if (m_watchThread.joinable()) m_watchThread.join();
    m_watchThread = std::thread(&GameLauncher::watcherThread, this, hProc, profile);

    return true;
}

// ---------------------------------------------------------------------------
// watcherThread
// ---------------------------------------------------------------------------
void GameLauncher::watcherThread(HANDLE hProcess, GameProfile profile) {
    // Oyun kapanana kadar bekle
    WaitForSingleObject(hProcess, INFINITE);

    DWORD exitCode = 0;
    GetExitCodeProcess(hProcess, &exitCode);
    CloseHandle(hProcess);

    // Temizlik
    m_api.cleanupAfterGame(profile, nullptr);

    {
        std::lock_guard<std::mutex> lk(m_mtx);
        m_session.hProcess   = nullptr;
        m_session.exitCode   = exitCode;
        m_session.state      = GameState::Exited;
        m_session.runTimeSec = (GetTickCount64() - m_session.startTickMs) / 1000.0;
        m_session.statusMsg  = L"Oyun kapandı. (Çıkış kodu: " +
                                std::to_wstring(exitCode) + L")";
    }
    m_state = GameState::Exited;
}

// ---------------------------------------------------------------------------
// forceStop
// ---------------------------------------------------------------------------
void GameLauncher::forceStop() {
    HANDLE hProc = nullptr;
    {
        std::lock_guard<std::mutex> lk(m_mtx);
        hProc = m_session.hProcess;
    }
    if (hProc && hProc != INVALID_HANDLE_VALUE) {
        TerminateProcess(hProc, 0xDEAD);
    }
}

// ---------------------------------------------------------------------------
// state / statusMsg
// ---------------------------------------------------------------------------
GameState GameLauncher::state() const {
    return m_state;
}

std::wstring GameLauncher::statusMsg() const {
    std::lock_guard<std::mutex> lk(m_mtx);
    return m_session.statusMsg;
}

// ---------------------------------------------------------------------------
// update — ImGui frame'inde çağrılır
// ---------------------------------------------------------------------------
void GameLauncher::update() {
    if (m_state == GameState::Running) {
        std::lock_guard<std::mutex> lk(m_mtx);
        if (m_session.startTickMs > 0) {
            m_session.runTimeSec =
                (GetTickCount64() - m_session.startTickMs) / 1000.0;
        }
    }
}

// ---------------------------------------------------------------------------
// addProfile / removeProfile
// ---------------------------------------------------------------------------
void GameLauncher::addProfile(const GameProfile& p) {
    m_profiles.push_back(p);
    saveProfiles();
}

void GameLauncher::removeProfile(size_t idx) {
    if (idx < m_profiles.size()) {
        m_profiles.erase(m_profiles.begin() + idx);
        saveProfiles();
    }
}

void GameLauncher::saveProfiles() {
    m_api.saveProfiles(m_profiles);
}

void GameLauncher::loadProfiles() {
    m_api.loadProfiles(m_profiles);
}

// ---------------------------------------------------------------------------
// browseForExe — Windows dosya dialogu
// ---------------------------------------------------------------------------
std::wstring GameLauncher::browseForExe(HWND hwndOwner) {
    wchar_t buf[MAX_PATH] = {};
    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner   = hwndOwner;
    ofn.lpstrFilter = L"Yürütülebilir Dosyalar (*.exe)\0*.exe\0Tüm Dosyalar (*.*)\0*.*\0";
    ofn.lpstrFile   = buf;
    ofn.nMaxFile    = MAX_PATH;
    ofn.lpstrTitle  = L"Oyun Dosyasını Seç";
    ofn.Flags       = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;

    if (GetOpenFileNameW(&ofn)) return buf;
    return {};
}

// ---------------------------------------------------------------------------
// checkD3DDebugLayer
// ---------------------------------------------------------------------------
bool GameLauncher::checkD3DDebugLayer() {
    // D3D Debug layer DLL varlığını kontrol et
    HMODULE h = LoadLibraryW(L"d3d11_1sdklayers.dll");
    if (h) { FreeLibrary(h); return true; }
    return false;
}

// ---------------------------------------------------------------------------
// checkWDDMPresent
// ---------------------------------------------------------------------------
bool GameLauncher::checkWDDMPresent() {
    HKEY hk = nullptr;
    const wchar_t* key =
        L"SYSTEM\\CurrentControlSet\\Control\\Class\\"
        L"{4d36e968-e325-11ce-bfc1-08002be10318}";
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, key, 0, KEY_READ, &hk) != ERROR_SUCCESS)
        return false;
    RegCloseKey(hk);
    return true;
}
