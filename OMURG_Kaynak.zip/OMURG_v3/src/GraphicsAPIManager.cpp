// =============================================================================
// OMURG - GraphicsAPIManager.cpp
// SwiftShader Vulkan ICD + DXVK + VKD3D-Proton + D3D Registry entegrasyonu
// =============================================================================
#include "GraphicsAPI.h"

#include <windows.h>
#include <wininet.h>
#include <shlwapi.h>
#include <shellapi.h>
#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "shell32.lib")

#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <filesystem>
#include <algorithm>
#include <cstdio>

  // ---------------------------------------------------------------------------
  // wstr_to_utf8 — wstring → UTF-8 string (MSVC C4244 olmadan)
  // ---------------------------------------------------------------------------
  static std::string wstr_to_utf8(const std::wstring& w) {
      if (w.empty()) return {};
      int len = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr);
      std::string s(len > 1 ? len - 1 : 0, '\0');
      if (len > 1) WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, s.data(), len, nullptr, nullptr);
      return s;
  }
  
namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Sabitler
// ---------------------------------------------------------------------------
static const wchar_t* VULKAN_ICD_REGKEY =
    L"SOFTWARE\\Khronos\\Vulkan\\Drivers";

static const wchar_t* DXGI_SW_ADAPTER_REGKEY =
    L"SOFTWARE\\Microsoft\\DirectX\\UserModeDrivers";

// SwiftShader GitHub Releases URL'si (en son stabil)
static const wchar_t* SWIFTSHADER_URL =
    L"https://github.com/nicowillis/swiftshader-builds/releases/latest/download/swiftshader-windows-x64.zip";

// DXVK GitHub Releases URL'si
static const wchar_t* DXVK_URL =
    L"https://github.com/doitsujin/dxvk/releases/latest/download/dxvk-2.4.tar.gz";

// VKD3D-Proton GitHub Releases
static const wchar_t* VKD3D_URL =
    L"https://github.com/HansKristian-Work/vkd3d-proton/releases/latest/download/vkd3d-proton-2.13.tar.zst";

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Yardımcı: Dizin oluştur (recursive)
// ---------------------------------------------------------------------------
static bool mkdirs(const std::wstring& path) {
    std::error_code ec;
    fs::create_directories(path, ec);
    return !ec;
}

// ---------------------------------------------------------------------------
// Constructor / Destructor
// ---------------------------------------------------------------------------
GraphicsAPIManager::GraphicsAPIManager() = default;
GraphicsAPIManager::~GraphicsAPIManager() = default;

// ---------------------------------------------------------------------------
// initialize
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::initialize(const std::wstring& baseDir) {
    m_baseDir  = baseDir;
    m_swDir    = baseDir + L"\\deps\\swiftshader";
    m_dxvkDir  = baseDir + L"\\deps\\dxvk\\x64";
    m_vkd3dDir = baseDir + L"\\deps\\vkd3d\\x64";

    mkdirs(m_swDir);
    mkdirs(m_dxvkDir);
    mkdirs(m_vkd3dDir);

    scanAvailableDeps();
    return true;
}

// ---------------------------------------------------------------------------
// scanAvailableDeps — Mevcut DLL'leri tara
// ---------------------------------------------------------------------------
void GraphicsAPIManager::scanAvailableDeps() {
    // SwiftShader
    std::wstring swDll = m_swDir + L"\\vk_swiftshader.dll";
    m_swRegistered = isSwiftShaderRegistered();

    // DXVK
    m_dxvk = {};
    auto checkDXVK = [&](const wchar_t* name, std::wstring& out) {
        std::wstring p = m_dxvkDir + L"\\" + name;
        if (fs::exists(p)) { out = p; return true; }
        return false;
    };
    bool d9  = checkDXVK(L"d3d9.dll",      m_dxvk.d3d9_dll);
    bool d10 = checkDXVK(L"d3d10core.dll", m_dxvk.d3d10core_dll);
    bool d11 = checkDXVK(L"d3d11.dll",     m_dxvk.d3d11_dll);
    bool dgi = checkDXVK(L"dxgi.dll",      m_dxvk.dxgi_dll);
    m_dxvk.available = d9 && d10 && d11 && dgi;

    // VKD3D
    m_vkd3d = {};
    std::wstring vp = m_vkd3dDir + L"\\d3d12.dll";
    if (fs::exists(vp)) {
        m_vkd3d.d3d12_dll = vp;
        m_vkd3d.available = true;
    }
    std::wstring vsp = m_vkd3dDir + L"\\d3d12SDKLayers.dll";
    if (fs::exists(vsp)) m_vkd3d.d3d12_sdklayers_dll = vsp;
}

// ---------------------------------------------------------------------------
// icdJsonPath
// ---------------------------------------------------------------------------
std::wstring GraphicsAPIManager::icdJsonPath() const {
    return m_swDir + L"\\vk_swiftshader_icd.json";
}

// ---------------------------------------------------------------------------
// writeICDJson — SwiftShader ICD JSON dosyasını yaz
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::writeICDJson(const std::wstring& dllPath) const {
    // Vulkan Loader ICD formatı
    std::string dllUtf8 = wstr_to_utf8(dllPath);
    // Ters slash → ileri slash
    std::replace(dllUtf8.begin(), dllUtf8.end(), '\\', '/');

    std::string json =
        "{\n"
        "    \"file_format_version\": \"1.0.0\",\n"
        "    \"ICD\": {\n"
        "        \"library_path\": \"" + dllUtf8 + "\",\n"
        "        \"api_version\": \"1.3.0\"\n"
        "    }\n"
        "}\n";

    std::ofstream f(icdJsonPath());
    if (!f.is_open()) return false;
    f << json;
    return true;
}

// ---------------------------------------------------------------------------
// regSetDword / regSetString
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::regSetDword(HKEY root, const wchar_t* key,
                                      const wchar_t* name, DWORD value) {
    HKEY hk = nullptr;
    if (RegCreateKeyExW(root, key, 0, nullptr, REG_OPTION_NON_VOLATILE,
                        KEY_SET_VALUE, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_DWORD,
                              reinterpret_cast<const BYTE*>(&value),
                              sizeof(DWORD)) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

bool GraphicsAPIManager::regSetString(HKEY root, const wchar_t* key,
                                       const wchar_t* name,
                                       const std::wstring& val) {
    HKEY hk = nullptr;
    if (RegCreateKeyExW(root, key, 0, nullptr, REG_OPTION_NON_VOLATILE,
                        KEY_SET_VALUE, nullptr, &hk, nullptr) != ERROR_SUCCESS)
        return false;
    bool ok = RegSetValueExW(hk, name, 0, REG_SZ,
                              reinterpret_cast<const BYTE*>(val.c_str()),
                              static_cast<DWORD>((val.size()+1)*sizeof(wchar_t))) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return ok;
}

// ---------------------------------------------------------------------------
// registerSwiftShader
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::registerSwiftShader() {
    std::wstring dllPath = m_swDir + L"\\vk_swiftshader.dll";
    if (!fs::exists(dllPath)) {
        m_lastError = L"vk_swiftshader.dll bulunamadı: " + dllPath;
        return false;
    }

    // JSON yaz
    if (!writeICDJson(dllPath)) {
        m_lastError = L"ICD JSON dosyası yazılamadı.";
        return false;
    }

    // Registry'ye kaydet: HKLM\SOFTWARE\Khronos\Vulkan\Drivers
    // Değer adı = JSON tam yolu, değer tipi = DWORD 0
    std::wstring jsonPath = icdJsonPath();
    if (!regSetDword(HKEY_LOCAL_MACHINE, VULKAN_ICD_REGKEY,
                     jsonPath.c_str(), 0)) {
        // 32-bit registry'ye de kaydet
        m_lastError = L"Vulkan ICD registry'ye yazılamadı "
                      L"(Yönetici olarak çalıştır gerekli).";
        return false;
    }

    // WOW6432Node için de kaydet (32-bit uygulamalar)
    regSetDword(HKEY_LOCAL_MACHINE,
                L"SOFTWARE\\WOW6432Node\\Khronos\\Vulkan\\Drivers",
                jsonPath.c_str(), 0);

    m_swRegistered = true;
    return true;
}

// ---------------------------------------------------------------------------
// unregisterSwiftShader
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::unregisterSwiftShader() {
    std::wstring jsonPath = icdJsonPath();
    HKEY hk = nullptr;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, VULKAN_ICD_REGKEY,
                      0, KEY_SET_VALUE, &hk) == ERROR_SUCCESS) {
        RegDeleteValueW(hk, jsonPath.c_str());
        RegCloseKey(hk);
    }
    // WOW64
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE,
                      L"SOFTWARE\\WOW6432Node\\Khronos\\Vulkan\\Drivers",
                      0, KEY_SET_VALUE, &hk) == ERROR_SUCCESS) {
        RegDeleteValueW(hk, jsonPath.c_str());
        RegCloseKey(hk);
    }
    m_swRegistered = false;
    return true;
}

// ---------------------------------------------------------------------------
// isSwiftShaderRegistered
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::isSwiftShaderRegistered() const {
    std::wstring jsonPath = icdJsonPath();
    HKEY hk = nullptr;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, VULKAN_ICD_REGKEY,
                      0, KEY_QUERY_VALUE, &hk) != ERROR_SUCCESS)
        return false;
    DWORD type = 0, data = 0, dataSize = sizeof(data);
    bool found = RegQueryValueExW(hk, jsonPath.c_str(), nullptr,
                                   &type, reinterpret_cast<BYTE*>(&data),
                                   &dataSize) == ERROR_SUCCESS;
    RegCloseKey(hk);
    return found;
}

// ---------------------------------------------------------------------------
// isSwiftShaderAvailable
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::isSwiftShaderAvailable() const {
    return fs::exists(m_swDir + L"\\vk_swiftshader.dll");
}

// ---------------------------------------------------------------------------
// enumerateVulkanICDs
// ---------------------------------------------------------------------------
std::vector<VulkanICDEntry> GraphicsAPIManager::enumerateVulkanICDs() const {
    std::vector<VulkanICDEntry> result;
    HKEY hk = nullptr;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, VULKAN_ICD_REGKEY,
                      0, KEY_READ, &hk) != ERROR_SUCCESS)
        return result;

    wchar_t name[1024];
    DWORD nameLen = 1024, type = 0, data = 0, dataSize = sizeof(data);
    DWORD idx = 0;

    while (RegEnumValueW(hk, idx++, name, &nameLen, nullptr,
                         &type, reinterpret_cast<BYTE*>(&data),
                         &dataSize) == ERROR_SUCCESS) {
        VulkanICDEntry e;
        e.jsonPath  = name;
        e.active    = (data == 0);

        // JSON'u oku → DLL yolunu bul
        std::ifstream jf(name);
        if (jf.is_open()) {
            std::string line;
            while (std::getline(jf, line)) {
                auto pos = line.find("\"library_path\"");
                if (pos != std::string::npos) {
                    auto q1 = line.find('"', pos + 14);
                    auto q2 = line.find('"', q1 + 1);
                    if (q1 != std::string::npos && q2 != std::string::npos) {
                        std::string dll = line.substr(q1+1, q2-q1-1);
                        e.dllPath = std::wstring(dll.begin(), dll.end());
                    }
                }
                auto av = line.find("\"api_version\"");
                if (av != std::string::npos) {
                    auto q1 = line.find('"', av + 13);
                    auto q2 = line.find('"', q1 + 1);
                    if (q1 != std::string::npos && q2 != std::string::npos) {
                        std::string ver = line.substr(q1+1, q2-q1-1);
                        e.apiVersion = std::wstring(ver.begin(), ver.end());
                    }
                }
            }
        }

        result.push_back(e);
        nameLen = 1024;
        dataSize = sizeof(data);
    }

    RegCloseKey(hk);
    return result;
}

// ---------------------------------------------------------------------------
// isAnyVulkanPresent
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::isAnyVulkanPresent() const {
    HKEY hk = nullptr;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, VULKAN_ICD_REGKEY,
                      0, KEY_READ, &hk) != ERROR_SUCCESS)
        return false;
    DWORD count = 0;
    RegQueryInfoKeyW(hk, nullptr, nullptr, nullptr, nullptr, nullptr,
                     nullptr, &count, nullptr, nullptr, nullptr, nullptr);
    RegCloseKey(hk);
    return count > 0;
}

// ---------------------------------------------------------------------------
// isDXVKAvailable
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::isDXVKAvailable() const {
    return m_dxvk.available;
}

// ---------------------------------------------------------------------------
// injectDXVK — DLL'leri oyun dizinine kopyala
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::injectDXVK(const std::wstring& gameDir) {
    if (!m_dxvk.available) {
        m_lastError = L"DXVK DLL'leri mevcut değil. Önce indirin.";
        return false;
    }

    auto copyDLL = [&](const std::wstring& src, const wchar_t* dstName) -> bool {
        if (src.empty()) return true;
        std::wstring dst = gameDir + L"\\" + dstName;
        // Orjinali yedekle
        std::wstring bak = dst + L".omurg_bak";
        if (fs::exists(dst) && !fs::exists(bak)) {
            std::error_code ec;
            fs::rename(dst, bak, ec);
        }
        std::error_code ec;
        fs::copy_file(src, dst, fs::copy_options::overwrite_existing, ec);
        return !ec;
    };

    bool ok = true;
    ok &= copyDLL(m_dxvk.d3d9_dll,      L"d3d9.dll");
    ok &= copyDLL(m_dxvk.d3d10core_dll, L"d3d10core.dll");
    ok &= copyDLL(m_dxvk.d3d11_dll,     L"d3d11.dll");
    ok &= copyDLL(m_dxvk.dxgi_dll,      L"dxgi.dll");

    // DXVK konfigürasyon dosyası: çözünürlük sınırını kaldır
    std::wstring cfgPath = gameDir + L"\\dxvk.conf";
    if (!fs::exists(cfgPath)) {
        std::ofstream cfg(cfgPath);
        cfg << "# OMURG DXVK Configuration\n"
            << "dxvk.enableAsync = True\n"
            << "dxvk.numCompilerThreads = 0\n"
            << "dxvk.maxFrameLatency = 1\n"
            << "dxvk.useRawSsbo = True\n";
    }

    if (!ok) m_lastError = L"Bazı DXVK DLL'leri kopyalanamadı.";
    return ok;
}

// ---------------------------------------------------------------------------
// removeDXVK — DLL'leri oyun dizininden kaldır
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::removeDXVK(const std::wstring& gameDir) {
    const wchar_t* dlls[] = {
        L"d3d9.dll", L"d3d10core.dll", L"d3d11.dll", L"dxgi.dll"
    };
    for (auto* name : dlls) {
        std::wstring path = gameDir + L"\\" + name;
        std::wstring bak  = path + L".omurg_bak";
        std::error_code ec;
        if (fs::exists(bak)) {
            fs::remove(path, ec);
            fs::rename(bak, path, ec);
        } else {
            // Yedek yok — DXVK DLL'yi sil (sistem DLL değil, local)
            fs::remove(path, ec);
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
// isDXVKInjected
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::isDXVKInjected(const std::wstring& gameDir) const {
    // d3d11.dll boyutunu kontrol et — sistem DLL'sinden farklı olacak
    std::wstring path = gameDir + L"\\d3d11.dll";
    if (!fs::exists(path)) return false;
    // DXVK d3d11.dll ~3MB, sistem d3d11.dll ~4.5MB
    auto sz = fs::file_size(path);
    return sz < 4'000'000;
}

// ---------------------------------------------------------------------------
// injectVKD3D
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::injectVKD3D(const std::wstring& gameDir) {
    if (!m_vkd3d.available) {
        m_lastError = L"VKD3D-Proton DLL'leri mevcut değil.";
        return false;
    }
    std::wstring dst = gameDir + L"\\d3d12.dll";
    std::wstring bak = dst + L".omurg_bak";
    std::error_code ec;
    if (fs::exists(dst) && !fs::exists(bak)) fs::rename(dst, bak, ec);
    fs::copy_file(m_vkd3d.d3d12_dll, dst, fs::copy_options::overwrite_existing, ec);
    return !ec;
}

bool GraphicsAPIManager::removeVKD3D(const std::wstring& gameDir) {
    std::wstring path = gameDir + L"\\d3d12.dll";
    std::wstring bak  = path + L".omurg_bak";
    std::error_code ec;
    if (fs::exists(bak)) {
        fs::remove(path, ec);
        fs::rename(bak, path, ec);
    } else {
        fs::remove(path, ec);
    }
    return true;
}

bool GraphicsAPIManager::isVKD3DInjected(const std::wstring& gameDir) const {
    return fs::exists(gameDir + L"\\d3d12.dll");
}

bool GraphicsAPIManager::isVKD3DAvailable() const {
    return m_vkd3d.available;
}

// ---------------------------------------------------------------------------
// writeD3DRegistryEntries
// D3D özellik düzeylerini Aygıt Yöneticisi'ne bildir.
// GPU görünürlüğü için kritik kayıt defteri girdileri.
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::writeD3DRegistryEntries(
    const std::wstring& deviceInstanceId,
    const std::wstring& modelName,
    uint32_t            vramMB,
    const std::string&  featureLevel)
{
    // Display class key
    const wchar_t* classBase =
        L"SYSTEM\\CurrentControlSet\\Control\\Class\\"
        L"{4d36e968-e325-11ce-bfc1-08002be10318}";

    // Cihaz örneği için doğru index'i bul
    HKEY hClass = nullptr;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, classBase,
                      0, KEY_READ | KEY_WRITE, &hClass) != ERROR_SUCCESS)
        return false;

    wchar_t subKey[64];
    DWORD idx = 0, len = 64;
    bool found = false;
    std::wstring targetSubKey;

    while (RegEnumKeyExW(hClass, idx++, subKey, &len,
                         nullptr, nullptr, nullptr, nullptr) == ERROR_SUCCESS) {
        wchar_t instId[512] = {};
        DWORD instLen = sizeof(instId);
        HKEY hSub = nullptr;
        if (RegOpenKeyExW(hClass, subKey, 0, KEY_READ, &hSub) == ERROR_SUCCESS) {
            if (RegQueryValueExW(hSub, L"DeviceInstanceId", nullptr, nullptr,
                                 reinterpret_cast<BYTE*>(instId),
                                 &instLen) == ERROR_SUCCESS) {
                if (deviceInstanceId.find(instId) != std::wstring::npos ||
                    std::wstring(instId).find(deviceInstanceId) != std::wstring::npos) {
                    targetSubKey = subKey;
                    found = true;
                }
            }
            RegCloseKey(hSub);
        }
        len = 64;
        if (found) break;
    }
    RegCloseKey(hClass);

    // Bulunamadı — ilk boş slota yaz
    if (!found) targetSubKey = L"0000";

    std::wstring fullKey = std::wstring(classBase) + L"\\" + targetSubKey;

    // ── DirectX Feature Level ────────────────────────────────────────────
    std::wstring fl(featureLevel.begin(), featureLevel.end());
    regSetString(HKEY_LOCAL_MACHINE, fullKey.c_str(),
                 L"HardwareInformation.ChipType", modelName + L" Rasterizer");
    regSetString(HKEY_LOCAL_MACHINE, fullKey.c_str(),
                 L"HardwareInformation.DacType", L"OMURG SW DAC");

    wchar_t vramBuf[64];
    _snwprintf_s(vramBuf, 64, L"%u MB", vramMB);
    regSetString(HKEY_LOCAL_MACHINE, fullKey.c_str(),
                 L"HardwareInformation.MemorySize", vramBuf);
    regSetString(HKEY_LOCAL_MACHINE, fullKey.c_str(),
                 L"HardwareInformation.AdapterString", modelName);
    regSetString(HKEY_LOCAL_MACHINE, fullKey.c_str(),
                 L"HardwareInformation.BiosString", L"OMURG VBIOS v3.0");

    // D3D özellik düzeyi bildirimi
    regSetString(HKEY_LOCAL_MACHINE, fullKey.c_str(), L"FeatureLevel", fl);

    // DirectX 11 DDI bildirimi
    regSetDword(HKEY_LOCAL_MACHINE, fullKey.c_str(), L"D3D11_DDI", 1);
    regSetDword(HKEY_LOCAL_MACHINE, fullKey.c_str(), L"D3D12_DDI", 1);

    // VRAM (bytes cinsinden)
    DWORD vramBytes = vramMB * 1024 * 1024;
    regSetDword(HKEY_LOCAL_MACHINE, fullKey.c_str(),
                L"HardwareInformation.qwMemorySize", vramBytes);

    // Vendor ID: OMURG için özel (PCI benzeri)
    regSetDword(HKEY_LOCAL_MACHINE, fullKey.c_str(), L"VendorId",  0x4F4D); // "OM"
    regSetDword(HKEY_LOCAL_MACHINE, fullKey.c_str(), L"DeviceId",  0x5552); // "UR"
    regSetDword(HKEY_LOCAL_MACHINE, fullKey.c_str(), L"SubVendorId", 0x4743); // "GV"

    // ── DXGI Adapter Description ─────────────────────────────────────────
    // DXGI bu anahtarı okur ve IDXGIAdapter::GetDesc()'e yansıtır
    const wchar_t* dxgiKey =
        L"SOFTWARE\\Microsoft\\DirectX";
    regSetString(HKEY_LOCAL_MACHINE, dxgiKey, L"AdapterString", modelName);
    regSetDword(HKEY_LOCAL_MACHINE,  dxgiKey, L"DedicatedVideoMemory", vramBytes);
    regSetDword(HKEY_LOCAL_MACHINE,  dxgiKey, L"DedicatedSystemMemory", 0);
    regSetDword(HKEY_LOCAL_MACHINE,  dxgiKey, L"SharedSystemMemory", vramBytes);

    return true;
}

// ---------------------------------------------------------------------------
// removeD3DRegistryEntries
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::removeD3DRegistryEntries(
    const std::wstring& /*deviceInstanceId*/)
{
    // DirectX anahtarını temizle
    HKEY hk = nullptr;
    const wchar_t* dxgiKey = L"SOFTWARE\\Microsoft\\DirectX";
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, dxgiKey, 0,
                      KEY_SET_VALUE, &hk) == ERROR_SUCCESS) {
        RegDeleteValueW(hk, L"AdapterString");
        RegDeleteValueW(hk, L"DedicatedVideoMemory");
        RegDeleteValueW(hk, L"SharedSystemMemory");
        RegCloseKey(hk);
    }
    return true;
}

// ---------------------------------------------------------------------------
// registerDXGISoftwareAdapter
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::registerDXGISoftwareAdapter(
    const std::wstring& adapterDllPath)
{
    return regSetString(HKEY_LOCAL_MACHINE, DXGI_SW_ADAPTER_REGKEY,
                        L"OMURG_SWAdapter", adapterDllPath);
}

bool GraphicsAPIManager::unregisterDXGISoftwareAdapter() {
    HKEY hk = nullptr;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, DXGI_SW_ADAPTER_REGKEY,
                      0, KEY_SET_VALUE, &hk) != ERROR_SUCCESS)
        return false;
    RegDeleteValueW(hk, L"OMURG_SWAdapter");
    RegCloseKey(hk);
    return true;
}

// ---------------------------------------------------------------------------
// launchGame
// ---------------------------------------------------------------------------
HANDLE GraphicsAPIManager::launchGame(const GameProfile& profile,
                                       std::wstring&      outError) {
    if (profile.exePath.empty()) {
        outError = L"Oyun yolu boş.";
        return nullptr;
    }

    // Çalışma dizinini belirle
    std::wstring workDir = profile.workDir;
    if (workDir.empty()) {
        // exe'nin bulunduğu klasör
        size_t pos = profile.exePath.find_last_of(L"\\/");
        if (pos != std::wstring::npos)
            workDir = profile.exePath.substr(0, pos);
    }

    // DXVK enjeksiyonu
    if (profile.useDXVK && isDXVKAvailable()) {
        if (!injectDXVK(workDir)) {
            outError = L"DXVK enjeksiyonu başarısız: " + m_lastError;
            return nullptr;
        }
    }

    // VKD3D enjeksiyonu
    if (profile.useVKD3D && isVKD3DAvailable()) {
        if (!injectVKD3D(workDir)) {
            outError = L"VKD3D enjeksiyonu başarısız: " + m_lastError;
            return nullptr;
        }
    }

    // Ortam değişkenleri
    // DXVK'nın OMURG'un SwiftShader Vulkan ICD'sini kullanmasını zorla
    std::wstring dxvkHud = L"fps,devinfo,memory";
    SetEnvironmentVariableW(L"DXVK_HUD",            dxvkHud.c_str());
    SetEnvironmentVariableW(L"DXVK_LOG_LEVEL",       L"warn");
    SetEnvironmentVariableW(L"VK_ICD_FILENAMES",
                             icdJsonPath().c_str());
    SetEnvironmentVariableW(L"VKD3D_CONFIG",
                             L"force_bindless_textures,upload_hvv_deferred");

    // Argümanlar
    std::wstring cmdLine = L"\"" + profile.exePath + L"\"";
    if (profile.forceDX11) cmdLine += L" -dx11";

    STARTUPINFOW si = {};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi = {};

    BOOL ok = CreateProcessW(
        profile.exePath.c_str(),
        const_cast<wchar_t*>(cmdLine.c_str()),
        nullptr, nullptr, FALSE,
        0, nullptr,
        workDir.c_str(),
        &si, &pi);

    if (!ok) {
        DWORD err = GetLastError();
        wchar_t buf[256] = {};
        FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM, nullptr, err,
                       MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                       buf, 256, nullptr);
        outError = buf;
        return nullptr;
    }

    CloseHandle(pi.hThread);
    return pi.hProcess;
}

// ---------------------------------------------------------------------------
// cleanupAfterGame
// ---------------------------------------------------------------------------
void GraphicsAPIManager::cleanupAfterGame(const GameProfile& profile,
                                           HANDLE hProcess) {
    if (hProcess && hProcess != INVALID_HANDLE_VALUE) {
        WaitForSingleObject(hProcess, 5000);
        CloseHandle(hProcess);
    }

    std::wstring workDir = profile.workDir;
    if (workDir.empty()) {
        size_t pos = profile.exePath.find_last_of(L"\\/");
        if (pos != std::wstring::npos)
            workDir = profile.exePath.substr(0, pos);
    }

    if (profile.useDXVK)  removeDXVK(workDir);
    if (profile.useVKD3D) removeVKD3D(workDir);
}

// ---------------------------------------------------------------------------
// downloadFile — WinINet ile URL'den dosya indir
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::downloadFile(const std::wstring& url,
                                       const std::wstring& dest,
                                       ProgressCallback    cb) {
    HINTERNET hInet = InternetOpenW(L"OMURG/3.0 WinINet",
                                     INTERNET_OPEN_TYPE_PRECONFIG,
                                     nullptr, nullptr, 0);
    if (!hInet) { m_lastError = L"WinINet açılamadı."; return false; }

    HINTERNET hUrl = InternetOpenUrlW(hInet, url.c_str(), nullptr, 0,
                                       INTERNET_FLAG_RELOAD |
                                       INTERNET_FLAG_SECURE |
                                       INTERNET_FLAG_NO_CACHE_WRITE,
                                       0);
    if (!hUrl) {
        InternetCloseHandle(hInet);
        m_lastError = L"URL açılamadı: " + url;
        return false;
    }

    // Content-Length
    wchar_t lenBuf[32] = {};
    DWORD bufLen = sizeof(lenBuf), idx = 0;
    ULONGLONG totalBytes = 0;
    if (HttpQueryInfoW(hUrl, HTTP_QUERY_CONTENT_LENGTH,
                       lenBuf, &bufLen, &idx))
        totalBytes = _wcstoui64(lenBuf, nullptr, 10);

    std::ofstream outFile(dest, std::ios::binary);
    if (!outFile.is_open()) {
        InternetCloseHandle(hUrl);
        InternetCloseHandle(hInet);
        m_lastError = L"Dosya yazılamadı: " + dest;
        return false;
    }

    std::vector<char> buf(65536);
    ULONGLONG downloaded = 0;
    DWORD read = 0;
    bool ok = true;

    while (InternetReadFile(hUrl, buf.data(), (DWORD)buf.size(), &read)
           && read > 0) {
        outFile.write(buf.data(), read);
        downloaded += read;
        if (cb && totalBytes > 0) {
            float pct = static_cast<float>(downloaded) / totalBytes;
            wchar_t msg[128];
            _snwprintf_s(msg, 128, L"İndiriliyor... %.1f / %.1f MB",
                         downloaded / 1048576.0, totalBytes / 1048576.0);
            cb(msg, pct);
        }
    }

    outFile.close();
    InternetCloseHandle(hUrl);
    InternetCloseHandle(hInet);
    return ok;
}

// ---------------------------------------------------------------------------
// extractZip — PowerShell ile ZIP aç (Windows yerleşik)
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::extractZip(const std::wstring& zipPath,
                                     const std::wstring& destDir,
                                     ProgressCallback    cb) {
    if (cb) cb(L"ZIP açılıyor...", 0.9f);

    mkdirs(destDir);

    // PowerShell Expand-Archive kullan
    std::wstring cmd =
        L"powershell.exe -NoProfile -Command \""
        L"Expand-Archive -Path '" + zipPath + L"'"
        L" -DestinationPath '" + destDir + L"'"
        L" -Force\"";

    STARTUPINFOW si = {}; si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi = {};

    if (!CreateProcessW(nullptr,
                        const_cast<wchar_t*>(cmd.c_str()),
                        nullptr, nullptr, FALSE,
                        CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        m_lastError = L"PowerShell başlatılamadı.";
        return false;
    }

    WaitForSingleObject(pi.hProcess, 60000);
    DWORD exitCode = 0;
    GetExitCodeProcess(pi.hProcess, &exitCode);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    if (cb) cb(L"Tamamlandı.", 1.0f);
    return exitCode == 0;
}

// ---------------------------------------------------------------------------
// downloadSwiftShader
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::downloadSwiftShader(ProgressCallback cb) {
    if (cb) cb(L"SwiftShader indiriliyor...", 0.0f);

    std::wstring zipDest = m_swDir + L"\\swiftshader.zip";

    if (!downloadFile(SWIFTSHADER_URL, zipDest, cb)) return false;
    if (!extractZip(zipDest, m_swDir, cb)) return false;

    // ZIP içi yapıyı düzelt (genellikle bir alt klasör vardır)
    // vk_swiftshader.dll ve libvulkan.so.1.0.0 gibi dosyaları bul
    for (auto& entry : fs::recursive_directory_iterator(m_swDir)) {
        if (entry.path().filename() == "vk_swiftshader.dll") {
            if (entry.path().parent_path() != fs::path(m_swDir)) {
                std::error_code ec;
                fs::copy_file(entry.path(),
                              fs::path(m_swDir) / "vk_swiftshader.dll",
                              fs::copy_options::overwrite_existing, ec);
            }
            break;
        }
    }

    // Geçici ZIP'i sil
    std::error_code ec;
    fs::remove(zipDest, ec);

    scanAvailableDeps();
    if (cb) cb(L"SwiftShader hazır!", 1.0f);
    return isSwiftShaderAvailable();
}

// ---------------------------------------------------------------------------
// downloadDXVK
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::downloadDXVK(ProgressCallback cb) {
    if (cb) cb(L"DXVK indiriliyor...", 0.0f);

    // DXVK en son release'i GitHub API'den sorgula
    // Önce basit bir URL dene
    std::wstring zipDest = m_dxvkDir + L"\\..\\dxvk.tar.gz";

    if (!downloadFile(DXVK_URL, zipDest, cb)) return false;

    // tar.gz için PowerShell 7+ veya 7-zip gerekir
    // PowerShell 5.x Expand-Archive sadece .zip destekler
    // Alternatif: tar komutunu kullan (Windows 10 1803+ yerleşik)
    std::wstring dxvkBase = m_dxvkDir + L"\\..";
    std::wstring cmd =
        L"cmd.exe /c tar -xzf \"" + zipDest + L"\" -C \"" + dxvkBase + L"\"";

    STARTUPINFOW si = {}; si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi = {};

    if (cb) cb(L"DXVK dosyaları çıkartılıyor...", 0.85f);

    CreateProcessW(nullptr, const_cast<wchar_t*>(cmd.c_str()),
                   nullptr, nullptr, FALSE, CREATE_NO_WINDOW,
                   nullptr, nullptr, &si, &pi);
    WaitForSingleObject(pi.hProcess, 120000);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    // Çıkartılan klasörden x64 DLL'leri m_dxvkDir'e taşı
    for (auto& entry : fs::recursive_directory_iterator(m_dxvkDir + L"\\..")) {
        auto fn = entry.path().filename().wstring();
        if (fn == L"d3d11.dll" || fn == L"d3d9.dll" ||
            fn == L"dxgi.dll"  || fn == L"d3d10core.dll") {
            // x64 klasöründekini al
            if (entry.path().parent_path().filename() == L"x64") {
                std::error_code ec;
                fs::copy_file(entry.path(),
                              fs::path(m_dxvkDir) / fn,
                              fs::copy_options::overwrite_existing, ec);
            }
        }
    }

    std::error_code ec;
    fs::remove(zipDest, ec);

    scanAvailableDeps();
    if (cb) cb(L"DXVK hazır!", 1.0f);
    return isDXVKAvailable();
}

// ---------------------------------------------------------------------------
// downloadVKD3D
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::downloadVKD3D(ProgressCallback cb) {
    if (cb) cb(L"VKD3D-Proton indiriliyor...", 0.0f);
    // VKD3D indirme mantığı DXVK ile benzer
    // (tar.zst formatı — daha karmaşık)
    // Şimdilik kullanıcıyı yönlendir
    if (cb) cb(L"VKD3D-Proton: Manuel kurulum gerekli (bkz. README)", 1.0f);
    return false;
}

// ---------------------------------------------------------------------------
// saveProfiles / loadProfiles — JSON tabanlı
// ---------------------------------------------------------------------------
bool GraphicsAPIManager::saveProfiles(const std::vector<GameProfile>& profiles) const {
    std::wstring path = m_baseDir + L"\\game_profiles.json";
    std::ofstream f(path);
    if (!f.is_open()) return false;

    f << "[\n";
    for (size_t i = 0; i < profiles.size(); ++i) {
        const auto& p = profiles[i];
        // Wide → UTF-8 basit dönüşüm
        auto w2s = [](const std::wstring& w) { return wstr_to_utf8(w); };
        f << "  {\n"
          << "    \"name\":\"" << w2s(p.name) << "\",\n"
          << "    \"exe\":\""  << w2s(p.exePath) << "\",\n"
          << "    \"workDir\":\"" << w2s(p.workDir) << "\",\n"
          << "    \"dxvk\":"  << (p.useDXVK   ? "true" : "false") << ",\n"
          << "    \"vkd3d\":" << (p.useVKD3D  ? "true" : "false") << ",\n"
          << "    \"dx11\":"  << (p.forceDX11 ? "true" : "false") << "\n"
          << "  }" << (i+1 < profiles.size() ? "," : "") << "\n";
    }
    f << "]\n";
    return true;
}

bool GraphicsAPIManager::loadProfiles(std::vector<GameProfile>& profiles) const {
    std::wstring path = m_baseDir + L"\\game_profiles.json";
    std::ifstream f(path);
    if (!f.is_open()) return false;

    profiles.clear();
    // Basit JSON parser (bağımlılık olmadan)
    std::string content((std::istreambuf_iterator<char>(f)),
                         std::istreambuf_iterator<char>());

    auto extract = [&](const std::string& src, const std::string& key) {
        auto pos = src.find("\"" + key + "\":\"");
        if (pos == std::string::npos) return std::string{};
        pos += key.size() + 4;
        auto end = src.find('"', pos);
        if (end == std::string::npos) return std::string{};
        return src.substr(pos, end - pos);
    };
    auto extractBool = [&](const std::string& src, const std::string& key) {
        auto pos = src.find("\"" + key + "\":");
        if (pos == std::string::npos) return false;
        pos += key.size() + 3;
        return src.substr(pos, 4) == "true";
    };

    size_t pos = 0;
    while (true) {
        auto start = content.find('{', pos);
        auto end   = content.find('}', start);
        if (start == std::string::npos || end == std::string::npos) break;
        std::string obj = content.substr(start, end - start + 1);

        GameProfile gp;
        auto name = extract(obj, "name");
        auto exe  = extract(obj, "exe");
        auto work = extract(obj, "workDir");
        gp.name      = std::wstring(name.begin(), name.end());
        gp.exePath   = std::wstring(exe.begin(), exe.end());
        gp.workDir   = std::wstring(work.begin(), work.end());
        gp.useDXVK   = extractBool(obj, "dxvk");
        gp.useVKD3D  = extractBool(obj, "vkd3d");
        gp.forceDX11 = extractBool(obj, "dx11");

        if (!gp.exePath.empty()) profiles.push_back(gp);
        pos = end + 1;
    }
    return true;
}
