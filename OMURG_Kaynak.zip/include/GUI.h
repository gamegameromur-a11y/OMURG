#pragma once
// =============================================================================
// OMURG - GUI.h
// =============================================================================
#ifndef OMURG_GUI_H
#define OMURG_GUI_H

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <memory>

struct Lang;  // forward decl for private methods

class OMURGGui {
public:
    OMURGGui();
    ~OMURGGui();

    bool init(HWND hwnd);
    void render();
    void resize(UINT w, UINT h);
    void shutdown();

private:
    struct Impl;
    std::unique_ptr<Impl> m;

    void createRTV();

    void renderGPUTab     (const Lang& L);
    void renderUpdaterTab (const Lang& L);
    void renderSupportTab (const Lang& L);
    void renderSettingsTab(const Lang& L);
};

// Resource IDs
#define IDI_OMURG 101

#endif // OMURG_GUI_H
