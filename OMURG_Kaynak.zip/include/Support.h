#pragma once
// =============================================================================
// OMURG - Support.h
// Lightweight SMTP-over-Winsock client for sending logs to support email.
// Also exposes an HTTP POST gateway path for REST-based mail APIs.
// =============================================================================
#ifndef OMURG_SUPPORT_H
#define OMURG_SUPPORT_H

#include <string>
#include <vector>
#include <functional>

// ---------------------------------------------------------------------------
// Support ticket payload
// ---------------------------------------------------------------------------
struct SupportTicket {
    std::string senderName;
    std::string senderEmail;  // user's reply-to
    std::string subject;
    std::string body;         // plain-text message
    std::string logDump;      // GPU log (will be base64-attached)
    std::string gpuModel;
    std::string driverVersion;
    std::string osInfo;
};

// ---------------------------------------------------------------------------
// Mail delivery result
// ---------------------------------------------------------------------------
struct MailResult {
    bool        success  = false;
    int         smtpCode = 0;
    std::string detail;
};

// ---------------------------------------------------------------------------
// SupportClient
// ---------------------------------------------------------------------------
class SupportClient {
public:
    static constexpr const char* SUPPORT_EMAIL = "gamegameromur@gmail.com";
    static constexpr const char* SMTP_HOST     = "smtp.gmail.com";
    static constexpr int         SMTP_PORT     = 587;  // STARTTLS

    // Gmail OAuth token (for XOAUTH2) — set before calling sendTicket()
    // For production: obtain via OAuth 2.0 flow or app-password.
    static constexpr const char* GATEWAY_URL =
        "https://api.emailjs.com/api/v1.0/email/send"; // fallback HTTP gateway

    SupportClient();
    ~SupportClient();

    // ── SMTP delivery (requires app password / OAuth) ─────────────────────
    void setSmtpAuth(const std::string& user, const std::string& password);

    /** Send ticket via direct SMTP. Blocking. */
    MailResult sendTicketSMTP(const SupportTicket& ticket);

    // ── HTTP gateway (EmailJS / SendGrid etc.) ────────────────────────────
    void setGatewayApiKey(const std::string& key);
    void setGatewayUrl   (const std::string& url);

    /** Send ticket via HTTP POST JSON. Blocking. */
    MailResult sendTicketHTTP(const SupportTicket& ticket);

    // ── Auto-select: try SMTP, fall back to HTTP ──────────────────────────
    MailResult sendTicket(const SupportTicket& ticket);

    // ── Log helpers ───────────────────────────────────────────────────────
    static std::string collectSystemInfo();
    static std::string base64Encode(const std::string& input);

private:
    std::string m_smtpUser;
    std::string m_smtpPass;
    std::string m_gatewayKey;
    std::string m_gatewayUrl;

    // Winsock SMTP primitives
    MailResult smtpConnect  (void** hSock, const std::string& host, int port);
    MailResult smtpSend     (void*  hSock, const std::string& cmd);
    MailResult smtpRecv     (void*  hSock, std::string& response);
    MailResult smtpClose    (void*  hSock);
    MailResult smtpStartTLS (void** hSock);

    std::string buildMimeMessage(const SupportTicket& ticket);
    std::string buildJsonPayload (const SupportTicket& ticket);
};

#endif // OMURG_SUPPORT_H
