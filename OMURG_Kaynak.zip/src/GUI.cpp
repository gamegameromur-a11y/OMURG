// =============================================================================
// OMURG - GUI.cpp
// Dear ImGui control panel: 5 themes, TR/EN, GPU selector, updater panel,
// support form, live stats dashboard.
//
// Dependencies:  Dear ImGui 1.90+  (docking branch recommended)
//                imgui_impl_win32.h / imgui_impl_dx11.h  (or DX12/Vulkan)
// =============================================================================

#include "GUI.h"
#include "FX150.h"
#include "Updater.h"
#include "Support.h"

#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>   // Swap for DX12/Vulkan if desired

#include <d3d11.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

#include <string>
#include <vector>
#include <sstream>
#include <cstring>
#include <memory>
#include <format>

// =============================================================================
// Language strings
// =============================================================================

struct Lang {
    const char* windowTitle;
    const char* menuGPU;
    const char* menuUpdater;
    const char* menuSupport;
    const char* menuSettings;
    const char* gpuLabel;
    const char* vramLabel;
    const char* threadsLabel;
    const char* tempLabel;
    const char* powerLabel;
    const char* fpsLabel;
    const char* trisLabel;
    const char* updateCheck;
    const char* updateDownload;
    const char* updateStatus;
    const char* supportName;
    const char* supportEmail;
    const char* supportSubj;
    const char* supportMsg;
    const char* supportSend;
    const char* langLabel;
    const char* themeLabel;
    const char* initBtn;
    const char* shutBtn;
    const char* statsHeader;
    const char* memDump;
};

static const Lang LANG_EN = {
    "OMURG Control Panel",
    "GPU",
    "Updater",
    "Support",
    "Settings",
    "Active GPU",
    "VRAM",
    "Compute Units",
    "Temperature",
    "Power Draw",
    "FPS",
    "Triangles/Frame",
    "Check for Updates",
    "Download",
    "Status",
    "Your Name",
    "Your Email",
    "Subject",
    "Message",
    "Send to Support",
    "Language",
    "Theme",
    "Initialize GPU",
    "Shutdown GPU",
    "Live Statistics",
    "Dump Memory Map",
};

static const Lang LANG_TR = {
    "OMURG Kontrol Paneli",
    "GPU",
    "Güncelleyici",
    "Destek",
    "Ayarlar",
    "Aktif GPU",
    "VRAM",
    "İşlem Birimleri",
    "Sıcaklık",
    "Güç Tüketimi",
    "FPS",
    "Üçgen/Kare",
    "Güncelleme Kontrol Et",
    "İndir",
    "Durum",
    "Adınız",
    "E-postanız",
    "Konu",
    "Mesaj",
    "Desteğe Gönder",
    "Dil",
    "Tema",
    "GPU Başlat",
    "GPU Kapat",
    "Canlı İstatistikler",
    "Bellek Haritasını Dök",
};

// =============================================================================
// Theme definitions
// =============================================================================

enum class Theme {
    DarkSilicon,    // Default dark hardware aesthetic
    CyberpunkNeon,  // Hot pink + cyan on near-black
    ArcticBlue,     // Pale blue + white
    OliveTerminal,  // Retro green terminal
    SunsetOrange,   // Warm amber + deep brown
};

static const char* THEME_NAMES[] = {
    "Dark Silicon",
    "Cyberpunk Neon",
    "Arctic Blue",
    "Olive Terminal",
    "Sunset Orange",
};

static void applyTheme(Theme t) {
    ImGuiStyle& s = ImGui::GetStyle();
    ImGui::StyleColorsDark();  // reset base

    s.WindowRounding    = 6.f;
    s.FrameRounding     = 4.f;
    s.ScrollbarRounding = 4.f;
    s.GrabRounding      = 4.f;
    s.TabRounding       = 4.f;
    s.ItemSpacing       = { 8.f, 6.f };
    s.FramePadding      = { 6.f, 4.f };

    ImVec4* c = s.Colors;

    switch (t) {
    // ── Dark Silicon ────────────────────────────────────────────────────
    case Theme::DarkSilicon:
        c[ImGuiCol_WindowBg]         = {0.10f,0.10f,0.12f,1.f};
        c[ImGuiCol_TitleBg]          = {0.08f,0.08f,0.10f,1.f};
        c[ImGuiCol_TitleBgActive]    = {0.14f,0.14f,0.18f,1.f};
        c[ImGuiCol_Header]           = {0.20f,0.20f,0.26f,1.f};
        c[ImGuiCol_HeaderHovered]    = {0.28f,0.28f,0.38f,1.f};
        c[ImGuiCol_Button]           = {0.18f,0.40f,0.78f,1.f};
        c[ImGuiCol_ButtonHovered]    = {0.26f,0.52f,0.96f,1.f};
        c[ImGuiCol_FrameBg]          = {0.16f,0.16f,0.20f,1.f};
        c[ImGuiCol_Tab]              = {0.14f,0.14f,0.18f,1.f};
        c[ImGuiCol_TabActive]        = {0.22f,0.44f,0.88f,1.f};
        c[ImGuiCol_CheckMark]        = {0.40f,0.76f,1.00f,1.f};
        c[ImGuiCol_SliderGrab]       = {0.36f,0.68f,1.00f,1.f};
        c[ImGuiCol_Text]             = {0.90f,0.92f,0.96f,1.f};
        break;

    // ── Cyberpunk Neon ──────────────────────────────────────────────────
    case Theme::CyberpunkNeon:
        c[ImGuiCol_WindowBg]         = {0.05f,0.02f,0.08f,1.f};
        c[ImGuiCol_TitleBg]          = {0.08f,0.02f,0.12f,1.f};
        c[ImGuiCol_TitleBgActive]    = {0.14f,0.04f,0.22f,1.f};
        c[ImGuiCol_Header]           = {0.70f,0.00f,0.60f,0.5f};
        c[ImGuiCol_HeaderHovered]    = {0.90f,0.10f,0.80f,0.8f};
        c[ImGuiCol_Button]           = {0.80f,0.00f,0.70f,1.f};
        c[ImGuiCol_ButtonHovered]    = {1.00f,0.20f,0.90f,1.f};
        c[ImGuiCol_FrameBg]          = {0.10f,0.04f,0.16f,1.f};
        c[ImGuiCol_Tab]              = {0.12f,0.04f,0.20f,1.f};
        c[ImGuiCol_TabActive]        = {0.00f,0.90f,0.90f,1.f};
        c[ImGuiCol_CheckMark]        = {0.00f,1.00f,0.80f,1.f};
        c[ImGuiCol_SliderGrab]       = {0.00f,0.90f,0.90f,1.f};
        c[ImGuiCol_Text]             = {0.95f,0.85f,1.00f,1.f};
        c[ImGuiCol_Separator]        = {0.60f,0.00f,0.80f,1.f};
        break;

    // ── Arctic Blue ─────────────────────────────────────────────────────
    case Theme::ArcticBlue:
        ImGui::StyleColorsLight();
        c[ImGuiCol_WindowBg]         = {0.92f,0.96f,1.00f,1.f};
        c[ImGuiCol_TitleBg]          = {0.70f,0.84f,0.96f,1.f};
        c[ImGuiCol_TitleBgActive]    = {0.52f,0.74f,0.94f,1.f};
        c[ImGuiCol_Button]           = {0.36f,0.64f,0.90f,1.f};
        c[ImGuiCol_ButtonHovered]    = {0.20f,0.50f,0.80f,1.f};
        c[ImGuiCol_FrameBg]          = {0.82f,0.92f,1.00f,1.f};
        c[ImGuiCol_Tab]              = {0.75f,0.90f,1.00f,1.f};
        c[ImGuiCol_TabActive]        = {0.36f,0.64f,0.90f,1.f};
        c[ImGuiCol_Text]             = {0.10f,0.18f,0.30f,1.f};
        break;

    // ── Olive Terminal ──────────────────────────────────────────────────
    case Theme::OliveTerminal:
        c[ImGuiCol_WindowBg]         = {0.04f,0.08f,0.04f,1.f};
        c[ImGuiCol_TitleBg]          = {0.02f,0.06f,0.02f,1.f};
        c[ImGuiCol_TitleBgActive]    = {0.06f,0.14f,0.06f,1.f};
        c[ImGuiCol_Header]           = {0.10f,0.30f,0.10f,1.f};
        c[ImGuiCol_HeaderHovered]    = {0.14f,0.44f,0.14f,1.f};
        c[ImGuiCol_Button]           = {0.12f,0.36f,0.12f,1.f};
        c[ImGuiCol_ButtonHovered]    = {0.18f,0.54f,0.18f,1.f};
        c[ImGuiCol_FrameBg]          = {0.06f,0.12f,0.06f,1.f};
        c[ImGuiCol_Tab]              = {0.04f,0.10f,0.04f,1.f};
        c[ImGuiCol_TabActive]        = {0.12f,0.36f,0.12f,1.f};
        c[ImGuiCol_CheckMark]        = {0.40f,1.00f,0.40f,1.f};
        c[ImGuiCol_SliderGrab]       = {0.30f,0.90f,0.30f,1.f};
        c[ImGuiCol_Text]             = {0.20f,0.95f,0.20f,1.f};
        c[ImGuiCol_Separator]        = {0.10f,0.40f,0.10f,1.f};
        break;

    // ── Sunset Orange ───────────────────────────────────────────────────
    case Theme::SunsetOrange:
        c[ImGuiCol_WindowBg]         = {0.12f,0.07f,0.04f,1.f};
        c[ImGuiCol_TitleBg]          = {0.18f,0.08f,0.03f,1.f};
        c[ImGuiCol_TitleBgActive]    = {0.28f,0.12f,0.04f,1.f};
        c[ImGuiCol_Header]           = {0.60f,0.28f,0.06f,0.6f};
        c[ImGuiCol_HeaderHovered]    = {0.80f,0.40f,0.10f,0.8f};
        c[ImGuiCol_Button]           = {0.80f,0.38f,0.08f,1.f};
        c[ImGuiCol_ButtonHovered]    = {0.96f,0.54f,0.14f,1.f};
        c[ImGuiCol_FrameBg]          = {0.18f,0.10f,0.05f,1.f};
        c[ImGuiCol_Tab]              = {0.20f,0.10f,0.04f,1.f};
        c[ImGuiCol_TabActive]        = {0.80f,0.38f,0.08f,1.f};
        c[ImGuiCol_CheckMark]        = {1.00f,0.70f,0.20f,1.f};
        c[ImGuiCol_SliderGrab]       = {0.90f,0.60f,0.16f,1.f};
        c[ImGuiCol_Text]             = {0.98f,0.88f,0.70f,1.f};
        break;
    }
}

// =============================================================================
// OMURGGui — main class
// =============================================================================

struct OMURGGui::Impl {
    // Window / D3D11
    HWND                     hwnd         = nullptr;
    ID3D11Device*            device       = nullptr;
    ID3D11DeviceContext*     context      = nullptr;
    IDXGISwapChain*          swapChain    = nullptr;
    ID3D11RenderTargetView*  mainRTV      = nullptr;

    // State
    Theme       currentTheme    = Theme::DarkSilicon;
    int         currentLangIdx  = 0;  // 0=EN, 1=TR
    int         gpuSelection    = 0;  // index into gpuList
    bool        gpuInitialized  = false;

    std::unique_ptr<FX150>       gpu;
    std::unique_ptr<Updater>     updater;
    std::unique_ptr<SupportClient> support;

    // GPU list
    std::vector<std::string> gpuList = { "FX150 (512 MB)", "FX150 (1 GB)", "FX150 (2 GB)" };
    static const uint64_t GPU_VRAM_SIZES[];

    // Updater state
    std::string updateStatus;
    bool        updateRunning = false;

    // Support form
    char supportName[128]  = {};
    char supportEmail[128] = {};
    char supportSubj[256]  = {};
    char supportMsg[2048]  = {};
    std::string supportResult;

    // Stats ring buffer for FPS graph
    static constexpr int FPS_HISTORY = 128;
    float fpsHistory[FPS_HISTORY] = {};
    int   fpsIdx = 0;

    // Mem dump
    std::string memDumpText;
};

const uint64_t OMURGGui::Impl::GPU_VRAM_SIZES[] = {
    512ull  * 1024 * 1024,
    1024ull * 1024 * 1024,
    2048ull * 1024 * 1024,
};

OMURGGui::OMURGGui()  : m(std::make_unique<Impl>()) {}
OMURGGui::~OMURGGui() { shutdown(); }

// =============================================================================
// Init / shutdown
// =============================================================================

bool OMURGGui::init(HWND hwnd) {
    m->hwnd = hwnd;

    // Create D3D11
    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount        = 2;
    sd.BufferDesc.Format  = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow       = hwnd;
    sd.SampleDesc.Count   = 1;
    sd.Windowed           = TRUE;
    sd.SwapEffect         = DXGI_SWAP_EFFECT_FLIP_DISCARD;

    D3D_FEATURE_LEVEL featureLevels[] = { D3D_FEATURE_LEVEL_11_0 };
    UINT flags = 0;
#ifdef _DEBUG
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
    if (FAILED(D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr,
            flags, featureLevels, 1, D3D11_SDK_VERSION,
            &sd, &m->swapChain, &m->device,
            nullptr, &m->context)))
        return false;

    createRTV();

    // ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(m->device, m->context);

    applyTheme(m->currentTheme);

    m->updater = std::make_unique<Updater>();
    m->support = std::make_unique<SupportClient>();

    return true;
}

void OMURGGui::createRTV() {
    ID3D11Texture2D* backBuf = nullptr;
    m->swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuf));
    if (backBuf) {
        m->device->CreateRenderTargetView(backBuf, nullptr, &m->mainRTV);
        backBuf->Release();
    }
}

void OMURGGui::shutdown() {
    if (m->gpuInitialized && m->gpu) {
        m->gpu->shutdown();
        m->gpuInitialized = false;
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    if (m->mainRTV)  { m->mainRTV->Release();  m->mainRTV  = nullptr; }
    if (m->swapChain){ m->swapChain->Release(); m->swapChain= nullptr; }
    if (m->context)  { m->context->Release();  m->context  = nullptr; }
    if (m->device)   { m->device->Release();   m->device   = nullptr; }
}

void OMURGGui::resize(UINT w, UINT h) {
    if (m->mainRTV) { m->mainRTV->Release(); m->mainRTV = nullptr; }
    m->swapChain->ResizeBuffers(0, w, h, DXGI_FORMAT_UNKNOWN, 0);
    createRTV();
}

// =============================================================================
// Main render loop tick
// =============================================================================

void OMURGGui::render() {
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    const Lang& L = (m->currentLangIdx == 0) ? LANG_EN : LANG_TR;

    // Full-window dockspace
    ImGui::DockSpaceOverViewport(0, ImGui::GetMainViewport(),
                                 ImGuiDockNodeFlags_PassthruCentralNode);

    // ── Main window ───────────────────────────────────────────────────────
    ImGui::Begin(L.windowTitle, nullptr,
                 ImGuiWindowFlags_NoScrollbar);

    if (ImGui::BeginTabBar("MainTabs")) {

        // ═══════════════════════════════════════════════════════════════
        // Tab: GPU
        // ═══════════════════════════════════════════════════════════════
        if (ImGui::BeginTabItem(L.menuGPU)) {
            renderGPUTab(L);
            ImGui::EndTabItem();
        }

        // ═══════════════════════════════════════════════════════════════
        // Tab: Updater
        // ═══════════════════════════════════════════════════════════════
        if (ImGui::BeginTabItem(L.menuUpdater)) {
            renderUpdaterTab(L);
            ImGui::EndTabItem();
        }

        // ═══════════════════════════════════════════════════════════════
        // Tab: Support
        // ═══════════════════════════════════════════════════════════════
        if (ImGui::BeginTabItem(L.menuSupport)) {
            renderSupportTab(L);
            ImGui::EndTabItem();
        }

        // ═══════════════════════════════════════════════════════════════
        // Tab: Settings
        // ═══════════════════════════════════════════════════════════════
        if (ImGui::BeginTabItem(L.menuSettings)) {
            renderSettingsTab(L);
            ImGui::EndTabItem();
        }

        ImGui::EndTabBar();
    }

    ImGui::End();

    // ImGui render
    ImGui::Render();
    const float cc[4] = { 0.06f, 0.06f, 0.08f, 1.f };
    m->context->OMSetRenderTargets(1, &m->mainRTV, nullptr);
    m->context->ClearRenderTargetView(m->mainRTV, cc);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    m->swapChain->Present(1, 0);
}

// =============================================================================
// GPU Tab
// =============================================================================

void OMURGGui::renderGPUTab(const Lang& L) {
    ImGui::Spacing();

    // GPU selector
    ImGui::Text("%s:", L.gpuLabel);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(220.f);

    std::vector<const char*> items;
    for (auto& n : m->gpuList) items.push_back(n.c_str());

    ImGui::Combo("##gpu", &m->gpuSelection,
                 items.data(), static_cast<int>(items.size()));

    ImGui::SameLine();
    if (!m->gpuInitialized) {
        if (ImGui::Button(L.initBtn)) {
            uint64_t vram = Impl::GPU_VRAM_SIZES[
                std::min(m->gpuSelection, 2)];
            m->gpu = std::make_unique<FX150>(vram);
            m->gpuInitialized = m->gpu->initialize();
        }
    } else {
        if (ImGui::Button(L.shutBtn)) {
            m->gpu->shutdown();
            m->gpuInitialized = false;
        }
    }

    // Status indicator
    ImGui::SameLine();
    if (m->gpuInitialized) {
        ImGui::TextColored({0.2f,1.f,0.4f,1.f}, "● ONLINE");
    } else {
        ImGui::TextColored({1.f,0.3f,0.3f,1.f}, "● OFFLINE");
    }

    ImGui::Separator();

    if (!m->gpuInitialized || !m->gpu) {
        ImGui::TextDisabled("No GPU active.");
        return;
    }

    // ── Live stats ───────────────────────────────────────────────────────
    ImGui::Text("%s", L.statsHeader);
    ImGui::Spacing();

    GPUStats   stats = m->gpu->queryStats();
    GPUDescriptor& desc = const_cast<GPUDescriptor&>(m->gpu->descriptor());

    // FPS graph
    m->fpsHistory[m->fpsIdx] = static_cast<float>(stats.fps);
    m->fpsIdx = (m->fpsIdx + 1) % Impl::FPS_HISTORY;
    char fpsLabel[32];
    std::snprintf(fpsLabel, sizeof(fpsLabel), "%.1f FPS", stats.fps);
    ImGui::PlotLines("##fps", m->fpsHistory, Impl::FPS_HISTORY,
                     m->fpsIdx, fpsLabel, 0.f, 200.f, {0, 60});

    // Info grid
    ImGui::Columns(2, "stats_col", false);
    ImGui::SetColumnWidth(0, 180.f);

    auto row = [&](const char* label, const std::string& val, ImVec4 col = {0.9f,0.92f,0.96f,1.f}) {
        ImGui::Text("%s:", label);
        ImGui::NextColumn();
        ImGui::TextColored(col, "%s", val.c_str());
        ImGui::NextColumn();
    };

    row(L.vramLabel,
        std::format("{:.1f} MB / {:.0f} MB",
            stats.vramUsed / 1048576.0,
            desc.vramBytes / 1048576.0));

    row(L.threadsLabel,
        std::to_string(stats.activeThreads));

    float temp = m->gpu->simulatedTemperature();
    ImVec4 tempCol = (temp > 75.f) ? ImVec4{1.f,0.3f,0.2f,1.f}
                   : (temp > 55.f) ? ImVec4{1.f,0.8f,0.2f,1.f}
                   :                 ImVec4{0.3f,1.f,0.5f,1.f};
    row(L.tempLabel,
        std::format("{:.1f} °C", temp), tempCol);

    row(L.powerLabel,
        std::format("{:.1f} W", m->gpu->simulatedPowerDraw()));

    row(L.fpsLabel,
        std::format("{:.2f}", stats.fps));

    row(L.trisLabel,
        std::format("{}", stats.trianglesPerFrame));

    ImGui::Columns(1);

    // VRAM bar
    float vramRatio = static_cast<float>(stats.vramUsed) / desc.vramBytes;
    ImGui::ProgressBar(vramRatio, {-1.f, 0.f}, "VRAM");

    // Temp bar
    float tempRatio = (temp - 30.f) / (90.f - 30.f);
    ImGui::ProgressBar(tempRatio < 0 ? 0 : tempRatio, {-1.f, 0.f}, L.tempLabel);

    ImGui::Spacing();
    if (ImGui::Button(L.memDump)) {
        m->memDumpText = m->gpu->dumpMemoryMap();
    }
    if (!m->memDumpText.empty()) {
        ImGui::InputTextMultiline("##memdump",
            m->memDumpText.data(),
            m->memDumpText.size(),
            {-1.f, 200.f},
            ImGuiInputTextFlags_ReadOnly);
    }
}

// =============================================================================
// Updater Tab
// =============================================================================

void OMURGGui::renderUpdaterTab(const Lang& L) {
    ImGui::Spacing();
    ImGui::TextWrapped("GitHub manifest: %s",
        Updater::DEFAULT_MANIFEST_URL);
    ImGui::Separator();
    ImGui::Spacing();

    if (!m->updateRunning) {
        if (ImGui::Button(L.updateCheck, {160.f, 0.f})) {
            m->updateRunning  = true;
            m->updateStatus   = "Fetching manifest...";

            m->updater->startAsyncUpdate(
                [this](const DownloadProgress& p) {
                    // progress callback (runs on background thread)
                    char buf[256];
                    if (p.totalBytes > 0)
                        std::snprintf(buf, sizeof(buf),
                            "Downloading %s: %.1f%%", p.filename.c_str(),
                            100.0 * p.bytesReceived / p.totalBytes);
                    else
                        std::snprintf(buf, sizeof(buf),
                            "Downloading %s: %llu bytes",
                            p.filename.c_str(), p.bytesReceived);
                    m->updateStatus = buf;
                },
                [this](bool ok, const std::string& msg) {
                    m->updateRunning = false;
                    m->updateStatus  = (ok ? "[OK] " : "[FAIL] ") + msg;
                });
        }
    } else {
        if (ImGui::Button("Cancel")) {
            m->updater->cancelAsync();
        }
        ImGui::SameLine();
        // Animated spinner
        const char* spin[] = {"|","/","-","\\"};
        static int frame = 0;
        ImGui::Text("%s %s", spin[(frame++ / 8) % 4], "Working...");
    }

    ImGui::Spacing();
    ImGui::Text("%s:", L.updateStatus);
    ImGui::SameLine();
    ImGui::TextWrapped("%s", m->updateStatus.c_str());
}

// =============================================================================
// Support Tab
// =============================================================================

void OMURGGui::renderSupportTab(const Lang& L) {
    ImGui::Spacing();
    ImGui::TextColored({0.6f,0.85f,1.f,1.f},
        "Support: %s", SupportClient::SUPPORT_EMAIL);
    ImGui::Separator();
    ImGui::Spacing();

    ImGui::Text("%s:", L.supportName);
    ImGui::InputText("##sname", m->supportName, sizeof(m->supportName));

    ImGui::Text("%s:", L.supportEmail);
    ImGui::InputText("##semail", m->supportEmail, sizeof(m->supportEmail));

    ImGui::Text("%s:", L.supportSubj);
    ImGui::InputText("##ssubj", m->supportSubj, sizeof(m->supportSubj));

    ImGui::Text("%s:", L.supportMsg);
    ImGui::InputTextMultiline("##smsg", m->supportMsg,
        sizeof(m->supportMsg), {-1.f, 120.f});

    ImGui::Spacing();
    if (ImGui::Button(L.supportSend, {180.f, 0.f})) {
        SupportTicket ticket;
        ticket.senderName    = m->supportName;
        ticket.senderEmail   = m->supportEmail;
        ticket.subject       = m->supportSubj;
        ticket.body          = m->supportMsg;
        ticket.osInfo        = SupportClient::collectSystemInfo();

        if (m->gpuInitialized && m->gpu) {
            ticket.gpuModel      = m->gpu->descriptor().modelName;
            ticket.driverVersion = m->gpu->descriptor().driverVersion;
            ticket.logDump       = m->gpu->dumpMemoryMap();
        } else {
            ticket.gpuModel = "N/A";
        }

        auto result = m->support->sendTicket(ticket);
        m->supportResult = result.success
            ? "[OK] Message sent."
            : "[FAIL] " + result.detail;
    }

    if (!m->supportResult.empty()) {
        ImGui::Spacing();
        bool ok = m->supportResult.substr(0,4) == "[OK]";
        ImGui::TextColored(ok ? ImVec4{0.2f,1.f,0.4f,1.f}
                             : ImVec4{1.f,0.3f,0.3f,1.f},
            "%s", m->supportResult.c_str());
    }
}

// =============================================================================
// Settings Tab
// =============================================================================

void OMURGGui::renderSettingsTab(const Lang& L) {
    ImGui::Spacing();

    // Language
    ImGui::Text("%s:", L.langLabel);
    ImGui::SameLine();
    const char* langs[] = { "English", "Türkçe" };
    ImGui::SetNextItemWidth(140.f);
    if (ImGui::Combo("##lang", &m->currentLangIdx, langs, 2)) {
        // Language change takes effect on next frame automatically
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // Theme
    ImGui::Text("%s:", L.themeLabel);
    ImGui::Spacing();

    int themeIdx = static_cast<int>(m->currentTheme);
    for (int i = 0; i < 5; ++i) {
        if (ImGui::RadioButton(THEME_NAMES[i], themeIdx == i)) {
            m->currentTheme = static_cast<Theme>(i);
            applyTheme(m->currentTheme);
        }
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // About
    ImGui::TextDisabled("OMURG Virtual GPU  v1.0.0");
    ImGui::TextDisabled("FX150 Software Rasterizer  |  x64");
    ImGui::TextDisabled("(c) 2025 OMURG Project");
}

// =============================================================================
// WinMain entry point
// =============================================================================

// Forward declaration for imgui_impl_win32
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static OMURGGui* g_gui = nullptr;

static LRESULT CALLBACK WndProc(HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg) {
    case WM_SIZE:
        if (g_gui && wParam != SIZE_MINIMIZED)
            g_gui->resize(LOWORD(lParam), HIWORD(lParam));
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    // Register window class
    WNDCLASSEXW wc = { sizeof(wc) };
    wc.style         = CS_CLASSDC;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = L"OMURGWnd";
    wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_OMURG));
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowW(
        L"OMURGWnd", L"OMURG Virtual GPU Control Panel",
        WS_OVERLAPPEDWINDOW,
        100, 100, 1200, 800,
        nullptr, nullptr, hInstance, nullptr);

    OMURGGui gui;
    g_gui = &gui;

    if (!gui.init(hwnd)) {
        MessageBoxA(nullptr, "Failed to initialize OMURG GUI.", "Error", MB_OK | MB_ICONERROR);
        return 1;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg = {};
    while (msg.message != WM_QUIT) {
        if (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        } else {
            gui.render();
        }
    }

    gui.shutdown();
    g_gui = nullptr;
    DestroyWindow(hwnd);
    UnregisterClassW(L"OMURGWnd", hInstance);
    return 0;
}
