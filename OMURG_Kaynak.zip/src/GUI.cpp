// =============================================================================
// OMURG - GUI.cpp  [NVIDIA-Style Redesign]
// =============================================================================

#include "GUI.h"
#include "FX150.h"
#include "Updater.h"
#include "Support.h"

#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>

#include <d3d11.h>
#include <shellapi.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "shell32.lib")

#include <string>
#include <vector>
#include <sstream>
#include <cstring>
#include <memory>
#include <format>

// =============================================================================
// Language strings
// =============================================================================

struct Lang {
    const char* windowTitle;
    const char* menuGPU;
    const char* menuUpdater;
    const char* menuSupport;
    const char* menuSettings;
    const char* gpuLabel;
    const char* vramLabel;
    const char* threadsLabel;
    const char* tempLabel;
    const char* powerLabel;
    const char* fpsLabel;
    const char* trisLabel;
    const char* updateCheck;
    const char* updateDownload;
    const char* updateStatus;
    const char* supportName;
    const char* supportEmail;
    const char* supportSubj;
    const char* supportMsg;
    const char* supportSend;
    const char* langLabel;
    const char* themeLabel;
    const char* initBtn;
    const char* shutBtn;
    const char* statsHeader;
    const char* memDump;
};

static const Lang LANG_EN = {
    "OMURG Control Panel", "GPU", "Updater", "Support", "Settings",
    "Active GPU", "VRAM", "Compute Units", "Temperature", "Power Draw",
    "FPS", "Triangles/Frame", "Check for Updates", "Download", "Status",
    "Your Name", "Your Email", "Subject", "Message", "Send to Support",
    "Language", "Theme", "Initialize GPU", "Shutdown GPU",
    "Live Statistics", "Dump Memory Map",
};

static const Lang LANG_TR = {
    "OMURG Kontrol Paneli", "GPU", "Guncelleyici", "Destek", "Ayarlar",
    "Aktif GPU", "VRAM", "Islem Birimleri", "Sicaklik", "Guc Tuketimi",
    "FPS", "Ucgen/Kare", "Guncelleme Kontrol Et", "Indir", "Durum",
    "Adiniz", "E-postaniz", "Konu", "Mesaj", "Destege Gonder",
    "Dil", "Tema", "GPU Baslat", "GPU Kapat",
    "Canli Istatistikler", "Bellek Haritasini Dok",
};

// =============================================================================
// NVIDIA Color Palette
// =============================================================================

static const ImVec4 NV_BG          = { 0.102f, 0.102f, 0.102f, 1.f }; // #1a1a1a
static const ImVec4 NV_BG2         = { 0.141f, 0.141f, 0.141f, 1.f }; // #242424
static const ImVec4 NV_BG3         = { 0.180f, 0.180f, 0.180f, 1.f }; // #2e2e2e
static const ImVec4 NV_PANEL       = { 0.118f, 0.118f, 0.118f, 1.f }; // #1e1e1e
static const ImVec4 NV_GREEN       = { 0.463f, 0.725f, 0.000f, 1.f }; // #76b900 NVIDIA green
static const ImVec4 NV_GREEN_DIM   = { 0.300f, 0.470f, 0.000f, 1.f };
static const ImVec4 NV_GREEN_DARK  = { 0.180f, 0.290f, 0.000f, 1.f };
static const ImVec4 NV_TEXT        = { 0.940f, 0.940f, 0.940f, 1.f };
static const ImVec4 NV_TEXT_DIM    = { 0.560f, 0.560f, 0.560f, 1.f };
static const ImVec4 NV_BORDER      = { 0.230f, 0.230f, 0.230f, 1.f };
static const ImVec4 NV_RED         = { 1.000f, 0.250f, 0.250f, 1.f };
static const ImVec4 NV_ORANGE      = { 1.000f, 0.650f, 0.000f, 1.f };
static const ImVec4 NV_SELECTED    = { 0.200f, 0.200f, 0.200f, 1.f };

static void applyNvidiaTheme() {
    ImGuiStyle& s = ImGui::GetStyle();
    ImGui::StyleColorsDark();

    s.WindowRounding    = 0.f;
    s.ChildRounding     = 4.f;
    s.FrameRounding     = 3.f;
    s.ScrollbarRounding = 3.f;
    s.GrabRounding      = 3.f;
    s.TabRounding       = 3.f;
    s.WindowBorderSize  = 0.f;
    s.ChildBorderSize   = 1.f;
    s.FrameBorderSize   = 0.f;
    s.ItemSpacing       = { 10.f, 8.f };
    s.ItemInnerSpacing  = { 6.f, 4.f };
    s.FramePadding      = { 8.f, 5.f };
    s.WindowPadding     = { 12.f, 12.f };
    s.IndentSpacing     = 16.f;
    s.ScrollbarSize     = 10.f;

    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg]             = NV_BG;
    c[ImGuiCol_ChildBg]              = NV_PANEL;
    c[ImGuiCol_PopupBg]              = NV_BG2;
    c[ImGuiCol_Border]               = NV_BORDER;
    c[ImGuiCol_BorderShadow]         = { 0,0,0,0 };
    c[ImGuiCol_FrameBg]              = NV_BG3;
    c[ImGuiCol_FrameBgHovered]       = { 0.24f,0.24f,0.24f,1.f };
    c[ImGuiCol_FrameBgActive]        = { 0.28f,0.28f,0.28f,1.f };
    c[ImGuiCol_TitleBg]              = NV_BG;
    c[ImGuiCol_TitleBgActive]        = NV_BG;
    c[ImGuiCol_TitleBgCollapsed]     = NV_BG;
    c[ImGuiCol_MenuBarBg]            = NV_BG2;
    c[ImGuiCol_ScrollbarBg]          = NV_BG;
    c[ImGuiCol_ScrollbarGrab]        = NV_BG3;
    c[ImGuiCol_ScrollbarGrabHovered] = NV_BORDER;
    c[ImGuiCol_ScrollbarGrabActive]  = NV_TEXT_DIM;
    c[ImGuiCol_CheckMark]            = NV_GREEN;
    c[ImGuiCol_SliderGrab]           = NV_GREEN;
    c[ImGuiCol_SliderGrabActive]     = { 0.55f,0.85f,0.0f,1.f };
    c[ImGuiCol_Button]               = NV_GREEN_DARK;
    c[ImGuiCol_ButtonHovered]        = NV_GREEN_DIM;
    c[ImGuiCol_ButtonActive]         = NV_GREEN;
    c[ImGuiCol_Header]               = NV_BG3;
    c[ImGuiCol_HeaderHovered]        = NV_SELECTED;
    c[ImGuiCol_HeaderActive]         = NV_GREEN_DARK;
    c[ImGuiCol_Separator]            = NV_BORDER;
    c[ImGuiCol_SeparatorHovered]     = NV_GREEN_DIM;
    c[ImGuiCol_SeparatorActive]      = NV_GREEN;
    c[ImGuiCol_ResizeGrip]           = { 0,0,0,0 };
    c[ImGuiCol_ResizeGripHovered]    = NV_GREEN_DIM;
    c[ImGuiCol_ResizeGripActive]     = NV_GREEN;
    c[ImGuiCol_Tab]                  = NV_BG2;
    c[ImGuiCol_TabHovered]           = NV_BG3;
    c[ImGuiCol_TabActive]            = NV_GREEN_DARK;
    c[ImGuiCol_TabUnfocused]         = NV_BG;
    c[ImGuiCol_TabUnfocusedActive]   = NV_BG2;
    c[ImGuiCol_DockingPreview]       = NV_GREEN;
    c[ImGuiCol_PlotLines]            = NV_GREEN;
    c[ImGuiCol_PlotLinesHovered]     = { 0.55f,0.85f,0.0f,1.f };
    c[ImGuiCol_PlotHistogram]        = NV_GREEN;
    c[ImGuiCol_PlotHistogramHovered] = { 0.55f,0.85f,0.0f,1.f };
    c[ImGuiCol_TableHeaderBg]        = NV_BG2;
    c[ImGuiCol_TableBorderStrong]    = NV_BORDER;
    c[ImGuiCol_TableBorderLight]     = { 0.18f,0.18f,0.18f,1.f };
    c[ImGuiCol_TextSelectedBg]       = NV_GREEN_DARK;
    c[ImGuiCol_NavHighlight]         = NV_GREEN;
    c[ImGuiCol_Text]                 = NV_TEXT;
    c[ImGuiCol_TextDisabled]         = NV_TEXT_DIM;
}

// =============================================================================
// Helper: section header (NVIDIA style divider)
// =============================================================================

static void SectionHeader(const char* label) {
    ImGui::Spacing();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(pos, { pos.x + 4.f, pos.y + 18.f },
                      IM_COL32(118, 185, 0, 255)); // NVIDIA green bar
    ImGui::SetCursorScreenPos({ pos.x + 10.f, pos.y + 1.f });
    ImGui::TextColored(NV_TEXT, "%s", label);
    ImGui::SetCursorScreenPos({ pos.x, pos.y + 22.f });
    dl->AddLine({ pos.x, pos.y + 22.f }, { pos.x + w, pos.y + 22.f },
                IM_COL32(58, 58, 58, 255));
    ImGui::Dummy({ w, 6.f });
}

// =============================================================================
// Helper: stat row
// =============================================================================

static void StatRow(const char* label, const std::string& value,
                    ImVec4 valCol = { 0.94f,0.94f,0.94f,1.f }) {
    ImGui::TextColored(NV_TEXT_DIM, "%s", label);
    ImGui::SameLine(200.f);
    ImGui::TextColored(valCol, "%s", value.c_str());
}

// =============================================================================
// Helper: NVIDIA-style progress bar
// =============================================================================

static void NvProgressBar(float fraction, float height,
                           ImVec4 color = { 0.463f,0.725f,0.0f,1.f }) {
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float w    = ImGui::GetContentRegionAvail().x;
    ImDrawList* dl = ImGui::GetWindowDrawList();

    // Background track
    dl->AddRectFilled(pos, { pos.x + w, pos.y + height },
                      IM_COL32(42, 42, 42, 255), 2.f);
    // Fill
    float fill = fraction * w;
    if (fill > 2.f) {
        dl->AddRectFilled(pos, { pos.x + fill, pos.y + height },
                          IM_COL32(
                              static_cast<int>(color.x * 255),
                              static_cast<int>(color.y * 255),
                              static_cast<int>(color.z * 255), 255), 2.f);
    }
    ImGui::Dummy({ w, height + 4.f });
}

// =============================================================================
// OMURGGui — main class
// =============================================================================

struct OMURGGui::Impl {
    HWND                     hwnd         = nullptr;
    ID3D11Device*            device       = nullptr;
    ID3D11DeviceContext*     context      = nullptr;
    IDXGISwapChain*          swapChain    = nullptr;
    ID3D11RenderTargetView*  mainRTV      = nullptr;

    int         currentLangIdx  = 0;
    int         gpuSelection    = 0;
    bool        gpuInitialized  = false;
    int         activeSection   = 0; // 0=GPU, 1=Updater, 2=Support, 3=Settings

    std::unique_ptr<FX150>         gpu;
    std::unique_ptr<Updater>       updater;
    std::unique_ptr<SupportClient> support;

    std::vector<std::string> gpuList = {
        "OMURG FX150  [512 MB]",
        "OMURG FX150  [1 GB]",
        "OMURG FX150  [2 GB]"
    };
    static const uint64_t GPU_VRAM_SIZES[];

    std::string updateStatus;
    bool        updateRunning = false;

    char supportName[128]  = {};
    char supportEmail[128] = {};
    char supportSubj[256]  = {};
    char supportMsg[2048]  = {};
    std::string supportResult;
    bool supportResultOk   = false;

    static constexpr int FPS_HISTORY = 128;
    float fpsHistory[FPS_HISTORY] = {};
    int   fpsIdx = 0;
    std::string memDumpText;
};

const uint64_t OMURGGui::Impl::GPU_VRAM_SIZES[] = {
    512ull  * 1024 * 1024,
    1024ull * 1024 * 1024,
    2048ull * 1024 * 1024,
};

OMURGGui::OMURGGui()  : m(std::make_unique<Impl>()) {}
OMURGGui::~OMURGGui() { shutdown(); }

// =============================================================================
// Init / Shutdown
// =============================================================================

bool OMURGGui::init(HWND hwnd) {
    m->hwnd = hwnd;

    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount        = 2;
    sd.BufferDesc.Format  = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage        = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow       = hwnd;
    sd.SampleDesc.Count   = 1;
    sd.Windowed           = TRUE;
    sd.SwapEffect         = DXGI_SWAP_EFFECT_FLIP_DISCARD;

    D3D_FEATURE_LEVEL fl[] = { D3D_FEATURE_LEVEL_11_0 };
    if (FAILED(D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
            fl, 1, D3D11_SDK_VERSION, &sd,
            &m->swapChain, &m->device, nullptr, &m->context)))
        return false;

    createRTV();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.IniFilename = nullptr;

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(m->device, m->context);

    applyNvidiaTheme();

    m->updater = std::make_unique<Updater>();
    m->support = std::make_unique<SupportClient>();

    return true;
}

void OMURGGui::createRTV() {
    ID3D11Texture2D* bb = nullptr;
    m->swapChain->GetBuffer(0, IID_PPV_ARGS(&bb));
    if (bb) { m->device->CreateRenderTargetView(bb, nullptr, &m->mainRTV); bb->Release(); }
}

void OMURGGui::shutdown() {
    if (m->gpuInitialized && m->gpu) { m->gpu->shutdown(); m->gpuInitialized = false; }
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (m->mainRTV)  { m->mainRTV->Release();  m->mainRTV  = nullptr; }
    if (m->swapChain){ m->swapChain->Release(); m->swapChain= nullptr; }
    if (m->context)  { m->context->Release();  m->context  = nullptr; }
    if (m->device)   { m->device->Release();   m->device   = nullptr; }
}

void OMURGGui::resize(UINT w, UINT h) {
    if (m->mainRTV) { m->mainRTV->Release(); m->mainRTV = nullptr; }
    m->swapChain->ResizeBuffers(0, w, h, DXGI_FORMAT_UNKNOWN, 0);
    createRTV();
}

// =============================================================================
// Main render
// =============================================================================

void OMURGGui::render() {
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    const Lang& L = (m->currentLangIdx == 0) ? LANG_EN : LANG_TR;

    ImGuiIO& io = ImGui::GetIO();
    ImGui::SetNextWindowPos({ 0, 0 });
    ImGui::SetNextWindowSize(io.DisplaySize);
    ImGui::Begin("##root", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoBringToFrontOnFocus);

    // ── Left sidebar ──────────────────────────────────────────────────────
    float sideW = 220.f;
    float totalH = ImGui::GetContentRegionAvail().y;

    ImGui::PushStyleColor(ImGuiCol_ChildBg, NV_BG2);
    ImGui::BeginChild("##sidebar", { sideW, totalH }, false);

    // Logo area
    ImGui::Dummy({ 0, 14.f });
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        // Green accent square
        dl->AddRectFilled(p, { p.x + 5.f, p.y + 40.f },
                          IM_COL32(118, 185, 0, 255));
        ImGui::SetCursorScreenPos({ p.x + 14.f, p.y });
        ImGui::TextColored(NV_GREEN, "OMURG");
        ImGui::SetCursorScreenPos({ p.x + 14.f, p.y + 20.f });
        ImGui::TextColored(NV_TEXT_DIM, "Virtual GPU");
        ImGui::SetCursorScreenPos({ p.x, p.y + 44.f });
    }
    ImGui::Dummy({ 0, 6.f });

    // Thin separator
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        dl->AddLine(p, { p.x + sideW, p.y }, IM_COL32(58, 58, 58, 255));
        ImGui::Dummy({ sideW, 8.f });
    }

    // Navigation items
    struct NavItem { const char* icon; const char* label; };
    const NavItem navEN[] = {
        { "[ ]", "GPU Control" },
        { "[U]", "Updater"     },
        { "[S]", "Support"     },
        { "[=]", "Settings"    },
    };
    const NavItem navTR[] = {
        { "[ ]", "GPU Kontrol" },
        { "[U]", "Guncelleyici"},
        { "[S]", "Destek"      },
        { "[=]", "Ayarlar"     },
    };
    const NavItem* nav = (m->currentLangIdx == 0) ? navEN : navTR;

    for (int i = 0; i < 4; ++i) {
        bool selected = (m->activeSection == i);

        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();

        if (selected) {
            // Green left bar + highlighted bg
            dl->AddRectFilled(p, { p.x + sideW, p.y + 36.f },
                              IM_COL32(30, 30, 30, 255));
            dl->AddRectFilled(p, { p.x + 3.f, p.y + 36.f },
                              IM_COL32(118, 185, 0, 255));
        }

        ImGui::PushStyleColor(ImGuiCol_Button,
            selected ? ImVec4{0.12f,0.12f,0.12f,1.f} : ImVec4{0,0,0,0});
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4{0.20f,0.20f,0.20f,1.f});
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4{0.16f,0.16f,0.16f,1.f});
        ImGui::PushStyleColor(ImGuiCol_Text,
            selected ? NV_GREEN : NV_TEXT_DIM);

        char btnId[32];
        std::snprintf(btnId, sizeof(btnId), "  %s##nav%d", nav[i].label, i);
        if (ImGui::Button(btnId, { sideW, 36.f }))
            m->activeSection = i;

        ImGui::PopStyleColor(4);
    }

    // Bottom: GPU status badge
    ImGui::SetCursorPosY(totalH - 80.f);
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        dl->AddLine(p, { p.x + sideW, p.y }, IM_COL32(58, 58, 58, 255));
    }
    ImGui::Dummy({ 0, 8.f });

    if (m->gpuInitialized) {
        ImGui::TextColored(NV_TEXT_DIM, "  GPU");
        ImGui::SameLine();
        ImGui::TextColored(NV_GREEN, "ONLINE");
    } else {
        ImGui::TextColored(NV_TEXT_DIM, "  GPU");
        ImGui::SameLine();
        ImGui::TextColored(NV_RED, "OFFLINE");
    }
    ImGui::TextColored(NV_TEXT_DIM, "  v1.0.0 | x64 | AVX2");

    ImGui::EndChild();
    ImGui::PopStyleColor();

    // ── Content area ──────────────────────────────────────────────────────
    ImGui::SameLine();

    // Vertical separator line
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetCursorScreenPos();
        dl->AddLine(p, { p.x, p.y + totalH }, IM_COL32(58, 58, 58, 255));
    }
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 1.f);

    ImGui::PushStyleColor(ImGuiCol_ChildBg, NV_BG);
    ImGui::BeginChild("##content", { 0, totalH }, false,
                      ImGuiWindowFlags_HorizontalScrollbar);

    switch (m->activeSection) {
    case 0: renderGPUTab(L);      break;
    case 1: renderUpdaterTab(L);  break;
    case 2: renderSupportTab(L);  break;
    case 3: renderSettingsTab(L); break;
    }

    ImGui::EndChild();
    ImGui::PopStyleColor();

    ImGui::End();

    ImGui::Render();
    const float cc[4] = { 0.102f, 0.102f, 0.102f, 1.f };
    m->context->OMSetRenderTargets(1, &m->mainRTV, nullptr);
    m->context->ClearRenderTargetView(m->mainRTV, cc);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    m->swapChain->Present(1, 0);
}

// =============================================================================
// GPU Tab
// =============================================================================

void OMURGGui::renderGPUTab(const Lang& L) {
    ImGui::Spacing();
    SectionHeader("GPU Selection");

    // GPU model selector
    std::vector<const char*> items;
    for (auto& n : m->gpuList) items.push_back(n.c_str());
    ImGui::SetNextItemWidth(280.f);
    ImGui::Combo("##gpu", &m->gpuSelection,
                 items.data(), static_cast<int>(items.size()));
    ImGui::SameLine(300.f);

    if (!m->gpuInitialized) {
        ImGui::PushStyleColor(ImGuiCol_Button,        NV_GREEN_DARK);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, NV_GREEN_DIM);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  NV_GREEN);
        if (ImGui::Button(L.initBtn, { 160.f, 28.f })) {
            uint64_t vram = Impl::GPU_VRAM_SIZES[std::min(m->gpuSelection, 2)];
            m->gpu = std::make_unique<FX150>(vram);
            m->gpuInitialized = m->gpu->initialize();
        }
        ImGui::PopStyleColor(3);
    } else {
        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4{0.30f,0.06f,0.06f,1.f});
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4{0.50f,0.10f,0.10f,1.f});
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  NV_RED);
        if (ImGui::Button(L.shutBtn, { 160.f, 28.f })) {
            m->gpu->shutdown();
            m->gpuInitialized = false;
        }
        ImGui::PopStyleColor(3);
    }

    if (!m->gpuInitialized || !m->gpu) {
        ImGui::Spacing();
        ImGui::Spacing();
        SectionHeader("Status");
        ImGui::TextColored(NV_TEXT_DIM, "No GPU active. Click \"Initialize GPU\" to begin.");
        return;
    }

    ImGui::Spacing();
    SectionHeader("Live Statistics");

    GPUStats stats  = m->gpu->queryStats();
    GPUDescriptor& desc = const_cast<GPUDescriptor&>(m->gpu->descriptor());

    float temp      = m->gpu->simulatedTemperature();
    float power     = m->gpu->simulatedPowerDraw();
    float vramRatio = static_cast<float>(stats.vramUsed) / desc.vramBytes;
    float tempRatio = std::max(0.f, (temp - 30.f) / (90.f - 30.f));

    ImVec4 tempCol = (temp > 75.f) ? NV_RED
                   : (temp > 55.f) ? NV_ORANGE
                   :                 NV_GREEN;

    // FPS graph
    m->fpsHistory[m->fpsIdx] = static_cast<float>(stats.fps);
    m->fpsIdx = (m->fpsIdx + 1) % Impl::FPS_HISTORY;
    char fpsLabel[32];
    std::snprintf(fpsLabel, sizeof(fpsLabel), "%.1f FPS", stats.fps);

    ImGui::PushStyleColor(ImGuiCol_FrameBg,      NV_BG2);
    ImGui::PushStyleColor(ImGuiCol_PlotLines,    NV_GREEN);
    ImGui::PlotLines("##fps", m->fpsHistory, Impl::FPS_HISTORY,
                     m->fpsIdx, fpsLabel, 0.f, 200.f,
                     { ImGui::GetContentRegionAvail().x, 70.f });
    ImGui::PopStyleColor(2);

    ImGui::Spacing();

    // Stats grid
    StatRow("GPU Model",
            m->gpu->descriptor().modelName);
    StatRow("VRAM Usage",
            std::format("{:.1f} MB / {:.0f} MB",
                stats.vramUsed / 1048576.0,
                desc.vramBytes / 1048576.0));
    StatRow("Compute Units",
            std::to_string(stats.activeThreads));
    StatRow("Temperature",
            std::format("{:.1f} C", temp), tempCol);
    StatRow("Power Draw",
            std::format("{:.1f} W", power));
    StatRow("Triangles/Frame",
            std::format("{}", stats.trianglesPerFrame));

    ImGui::Spacing();
    SectionHeader("VRAM");
    NvProgressBar(vramRatio, 12.f, NV_GREEN);
    ImGui::TextColored(NV_TEXT_DIM, "%.1f MB used of %.0f MB",
        stats.vramUsed / 1048576.0, desc.vramBytes / 1048576.0);

    ImGui::Spacing();
    SectionHeader("Thermal");
    NvProgressBar(tempRatio, 12.f, tempCol);
    ImGui::TextColored(tempCol, "%.1f C", temp);

    ImGui::Spacing();
    SectionHeader("Memory Diagnostics");
    ImGui::PushStyleColor(ImGuiCol_Button,        NV_BG3);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, NV_SELECTED);
    if (ImGui::Button(L.memDump, { 200.f, 28.f }))
        m->memDumpText = m->gpu->dumpMemoryMap();
    ImGui::PopStyleColor(2);

    if (!m->memDumpText.empty()) {
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_FrameBg, NV_BG2);
        ImGui::InputTextMultiline("##memdump",
            m->memDumpText.data(), m->memDumpText.size(),
            { -1.f, 180.f }, ImGuiInputTextFlags_ReadOnly);
        ImGui::PopStyleColor();
    }
}

// =============================================================================
// Updater Tab
// =============================================================================

void OMURGGui::renderUpdaterTab(const Lang& L) {
    ImGui::Spacing();
    SectionHeader("Automatic Updates");

    ImGui::TextColored(NV_TEXT_DIM, "Manifest URL:");
    ImGui::SameLine();
    ImGui::TextColored(NV_GREEN, "%s", Updater::DEFAULT_MANIFEST_URL);

    ImGui::Spacing();

    if (!m->updateRunning) {
        ImGui::PushStyleColor(ImGuiCol_Button,        NV_GREEN_DARK);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, NV_GREEN_DIM);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  NV_GREEN);
        if (ImGui::Button(L.updateCheck, { 200.f, 32.f })) {
            m->updateRunning = true;
            m->updateStatus  = "Fetching manifest...";
            m->updater->startAsyncUpdate(
                [this](const DownloadProgress& p) {
                    char buf[256];
                    if (p.totalBytes > 0)
                        std::snprintf(buf, sizeof(buf),
                            "Downloading %s: %.1f%%",
                            p.filename.c_str(),
                            100.0 * p.bytesReceived / p.totalBytes);
                    else
                        std::snprintf(buf, sizeof(buf),
                            "Downloading %s: %llu bytes",
                            p.filename.c_str(), p.bytesReceived);
                    m->updateStatus = buf;
                },
                [this](bool ok, const std::string& msg) {
                    m->updateRunning = false;
                    m->updateStatus  = (ok ? "[OK] " : "[FAIL] ") + msg;
                });
        }
        ImGui::PopStyleColor(3);
    } else {
        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4{0.30f,0.06f,0.06f,1.f});
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4{0.50f,0.10f,0.10f,1.f});
        if (ImGui::Button("Cancel", { 120.f, 32.f }))
            m->updater->cancelAsync();
        ImGui::PopStyleColor(2);
        ImGui::SameLine();
        const char* spin[] = { "|", "/", "-", "\\" };
        static int frame = 0;
        ImGui::TextColored(NV_GREEN, "%s  Working...", spin[(frame++ / 8) % 4]);
    }

    ImGui::Spacing();
    SectionHeader("Status");

    if (!m->updateStatus.empty()) {
        bool ok = m->updateStatus.substr(0, 4) == "[OK]";
        bool fail = m->updateStatus.substr(0, 6) == "[FAIL]";
        ImVec4 col = fail ? NV_RED : (ok ? NV_GREEN : NV_TEXT_DIM);
        ImGui::TextColored(col, "%s", m->updateStatus.c_str());
    } else {
        ImGui::TextColored(NV_TEXT_DIM, "No update check performed yet.");
    }
}

// =============================================================================
// Support Tab
// =============================================================================

void OMURGGui::renderSupportTab(const Lang& L) {
    ImGui::Spacing();
    SectionHeader("Contact Support");

    ImGui::TextColored(NV_TEXT_DIM,
        "Fill in the form below. Clicking Send will open your");
    ImGui::TextColored(NV_TEXT_DIM,
        "default email client with the message pre-filled.");
    ImGui::Spacing();

    ImGui::PushStyleColor(ImGuiCol_FrameBg, NV_BG2);

    ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportName);
    ImGui::SetNextItemWidth(-1.f);
    ImGui::InputText("##sname", m->supportName, sizeof(m->supportName));
    ImGui::Spacing();

    ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportEmail);
    ImGui::SetNextItemWidth(-1.f);
    ImGui::InputText("##semail", m->supportEmail, sizeof(m->supportEmail));
    ImGui::Spacing();

    ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportSubj);
    ImGui::SetNextItemWidth(-1.f);
    ImGui::InputText("##ssubj", m->supportSubj, sizeof(m->supportSubj));
    ImGui::Spacing();

    ImGui::TextColored(NV_TEXT_DIM, "%s", L.supportMsg);
    ImGui::InputTextMultiline("##smsg", m->supportMsg,
        sizeof(m->supportMsg), { -1.f, 140.f });

    ImGui::PopStyleColor();

    ImGui::Spacing();

    ImGui::PushStyleColor(ImGuiCol_Button,        NV_GREEN_DARK);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, NV_GREEN_DIM);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  NV_GREEN);

    if (ImGui::Button(L.supportSend, { 200.f, 32.f })) {
        // Build mailto: URL and open default email client
        std::string subject = std::string("[OMURG] ") + m->supportSubj;
        std::string body    = std::string("Name: ") + m->supportName + "\r\n"
                            + "Email: "    + m->supportEmail + "\r\n\r\n"
                            + m->supportMsg;

        // URL-encode (minimal: spaces and newlines)
        auto urlEnc = [](const std::string& s) {
            std::string r;
            for (unsigned char c : s) {
                if (c == ' ')       r += "%20";
                else if (c == '\r') r += "%0D";
                else if (c == '\n') r += "%0A";
                else if (c == '&')  r += "%26";
                else if (c == '?')  r += "%3F";
                else if (c == '#')  r += "%23";
                else                r += static_cast<char>(c);
            }
            return r;
        };

        std::string mailto = "mailto:";
        mailto += SupportClient::SUPPORT_EMAIL;
        mailto += "?subject=" + urlEnc(subject);
        mailto += "&body="    + urlEnc(body);

        ShellExecuteA(nullptr, "open", mailto.c_str(), nullptr, nullptr, SW_SHOW);

        m->supportResultOk = true;
        m->supportResult   = "Email client opened successfully.";
    }

    ImGui::PopStyleColor(3);

    if (!m->supportResult.empty()) {
        ImGui::Spacing();
        ImGui::TextColored(m->supportResultOk ? NV_GREEN : NV_RED,
            "%s", m->supportResult.c_str());
    }
}

// =============================================================================
// Settings Tab
// =============================================================================

void OMURGGui::renderSettingsTab(const Lang& L) {
    ImGui::Spacing();
    SectionHeader("Interface");

    ImGui::TextColored(NV_TEXT_DIM, "%s", L.langLabel);
    ImGui::SameLine(160.f);
    const char* langs[] = { "English", "Turkce" };
    ImGui::SetNextItemWidth(160.f);
    ImGui::Combo("##lang", &m->currentLangIdx, langs, 2);

    ImGui::Spacing();
    SectionHeader("About");

    StatRow("Application",    "OMURG Virtual GPU Control Panel");
    StatRow("Version",        "1.0.0");
    StatRow("Architecture",   "x64 (AVX2 / SSE4.2)");
    StatRow("Renderer",       "FX150 Software Rasterizer");
    StatRow("Build",          __DATE__);

    ImGui::Spacing();
    SectionHeader("Links");

    ImGui::PushStyleColor(ImGuiCol_Button,        NV_BG3);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, NV_SELECTED);
    if (ImGui::Button("GitHub Repository", { 200.f, 28.f }))
        ShellExecuteA(nullptr, "open",
            "https://github.com/gamegameromur-a11y/OMURG",
            nullptr, nullptr, SW_SHOW);
    ImGui::PopStyleColor(2);
}

// =============================================================================
// WinMain
// =============================================================================

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static OMURGGui* g_gui = nullptr;

static LRESULT CALLBACK WndProc(HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;
    switch (msg) {
    case WM_SIZE:
        if (g_gui && wParam != SIZE_MINIMIZED)
            g_gui->resize(LOWORD(lParam), HIWORD(lParam));
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    WNDCLASSEXW wc = { sizeof(wc) };
    wc.style         = CS_CLASSDC;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = L"OMURGWnd";
    wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_OMURG));
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowW(
        L"OMURGWnd", L"OMURG Virtual GPU Control Panel",
        WS_OVERLAPPEDWINDOW,
        100, 100, 1280, 800,
        nullptr, nullptr, hInstance, nullptr);

    OMURGGui gui;
    g_gui = &gui;

    if (!gui.init(hwnd)) {
        MessageBoxA(nullptr, "Failed to initialize OMURG.", "Error",
                    MB_OK | MB_ICONERROR);
        return 1;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg = {};
    while (msg.message != WM_QUIT) {
        if (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        } else {
            gui.render();
        }
    }

    gui.shutdown();
    g_gui = nullptr;
    DestroyWindow(hwnd);
    UnregisterClassW(L"OMURGWnd", hInstance);
    return 0;
}
