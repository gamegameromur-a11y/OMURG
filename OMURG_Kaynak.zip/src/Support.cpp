// =============================================================================
// OMURG - Support.cpp
// SMTP client via Winsock2 (STARTTLS) + HTTP POST fallback
// =============================================================================

#include "Support.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <wininet.h>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wininet.lib")

// Schannel / TLS (for STARTTLS upgrade)
#define SECURITY_WIN32
#include <security.h>
#include <schnlsp.h>
#pragma comment(lib, "secur32.lib")

#include <sstream>
#include <iomanip>
#include <ctime>
#include <algorithm>
#include <stdexcept>

// =============================================================================
// Base64
// =============================================================================

static const char B64_CHARS[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

std::string SupportClient::base64Encode(const std::string& input) {
    std::string result;
    result.reserve((input.size() + 2) / 3 * 4);

    const auto* data = reinterpret_cast<const unsigned char*>(input.c_str());
    size_t len = input.size();

    for (size_t i = 0; i < len; i += 3) {
        unsigned char b0 = data[i];
        unsigned char b1 = (i + 1 < len) ? data[i + 1] : 0;
        unsigned char b2 = (i + 2 < len) ? data[i + 2] : 0;

        result += B64_CHARS[(b0 >> 2) & 0x3F];
        result += B64_CHARS[((b0 & 0x3) << 4) | ((b1 >> 4) & 0xF)];
        result += (i + 1 < len) ? B64_CHARS[((b1 & 0xF) << 2) | ((b2 >> 6) & 0x3)] : '=';
        result += (i + 2 < len) ? B64_CHARS[b2 & 0x3F] : '=';
    }
    return result;
}

// =============================================================================
// System info collector
// =============================================================================

std::string SupportClient::collectSystemInfo() {
    std::ostringstream oss;

    // OS version
    OSVERSIONINFOEXA osvi = { sizeof(osvi) };
#pragma warning(suppress: 4996)
    GetVersionExA(reinterpret_cast<OSVERSIONINFOA*>(&osvi));
    oss << "OS: Windows " << osvi.dwMajorVersion << "."
        << osvi.dwMinorVersion << " Build " << osvi.dwBuildNumber << "\n";

    // CPU info
    SYSTEM_INFO si = {};
    GetNativeSystemInfo(&si);
    oss << "CPU Threads: " << si.dwNumberOfProcessors << "\n";
    oss << "Architecture: " << (si.wProcessorArchitecture == 9 ? "x64" : "x86") << "\n";

    // Memory
    MEMORYSTATUSEX mem = { sizeof(mem) };
    GlobalMemoryStatusEx(&mem);
    oss << "RAM Total: " << (mem.ullTotalPhys / 1024 / 1024) << " MB\n";
    oss << "RAM Available: " << (mem.ullAvailPhys / 1024 / 1024) << " MB\n";

    // Computer name
    char name[256] = {};
    DWORD nameLen = sizeof(name);
    GetComputerNameA(name, &nameLen);
    oss << "Machine: " << name << "\n";

    // Timestamp
    std::time_t t = std::time(nullptr);
    char timeBuf[64];
    std::strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S UTC", std::gmtime(&t));
    oss << "Time: " << timeBuf << "\n";

    return oss.str();
}

// =============================================================================
// Construction
// =============================================================================

SupportClient::SupportClient()
    : m_gatewayUrl(GATEWAY_URL)
{
    // Initialize Winsock once (idempotent if called multiple times)
    WSADATA wd;
    WSAStartup(MAKEWORD(2, 2), &wd);
}

SupportClient::~SupportClient() {
    // Do NOT call WSACleanup here — other parts of the app might use sockets.
}

void SupportClient::setSmtpAuth(const std::string& user, const std::string& pw) {
    m_smtpUser = user;
    m_smtpPass = pw;
}

void SupportClient::setGatewayApiKey(const std::string& key) { m_gatewayKey = key; }
void SupportClient::setGatewayUrl   (const std::string& url) { m_gatewayUrl = url; }

// =============================================================================
// MIME message builder
// =============================================================================

std::string SupportClient::buildMimeMessage(const SupportTicket& ticket) {
    std::ostringstream oss;

    std::time_t t = std::time(nullptr);
    char timeBuf[64];
    std::strftime(timeBuf, sizeof(timeBuf),
                  "%a, %d %b %Y %H:%M:%S +0000", std::gmtime(&t));

    std::string boundary = "----=_OMURG_Boundary_7F3A9D2C";

    oss << "From: OMURG Support <" << m_smtpUser << ">\r\n";
    oss << "To: " << SUPPORT_EMAIL << "\r\n";
    oss << "Reply-To: " << ticket.senderName
        << " <" << ticket.senderEmail << ">\r\n";
    oss << "Subject: [OMURG] " << ticket.subject << "\r\n";
    oss << "Date: " << timeBuf << "\r\n";
    oss << "MIME-Version: 1.0\r\n";
    oss << "Content-Type: multipart/mixed; boundary=\"" << boundary << "\"\r\n";
    oss << "X-OMURG-GPU: " << ticket.gpuModel << "\r\n";
    oss << "X-OMURG-Driver: " << ticket.driverVersion << "\r\n";
    oss << "\r\n";

    // Part 1: Plain-text body
    oss << "--" << boundary << "\r\n";
    oss << "Content-Type: text/plain; charset=UTF-8\r\n";
    oss << "Content-Transfer-Encoding: 7bit\r\n\r\n";
    oss << "From: " << ticket.senderName << " <" << ticket.senderEmail << ">\r\n";
    oss << "GPU Model: " << ticket.gpuModel << "\r\n";
    oss << "Driver: "   << ticket.driverVersion << "\r\n";
    oss << "OS: "       << ticket.osInfo << "\r\n\r\n";
    oss << ticket.body << "\r\n";

    // Part 2: Log attachment (base64)
    if (!ticket.logDump.empty()) {
        oss << "--" << boundary << "\r\n";
        oss << "Content-Type: text/plain; name=\"omurg_log.txt\"\r\n";
        oss << "Content-Disposition: attachment; filename=\"omurg_log.txt\"\r\n";
        oss << "Content-Transfer-Encoding: base64\r\n\r\n";

        std::string encoded = base64Encode(ticket.logDump);
        // Wrap at 76 chars per RFC 2045
        for (size_t i = 0; i < encoded.size(); i += 76) {
            oss << encoded.substr(i, 76) << "\r\n";
        }
    }

    oss << "--" << boundary << "--\r\n";
    return oss.str();
}

// =============================================================================
// Winsock helpers
// =============================================================================

MailResult SupportClient::smtpSend(void* hSock, const std::string& cmd) {
    SOCKET s = reinterpret_cast<SOCKET>(hSock);
    std::string line = cmd + "\r\n";
    int sent = send(s, line.c_str(), static_cast<int>(line.size()), 0);
    if (sent == SOCKET_ERROR)
        return { false, -1, "send() failed: " + std::to_string(WSAGetLastError()) };
    return { true };
}

MailResult SupportClient::smtpRecv(void* hSock, std::string& response) {
    SOCKET s = reinterpret_cast<SOCKET>(hSock);
    response.clear();
    char buf[1024];
    while (true) {
        int n = recv(s, buf, sizeof(buf) - 1, 0);
        if (n <= 0) return { false, -1, "recv() failed" };
        buf[n] = '\0';
        response += buf;
        if (response.size() >= 2 &&
            response[response.size() - 2] == '\r' &&
            response[response.size() - 1] == '\n')
            break;
    }
    return { true, std::atoi(response.c_str()) };
}

MailResult SupportClient::smtpClose(void* hSock) {
    SOCKET s = reinterpret_cast<SOCKET>(hSock);
    closesocket(s);
    return { true };
}

// =============================================================================
// SMTP delivery
// =============================================================================

MailResult SupportClient::sendTicketSMTP(const SupportTicket& ticket) {
    if (m_smtpUser.empty() || m_smtpPass.empty())
        return { false, 0, "SMTP credentials not set." };

    // Resolve host
    struct addrinfo hints = {}, *res = nullptr;
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if (getaddrinfo(SMTP_HOST, std::to_string(SMTP_PORT).c_str(),
                    &hints, &res) != 0)
        return { false, 0, "DNS resolution failed for " + std::string(SMTP_HOST) };

    SOCKET sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sock == INVALID_SOCKET) {
        freeaddrinfo(res);
        return { false, 0, "socket() failed" };
    }

    if (connect(sock, res->ai_addr, static_cast<int>(res->ai_addrlen)) != 0) {
        closesocket(sock);
        freeaddrinfo(res);
        return { false, 0, "connect() to " + std::string(SMTP_HOST) + " failed" };
    }
    freeaddrinfo(res);

    void* hSock = reinterpret_cast<void*>(sock);

    auto check = [&](const std::string& cmd, int expected) -> MailResult {
        if (!cmd.empty()) smtpSend(hSock, cmd);
        std::string resp;
        auto r = smtpRecv(hSock, resp);
        if (!r.success) return r;
        if (expected > 0 && r.smtpCode != expected)
            return { false, r.smtpCode, "Unexpected: " + resp };
        return { true, r.smtpCode, resp };
    };

    MailResult r;

    // Server greeting
    r = check("", 220); if (!r.success) { smtpClose(hSock); return r; }

    // EHLO
    r = check("EHLO omurg-client", 250); if (!r.success) { smtpClose(hSock); return r; }

    // STARTTLS
    r = check("STARTTLS", 220);
    if (!r.success) { smtpClose(hSock); return r; }

    // NOTE: For full TLS upgrade using Schannel, a production implementation
    // would call InitializeSecurityContext() here. Shown as stub:
    // r = smtpStartTLS(&hSock);
    // For simplicity we document this clearly — use a TLS wrapper library
    // (e.g. WolfSSL, OpenSSL) for the actual handshake in production.

    // Re-EHLO after TLS (required by RFC 3207)
    r = check("EHLO omurg-client", 250); if (!r.success) { smtpClose(hSock); return r; }

    // AUTH PLAIN
    std::string credentials = std::string("\0", 1) + m_smtpUser
                            + std::string("\0", 1) + m_smtpPass;
    r = check("AUTH PLAIN " + base64Encode(credentials), 235);
    if (!r.success) { smtpClose(hSock); return r; }

    // Envelope
    r = check("MAIL FROM:<" + m_smtpUser + ">", 250);
    if (!r.success) { smtpClose(hSock); return r; }

    r = check("RCPT TO:<" + std::string(SUPPORT_EMAIL) + ">", 250);
    if (!r.success) { smtpClose(hSock); return r; }

    r = check("DATA", 354);
    if (!r.success) { smtpClose(hSock); return r; }

    // Send MIME body
    std::string mime = buildMimeMessage(ticket);
    smtpSend(hSock, mime);
    r = check(".", 250);
    if (!r.success) { smtpClose(hSock); return r; }

    check("QUIT", 221);
    smtpClose(hSock);

    return { true, 250, "Message delivered via SMTP." };
}

// =============================================================================
// HTTP POST fallback (WinINet)
// =============================================================================

std::string SupportClient::buildJsonPayload(const SupportTicket& ticket) {
    // Simple JSON serialization (escaping omitted for brevity — add in production)
    std::ostringstream oss;
    oss << "{"
        << "\"service_id\":\"omurg_support\","
        << "\"template_id\":\"template_support\","
        << "\"user_id\":\"" << m_gatewayKey << "\","
        << "\"template_params\":{"
        << "\"from_name\":\""    << ticket.senderName    << "\","
        << "\"from_email\":\""   << ticket.senderEmail   << "\","
        << "\"subject\":\""      << ticket.subject       << "\","
        << "\"message\":\""      << ticket.body          << "\","
        << "\"gpu_model\":\""    << ticket.gpuModel      << "\","
        << "\"driver_ver\":\""   << ticket.driverVersion << "\","
        << "\"log\":\""          << base64Encode(ticket.logDump) << "\""
        << "}}";
    return oss.str();
}

MailResult SupportClient::sendTicketHTTP(const SupportTicket& ticket) {
    std::string payload = buildJsonPayload(ticket);

    HINTERNET hNet = InternetOpenA("OMURG-Support/1.0",
        INTERNET_OPEN_TYPE_PRECONFIG, nullptr, nullptr, 0);
    if (!hNet) return { false, 0, "InternetOpen failed" };

    // Parse URL
    URL_COMPONENTSA uc = { sizeof(uc) };
    char host[256] = {}, path[1024] = {};
    uc.lpszHostName = host; uc.dwHostNameLength = sizeof(host);
    uc.lpszUrlPath  = path; uc.dwUrlPathLength  = sizeof(path);
    InternetCrackUrlA(m_gatewayUrl.c_str(),
                      static_cast<DWORD>(m_gatewayUrl.size()), 0, &uc);

    HINTERNET hConn = InternetConnectA(hNet, host, uc.nPort,
        nullptr, nullptr, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConn) {
        InternetCloseHandle(hNet);
        return { false, 0, "InternetConnect failed" };
    }

    DWORD flags = INTERNET_FLAG_RELOAD | INTERNET_FLAG_SECURE |
                  INTERNET_FLAG_NO_CACHE_WRITE;
    HINTERNET hReq = HttpOpenRequestA(hConn, "POST", path,
        nullptr, nullptr, nullptr, flags, 0);
    if (!hReq) {
        InternetCloseHandle(hConn);
        InternetCloseHandle(hNet);
        return { false, 0, "HttpOpenRequest failed" };
    }

    std::string headers = "Content-Type: application/json\r\n";
    BOOL ok = HttpSendRequestA(hReq,
        headers.c_str(), static_cast<DWORD>(headers.size()),
        const_cast<char*>(payload.c_str()),
        static_cast<DWORD>(payload.size()));

    DWORD statusCode = 0;
    DWORD scLen = sizeof(DWORD);
    if (ok) {
        HttpQueryInfoA(hReq,
            HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
            &statusCode, &scLen, nullptr);
    }

    InternetCloseHandle(hReq);
    InternetCloseHandle(hConn);
    InternetCloseHandle(hNet);

    bool success = (statusCode >= 200 && statusCode < 300);
    return { success, static_cast<int>(statusCode),
             success ? "HTTP POST delivered." : "HTTP POST failed." };
}

// =============================================================================
// Auto-select
// =============================================================================

MailResult SupportClient::sendTicket(const SupportTicket& ticket) {
    if (!m_smtpUser.empty() && !m_smtpPass.empty()) {
        auto r = sendTicketSMTP(ticket);
        if (r.success) return r;
    }
    if (!m_gatewayKey.empty()) {
        return sendTicketHTTP(ticket);
    }
    return { false, 0, "No delivery method configured." };
}
